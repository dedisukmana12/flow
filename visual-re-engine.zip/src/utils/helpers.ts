import { HierarchyLevel, MenuItem, Project, RequirementNode } from '../types';

export const LEVEL_CONFIG: Record<
  HierarchyLevel,
  {
    name: string;
    badgeClass: string;
    bgLight: string;
    borderClass: string;
    icon: string;
    description: string;
  }
> = {
  1: {
    name: 'Tingkat 1: Sistem Utama',
    badgeClass: 'bg-[#007bff] text-white',
    bgLight: 'bg-blue-50/70 border-blue-200',
    borderClass: 'border-l-4 border-l-[#007bff]',
    icon: 'fa-solid fa-server',
    description: 'Nama aplikasi utama atau sistem induk secara menyeluruh',
  },
  2: {
    name: 'Tingkat 2: Bagian / Modul',
    badgeClass: 'bg-[#28a745] text-white',
    bgLight: 'bg-green-50/70 border-green-200',
    borderClass: 'border-l-4 border-l-[#28a745]',
    icon: 'fa-solid fa-cubes',
    description: 'Kelompok menu atau bagian fungsi utama dalam aplikasi',
  },
  3: {
    name: 'Tingkat 3: Menu / Halaman',
    badgeClass: 'bg-[#ffc107] text-gray-900',
    bgLight: 'bg-amber-50/70 border-amber-200',
    borderClass: 'border-l-4 border-l-[#ffc107]',
    icon: 'fa-solid fa-list-check',
    description: 'Halaman kerja, formulir, atau layar tampilan yang dibuka pengguna',
  },
  4: {
    name: 'Tingkat 4: Fitur / Tombol',
    badgeClass: 'bg-[#17a2b8] text-white',
    bgLight: 'bg-cyan-50/70 border-cyan-200',
    borderClass: 'border-l-4 border-l-[#17a2b8]',
    icon: 'fa-solid fa-bolt',
    description: 'Tombol, tindakan, atau fungsi spesifik yang diklik pengguna',
  },
};

export const COMMON_FA_ICONS = [
  'fa-solid fa-server',
  'fa-solid fa-cubes',
  'fa-solid fa-list-check',
  'fa-solid fa-bolt',
  'fa-solid fa-hospital',
  'fa-solid fa-user-plus',
  'fa-solid fa-truck-medical',
  'fa-solid fa-stethoscope',
  'fa-solid fa-file-prescription',
  'fa-solid fa-pills',
  'fa-solid fa-file-invoice-dollar',
  'fa-solid fa-fingerprint',
  'fa-solid fa-shield-halved',
  'fa-solid fa-heart-pulse',
  'fa-solid fa-barcode',
  'fa-solid fa-database',
  'fa-solid fa-network-wired',
  'fa-solid fa-lock',
  'fa-solid fa-cart-shopping',
  'fa-solid fa-wallet',
  'fa-solid fa-gear',
  'fa-solid fa-chart-line',
  'fa-solid fa-bell',
  'fa-solid fa-envelope',
  'fa-solid fa-cloud-arrow-up',
];

/**
 * Builds a structured hierarchy tree from flat menu items
 */
export interface TreeNode {
  item: MenuItem;
  children: TreeNode[];
  requirementCount: number;
}

export function buildHierarchyTree(
  items: MenuItem[],
  requirements: RequirementNode[]
): TreeNode[] {
  const itemMap = new Map<string, TreeNode>();

  // Count requirements per feature/menu/module/system
  const reqCounts: Record<string, number> = {};
  for (const r of requirements) {
    if (r.featureId) reqCounts[r.featureId] = (reqCounts[r.featureId] || 0) + 1;
    if (r.menuId) reqCounts[r.menuId] = (reqCounts[r.menuId] || 0) + 1;
    if (r.moduleId) reqCounts[r.moduleId] = (reqCounts[r.moduleId] || 0) + 1;
  }

  // Create tree nodes
  items.forEach((item) => {
    itemMap.set(item.id, {
      item,
      children: [],
      requirementCount: reqCounts[item.id] || 0,
    });
  });

  const rootNodes: TreeNode[] = [];

  items
    .sort((a, b) => a.order - b.order)
    .forEach((item) => {
      const node = itemMap.get(item.id)!;
      if (!item.parentId || !itemMap.has(item.parentId)) {
        rootNodes.push(node);
      } else {
        const parentNode = itemMap.get(item.parentId);
        if (parentNode) {
          parentNode.children.push(node);
        } else {
          rootNodes.push(node);
        }
      }
    });

  return rootNodes;
}

export interface ProjectStateInput {
  requirements: RequirementNode[];
  menuItems?: MenuItem[];
  project?: Project;
}

/**
 * Phase 3 Live Mermaid.js Diagram Compiler Function: compileToMermaid(projectState)
 * Reads requirement nodes and generates valid Mermaid.js Flowchart syntax matching:
 * graph TD
 * A[WHO: Suster] -->|ACTION: Submit Form| B(LOGIC: Validasi NIK)
 * B -->|OUTPUT: Record Patient| C[(TO: DB patients)]
 */
export function compileToMermaid(
  projectState: ProjectStateInput | RequirementNode[],
  options: {
    direction?: 'TD' | 'LR';
    selectedFeatureId?: string;
    styleMode?: 'CANONICAL' | 'SUBGRAPH';
  } = {}
): string {
  const requirements: RequirementNode[] = Array.isArray(projectState)
    ? projectState
    : projectState.requirements || [];

  const direction = options.direction || 'TD';
  const filterId = options.selectedFeatureId;
  const filtered = filterId
    ? requirements.filter(
        (r) => r.featureId === filterId || r.menuId === filterId || r.moduleId === filterId
      )
    : requirements;

  if (filtered.length === 0) {
    return `graph ${direction}
  EmptyState["No requirements defined for current scope\\nAdd requirement nodes in Builder"]:::emptyNode
  classDef emptyNode fill:#f8f9fa,stroke:#ced4da,stroke-width:2px,stroke-dasharray: 5 5,color:#6c757d;`;
  }

  const sanitize = (text: string) =>
    (text || '')
      .replace(/["\n\r|]/g, ' ')
      .replace(/[[\]{}()]/g, '')
      .trim();

  let code = `graph ${direction}\n`;
  code += `  %% Visual RE-Engine Live Compiled Architecture Flowchart\n`;

  // AdminLTE Theme Class Definitions
  code += `  classDef whoClass fill:#e8f4fd,stroke:#007bff,stroke-width:2px,color:#004085,font-weight:bold;\n`;
  code += `  classDef logicClass fill:#fff3cd,stroke:#ffc107,stroke-width:2px,color:#856404,font-weight:600;\n`;
  code += `  classDef targetClass fill:#e2e3e5,stroke:#343a40,stroke-width:2px,color:#1b1e21,font-weight:bold;\n`;
  code += `  classDef branchClass fill:#f8d7da,stroke:#dc3545,stroke-width:2px,color:#721c24;\n`;
  code += `  classDef fallbackClass fill:#e2e3e5,stroke:#6c757d,stroke-width:1px,color:#383d41;\n`;

  const useSubgraph = options.styleMode === 'SUBGRAPH';

  filtered.forEach((req, idx) => {
    const p = `R${idx + 1}`;
    const codeTag = req.reqCode ? `[${req.reqCode}] ` : '';
    const who = sanitize(req.whoRole || 'User Actor');
    const action = sanitize(req.action || 'Execute Action');
    const logic = sanitize(req.logic || 'Validate & Process Rules');
    const output = sanitize(req.output || 'Generate Result');
    const to = sanitize(req.toWhere || 'Target Destination');

    if (useSubgraph) {
      code += `\n  subgraph Sub_${p} ["${codeTag}${sanitize(req.title)}"]\n`;
      code += `    ${p}_WHO["WHO: ${who}"]:::whoClass\n`;
      code += `    ${p}_LOG("LOGIC: ${logic}"):::logicClass\n`;
      code += `    ${p}_TO[("TO: ${to}")]:::targetClass\n`;
      code += `    ${p}_WHO -->|ACTION: ${action}| ${p}_LOG\n`;
      code += `    ${p}_LOG -->|OUTPUT: ${output}| ${p}_TO\n`;

      if (req.hasBranching && req.branches && req.branches.length > 0) {
        req.branches.forEach((br, bIdx) => {
          const bp = `${p}_B${bIdx + 1}`;
          const cond = sanitize(br.condition || `Condition ${bIdx + 1}`);
          const brOut = sanitize(br.output || 'Alternative Output');
          const brTo = sanitize(br.toWhere || 'Alternative Target');
          const isElse = br.label?.toLowerCase().includes('else') || cond.toLowerCase().includes('else');

          code += `    ${bp}_TO[("TO: ${brTo}")]:::${isElse ? 'fallbackClass' : 'branchClass'}\n`;
          code += `    ${p}_LOG -->|${isElse ? 'ELSE' : 'IF'}: ${cond} -> OUTPUT: ${brOut}| ${bp}_TO\n`;
        });
      }
      code += `  end\n`;
    } else {
      // Direct Canonical Format:
      // A[WHO: Suster] -->|ACTION: Submit Form| B(LOGIC: Validasi NIK)
      // B -->|OUTPUT: Record Patient| C[(TO: DB patients)]
      code += `\n  %% Node ${codeTag}${sanitize(req.title)}\n`;
      code += `  ${p}_WHO["WHO: ${who} (${req.reqCode})"]:::whoClass\n`;
      code += `  ${p}_LOG("LOGIC: ${logic}"):::logicClass\n`;
      code += `  ${p}_TO[("TO: ${to}")]:::targetClass\n`;
      code += `  ${p}_WHO -->|ACTION: ${action}| ${p}_LOG\n`;
      code += `  ${p}_LOG -->|OUTPUT: ${output}| ${p}_TO\n`;

      if (req.hasBranching && req.branches && req.branches.length > 0) {
        req.branches.forEach((br, bIdx) => {
          const bp = `${p}_B${bIdx + 1}`;
          const cond = sanitize(br.condition || `Condition ${bIdx + 1}`);
          const brOut = sanitize(br.output || 'Alternative Output');
          const brTo = sanitize(br.toWhere || 'Alternative Target');
          const isElse = br.label?.toLowerCase().includes('else') || cond.toLowerCase().includes('else');

          code += `  ${bp}_TO[("TO: ${brTo}")]:::${isElse ? 'fallbackClass' : 'branchClass'}\n`;
          code += `  ${p}_LOG -->|${isElse ? 'ELSE' : 'IF'}: ${cond} -> ${brOut}| ${bp}_TO\n`;
        });
      }
    }
  });

  return code;
}

/**
 * Generate Mermaid Flowchart syntax (Legacy wrapper for backward compatibility)
 */
export function generateMermaidDiagram(
  requirements: RequirementNode[],
  options: {
    direction?: 'TD' | 'LR';
    selectedFeatureId?: string;
    menuItemsMap?: Map<string, MenuItem>;
  } = {}
): string {
  return compileToMermaid({ requirements }, {
    direction: options.direction,
    selectedFeatureId: options.selectedFeatureId,
    styleMode: 'CANONICAL',
  });
}

/**
 * Generate Sequence Diagram syntax
 */
export function generateSequenceDiagram(requirements: RequirementNode[]): string {
  if (requirements.length === 0) {
    return `sequenceDiagram\n  Note over User,System: No requirements to display`;
  }

  let code = `sequenceDiagram\n  autonumber\n`;
  const sampleReqs = requirements.slice(0, 5); // top 5 for clean sequence

  sampleReqs.forEach((r) => {
    const who = (r.whoRole || 'User').replace(/[^a-zA-Z0-9]/g, '_');
    const source = (r.fromWhere || 'Client_UI').replace(/[^a-zA-Z0-9]/g, '_');
    const system = 'RE_Engine_Core';
    const target = (r.toWhere || 'Target_Destination').replace(/[^a-zA-Z0-9]/g, '_');

    code += `  actor ${who} as ${r.whoRole || 'User'}\n`;
    code += `  participant ${source} as ${r.fromWhere || 'Client UI'}\n`;
    code += `  participant ${system} as Core Validation Logic\n`;
    code += `  participant ${target} as ${r.toWhere || 'Target Store/UI'}\n\n`;

    code += `  ${who}->>${source}: ${r.action}\n`;
    code += `  ${source}->>${system}: Validate: ${r.logic.substring(0, 40)}...\n`;
    code += `  alt Success Scenario (${r.reqCode})\n`;
    code += `    ${system}->>${target}: ${r.output.substring(0, 45)}...\n`;
    code += `    ${target}-->>${who}: Confirmation Ack\n`;

    if (r.hasBranching && r.branches && r.branches.length > 0) {
      r.branches.forEach((b) => {
        const isElse = b.label?.toLowerCase().includes('else');
        code += `  else ${isElse ? 'Fallback (ELSE)' : b.label || 'Alternative Condition'}\n`;
        code += `    ${system}->>${target}: ${b.output.substring(0, 45)}...\n`;
      });
    }
    code += `  end\n\n`;
  });

  return code;
}

export type LogicGapType =
  | 'MISSING_TO_DESTINATION'
  | 'MISSING_ELSE_BRANCH'
  | 'INCOMPLETE_CORE_FIELDS'
  | 'ORPHAN_FEATURE_NODE';

export interface LogicGapIssue {
  id: string;
  type: LogicGapType;
  severity: 'CRITICAL' | 'WARNING' | 'INFO';
  title: string;
  description: string;
  fixSuggestion: string;
  reqId?: string;
  reqCode?: string;
  reqTitle?: string;
  featureId?: string;
  featureName?: string;
  fieldToFocus?: 'toWhere' | 'branches' | 'logic' | 'action' | 'whoRole';
}

/**
 * Mesin Pemeriksa Kelengkapan Alur Logika (Logic Gap Inspector)
 * Memeriksa:
 * 1. Alur yang belum memiliki tujuan akhir (TO Destination)
 * 2. Syarat/Kondisi yang belum memiliki penanganan saat gagal/salah (ELSE/Fallback)
 * 3. Alur 6-Pertanyaan yang belum terisi lengkap
 * 4. Tombol/Fitur menu yang belum dibuatkan alur kerjanya
 */
export function analyzeLogicGaps(
  requirements: RequirementNode[],
  menuItems: MenuItem[] = []
): LogicGapIssue[] {
  const issues: LogicGapIssue[] = [];

  // Periksa setiap alur kebutuhan
  requirements.forEach((req) => {
    // 1. Pengecekan Tujuan Akhir (TO WHERE)
    const toWhere = (req.toWhere || '').trim().toLowerCase();
    const isMissingTo =
      !toWhere ||
      toWhere === 'n/a' ||
      toWhere === 'tbd' ||
      toWhere === 'unknown' ||
      toWhere === '-' ||
      toWhere === 'none';

    if (isMissingTo) {
      issues.push({
        id: `gap-to-${req.id}`,
        type: 'MISSING_TO_DESTINATION',
        severity: 'CRITICAL',
        title: `Tujuan Akhir Belum Ditentukan pada [${req.reqCode}]`,
        description: `Alur "${req.title}" belum menentukan ke mana hasil atau layar tujuan setelah tombol/tindakan ini berhasil dijalankan.`,
        fixSuggestion: `Isi bagian "TUJUAN (Ke Mana)" dengan nama halaman, pesan notifikasi, atau penyimpanan data (misalnya: "Halaman Daftar Pasien", "Penyimpanan Database", atau "Pesan Berhasil").`,
        reqId: req.id,
        reqCode: req.reqCode,
        reqTitle: req.title,
        fieldToFocus: 'toWhere',
      });
    }

    // 2. Pengecekan Kondisi Khusus / Percabangan Jika-Gagal (ELSE / Fallback)
    const logicText = (req.logic || '').toLowerCase();
    const hasIfInLogic =
      logicText.includes('if ') ||
      logicText.includes('jika') ||
      logicText.includes('apabila') ||
      logicText.includes('ketika') ||
      logicText.includes('validasi') ||
      logicText.includes('check');

    if (req.hasBranching) {
      const branches = req.branches || [];
      if (branches.length === 0) {
        issues.push({
          id: `gap-branch-empty-${req.id}`,
          type: 'MISSING_ELSE_BRANCH',
          severity: 'WARNING',
          title: `Percabangan Aktif tapi Belum Ada Kondisi Khusus pada [${req.reqCode}]`,
          description: `Opsi percabangan diaktifkan, namun belum ada daftar kondisi jika-berhasil atau jika-gagal yang ditambahkan.`,
          fixSuggestion: `Tambahkan minimal 1 kondisi (JIKA) dan 1 kondisi penanganan gagal (JIKA SALAH / LAINNYA) agar alur tidak buntu.`,
          reqId: req.id,
          reqCode: req.reqCode,
          reqTitle: req.title,
          fieldToFocus: 'branches',
        });
      } else {
        const hasElseBranch = branches.some(
          (b) =>
            (b.label || '').toLowerCase().includes('else') ||
            (b.condition || '').toLowerCase().includes('else') ||
            (b.condition || '').toLowerCase().includes('lainnya') ||
            (b.condition || '').toLowerCase().includes('default') ||
            (b.condition || '').toLowerCase().includes('gagal') ||
            (b.condition || '').toLowerCase().includes('salah') ||
            (b.condition || '').toLowerCase().includes('tidak valid') ||
            (b.condition || '').toLowerCase().includes('invalid')
        );

        if (!hasElseBranch) {
          issues.push({
            id: `gap-else-${req.id}`,
            type: 'MISSING_ELSE_BRANCH',
            severity: 'WARNING',
            title: `Belum Ada Jalur Penanganan Jika Gagal pada [${req.reqCode}]`,
            description: `Terdapat kondisi khusus, tetapi belum ditentukan apa yang terjadi jika data tidak sesuai / salah pengisian.`,
            fixSuggestion: `Tambahkan cabang "JIKA GAGAL / KONDISI LAINNYA" yang menjelaskan pesan peringatan atau tindakan jika pengguna salah mengisi.`,
            reqId: req.id,
            reqCode: req.reqCode,
            reqTitle: req.title,
            fieldToFocus: 'branches',
          });
        }

        // Cek jika ada cabang yang tidak punya tujuan
        branches.forEach((b, bIdx) => {
          const brTo = (b.toWhere || '').trim().toLowerCase();
          if (!brTo || brTo === 'tbd' || brTo === 'n/a') {
            issues.push({
              id: `gap-branch-to-${req.id}-${b.id || bIdx}`,
              type: 'MISSING_TO_DESTINATION',
              severity: 'WARNING',
              title: `Cabang #${bIdx + 1} (${b.label || 'Kondisi'}) Belum Memiliki Tujuan pada [${req.reqCode}]`,
              description: `Kondisi percabangan "${b.condition || 'JIKA'}" menghasilkan keluaran tapi belum ditentukan ke mana hasil diarahkan.`,
              fixSuggestion: `Tuliskan layar tujuan atau pesan peringatan pada isian "TUJUAN (Ke Mana)".`,
              reqId: req.id,
              reqCode: req.reqCode,
              reqTitle: req.title,
              fieldToFocus: 'branches',
            });
          }
        });
      }
    } else if (hasIfInLogic && !req.hasBranching) {
      // Sarankan mengaktifkan percabangan jika ada kata 'jika'/'validasi'
      issues.push({
        id: `gap-unbranched-if-${req.id}`,
        type: 'MISSING_ELSE_BRANCH',
        severity: 'INFO',
        title: `Ada Kata Syarat / Pengecekan pada [${req.reqCode}]`,
        description: `Bagian aturan menyebutkan syarat pemeriksaan ("${req.logic.substring(0, 50)}..."), tetapi opsi percabangan belum diaktifkan.`,
        fixSuggestion: `Aktifkan "Pilihan Kondisi / Percabangan (Jika/Maka)" untuk memisahkan hasil saat sukses dan hasil saat data salah.`,
        reqId: req.id,
        reqCode: req.reqCode,
        reqTitle: req.title,
        fieldToFocus: 'branches',
      });
    }

    // 3. Pengecekan kelengkapan isian pokok
    const isMissingCore =
      !req.whoRole ||
      !req.action ||
      !req.logic ||
      !req.output;

    if (isMissingCore) {
      issues.push({
        id: `gap-core-${req.id}`,
        type: 'INCOMPLETE_CORE_FIELDS',
        severity: 'WARNING',
        title: `Isian Alur Belum Lengkap pada [${req.reqCode}]`,
        description: `Masih ada kolom penting yang kosong (misalnya Peran Pengguna, Tindakan Tombol, Aturan, atau Hasil).`,
        fixSuggestion: `Lengkapi semua isian di menu "Pencatat Alur Kerja" agar alur aplikasi jelas dari awal sampai akhir.`,
        reqId: req.id,
        reqCode: req.reqCode,
        reqTitle: req.title,
      });
    }
  });

  // 4. Pengecekan tombol/fitur menu yang belum dibuatkan alur kerjanya
  const features = menuItems.filter((m) => m.level === 4);
  const coveredFeatureIds = new Set(requirements.map((r) => r.featureId));

  features.forEach((feat) => {
    if (!coveredFeatureIds.has(feat.id)) {
      issues.push({
        id: `gap-feat-orphan-${feat.id}`,
        type: 'ORPHAN_FEATURE_NODE',
        severity: 'INFO',
        title: `Fitur/Tombol Belum Ada Alur Kerjanya: "${feat.name}" [${feat.code}]`,
        description: `Tombol ini sudah ada di susunan menu, tetapi belum dicatat bagaimana cara kerja dan tindakannya saat diklik.`,
        fixSuggestion: `Klik tombol "+ Buat Alur Kerja" untuk melengkapi detail cara kerja fitur ini.`,
        featureId: feat.id,
        featureName: feat.name,
      });
    }
  });

  return issues;
}
