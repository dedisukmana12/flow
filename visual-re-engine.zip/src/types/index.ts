export type HierarchyLevel = 1 | 2 | 3 | 4;

export interface MenuItem {
  id: string;
  projectId: string;
  name: string;
  code: string; // e.g. SYS-01, MOD-PATIENT, MNU-REG, FT-BIOMETRIC
  level: HierarchyLevel; // 1: System, 2: Module, 3: Menu, 4: Feature
  parentId: string | null;
  description?: string;
  icon?: string; // FontAwesome icon class e.g. "fa-solid fa-server"
  order: number;
  tags?: string[];
  createdAt: string;
  updatedAt: string;
}

export interface BranchCondition {
  id: string;
  label: string; // e.g. "Condition A: Valid Token", "Else: Auth Failed"
  condition: string; // e.g. "If user status is ACTIVE and password matches"
  output: string; // e.g. "Issue Access Token and proceed"
  toWhere: string; // e.g. "Dashboard View" or "Error Dialog"
  toWhereType?: 'internal_menu' | 'external_api' | 'ui_view' | 'db_operation';
}

export type RequirementPriority = 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
export type RequirementStatus = 'DRAFT' | 'IN_REVIEW' | 'APPROVED' | 'IMPLEMENTED';

export interface RequirementNode {
  id: string;
  projectId: string;
  reqCode: string; // e.g. REQ-AUTH-001
  title: string;
  
  // Hierarchy Linkage
  moduleId: string;
  menuId: string;
  featureId: string;
  
  // 6-Field Flow Architecture
  whoRole: string; // Actor role e.g. "Physician", "Admin", "Patient"
  whoCustom?: string;
  fromWhere: string; // Trigger origin e.g. "Registration Web Form", "Payment Webhook"
  action: string; // Trigger event e.g. "Clicks 'Confirm Admission' button"
  logic: string; // Business rules & validation rules
  output: string; // Success / primary response result
  toWhere: string; // Target destination / UI / system
  toWhereType: 'internal_menu' | 'external_api' | 'ui_view' | 'db_operation';
  
  // Branching Architecture
  hasBranching: boolean;
  branches: BranchCondition[];
  
  priority: RequirementPriority;
  status: RequirementStatus;
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

export interface Project {
  id: string;
  name: string;
  code: string;
  systemName: string;
  description: string;
  version: string;
  author: string;
  roles: string[];
  targetTechStack?: string;
  createdAt: string;
  updatedAt: string;
}

export type ActiveView = 
  | 'dashboard'
  | 'workspace'
  | 'menu_configurator' // View A
  | 'req_builder'       // View B
  | 'logic_diagram'     // View C
  | 'export_center'
  | 'help_center';

export interface BreadcrumbItem {
  id: string;
  name: string;
  level: HierarchyLevel;
}
