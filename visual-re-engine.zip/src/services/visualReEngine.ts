import { StorageService } from './storageService';
import { MenuItem, RequirementNode, Project } from '../types';

export interface VisualReEngineState {
  projectId: string;
  projectName: string;
  targetTechStack: string;
  menuHierarchy: MenuItem[]; // Tree/List of Level 1-4
  requirements: RequirementNode[]; // Array of WHO-FROM-ACTION-LOGIC-OUTPUT-TO
}

export interface LogicGapWarning {
  reqId: string;
  type: 'ORPHAN_OUTPUT' | 'MISSING_BRANCH' | 'INCOMPLETE_FLOW';
  message: string;
  severity?: 'CRITICAL' | 'WARNING' | 'INFO';
  fixSuggestion?: string;
}

/**
 * Visual RE-Engine Core Engine
 * Clean Code Architecture - Single Source of Truth
 * Fully integrated with persistent storage and domain invariants.
 */
export class VisualReEngine {
  public state: VisualReEngineState;

  constructor() {
    this.state = this.loadFromStorage() || this.getInitialState();
  }

  private getInitialState(): VisualReEngineState {
    const activeProject = StorageService.getActiveProject() || {
      id: 'proj-default',
      name: 'My First Project',
      code: 'SYS',
      systemName: 'Visual RE Enterprise',
      description: 'System Requirement Architecture and Logic Specification',
      version: '1.0.0',
      author: 'Software Architect',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    return {
      projectId: activeProject.id,
      projectName: activeProject.name,
      targetTechStack: 'Node.js + React',
      menuHierarchy: StorageService.getMenuItems(activeProject.id),
      requirements: StorageService.getRequirements(activeProject.id),
    };
  }

  // --- HIERARCHY MANAGEMENT ---
  addMenuNode(
    parentId: string | null,
    name: string,
    level: 1 | 2 | 3 | 4,
    extra: Partial<MenuItem> = {}
  ): MenuItem {
    const activeProjId = this.state.projectId || 'proj-default';
    const newNode: MenuItem = {
      id: 'node-' + Date.now() + '-' + Math.random().toString(36).substring(2, 6),
      projectId: activeProjId,
      parentId: parentId || null,
      name: name,
      code: extra.code || `L${level}-${Date.now().toString().slice(-4)}`,
      level: level, // 1: System, 2: Module, 3: Menu, 4: Feature
      icon: extra.icon || 'fa-solid fa-cube',
      order: extra.order !== undefined ? extra.order : this.state.menuHierarchy.length + 1,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      ...extra,
    };

    this.state.menuHierarchy.push(newNode);
    StorageService.saveMenuItem(newNode);
    this.saveToStorage();
    return newNode;
  }

  // --- REQUIREMENT MATRIX MANAGEMENT ---
  addRequirement(reqData: {
    featureId?: string;
    menuId?: string;
    moduleId?: string;
    who?: string;
    whoRole?: string;
    from?: string;
    fromWhere?: string;
    action: string;
    logic: string;
    output: string;
    to?: string;
    toWhere?: string;
    toWhereType?: RequirementNode['toWhereType'];
    branches?: RequirementNode['branches'];
    hasBranching?: boolean;
    title?: string;
    reqCode?: string;
    priority?: RequirementNode['priority'];
    status?: RequirementNode['status'];
  }): RequirementNode {
    const activeProjId = this.state.projectId || 'proj-default';
    const now = new Date().toISOString();

    const whoVal = reqData.who || reqData.whoRole || 'User Actor';
    const fromVal = reqData.from || reqData.fromWhere || 'User Interface';
    const toVal = reqData.to || reqData.toWhere || '';

    const newReq: RequirementNode = {
      id: 'req-' + Date.now() + '-' + Math.random().toString(36).substring(2, 6),
      projectId: activeProjId,
      moduleId: reqData.moduleId || '',
      menuId: reqData.menuId || '',
      featureId: reqData.featureId || '',
      reqCode: reqData.reqCode || `REQ-${String(this.state.requirements.length + 1).padStart(2, '0')}`,
      title: reqData.title || reqData.action || 'Requirement Node',
      whoRole: whoVal,
      fromWhere: fromVal,
      action: reqData.action,
      logic: reqData.logic,
      output: reqData.output,
      toWhere: toVal,
      toWhereType: reqData.toWhereType || 'db_operation',
      hasBranching: reqData.hasBranching ?? (Boolean(reqData.branches && reqData.branches.length > 0)),
      branches: reqData.branches || [],
      priority: reqData.priority || 'HIGH',
      status: reqData.status || 'APPROVED',
      createdAt: now,
      updatedAt: now,
    };

    this.state.requirements.push(newReq);
    StorageService.saveRequirement(newReq);
    this.saveToStorage();
    return newReq;
  }

  // --- LOGIC GAP INSPECTOR ENGINE ---
  inspectGaps(): LogicGapWarning[] {
    const warnings: LogicGapWarning[] = [];

    this.state.requirements.forEach((req) => {
      const target = (req.toWhere || '').trim();
      const logicUpper = (req.logic || '').toUpperCase();
      const actionName = req.action || req.title || req.reqCode;

      // Rule 1: Orphan Output Check (Output exists without Destination TO)
      if (req.output && (!target || target === '' || target.toLowerCase() === 'n/a' || target.toLowerCase() === 'tbd')) {
        warnings.push({
          reqId: req.id,
          type: 'ORPHAN_OUTPUT',
          message: `Requirement [${actionName}] menghasilkan Output '${req.output}' tetapi tidak memiliki Target Destination (TO).`,
          severity: 'CRITICAL',
          fixSuggestion: `Tambahkan target destinasi pada field 'TO WHERE' (contoh: Database Table, Workspace View, atau Notification Dialog).`,
        });
      }

      // Rule 2: Uncovered Conditional (IF logic without branching/ELSE exception)
      const hasIfClause = logicUpper.includes('IF') || logicUpper.includes('JIKA') || logicUpper.includes('APABILA');
      const hasBranches = req.hasBranching && req.branches && req.branches.length > 0;

      if (hasIfClause && !hasBranches) {
        warnings.push({
          reqId: req.id,
          type: 'MISSING_BRANCH',
          message: `Requirement [${actionName}] memiliki logika kondisional 'IF' tetapi belum memiliki cabang ELSE/Exception.`,
          severity: 'WARNING',
          fixSuggestion: `Aktifkan Conditional Branching dan tambahkan cabang ELSE/Fallback untuk menangani kegagalan validasi.`,
        });
      }
    });

    return warnings;
  }

  // --- MERMAID COMPILER ENGINE ---
  generateMermaidSyntax(): string {
    let syntax = 'graph TD\n';
    if (this.state.requirements.length === 0) {
      return syntax + '    Empty[Belum Ada Node Requirement]';
    }

    // Styling definitions for professional render
    syntax += '    classDef whoClass fill:#e8f4fd,stroke:#007bff,stroke-width:2px,color:#004085,font-weight:bold;\n';
    syntax += '    classDef logicClass fill:#fff3cd,stroke:#ffc107,stroke-width:2px,color:#856404,font-weight:600;\n';
    syntax += '    classDef targetClass fill:#e2e3e5,stroke:#343a40,stroke-width:2px,color:#1b1e21,font-weight:bold;\n';
    syntax += '    classDef branchClass fill:#f8d7da,stroke:#dc3545,stroke-width:2px,color:#721c24;\n';

    const sanitize = (text: string) =>
      (text || '')
        .replace(/["\n\r|]/g, ' ')
        .replace(/[[\]{}()]/g, '')
        .trim();

    this.state.requirements.forEach((req, idx) => {
      const nodeId = `N${idx}`;
      const who = sanitize(req.whoRole || 'User');
      const action = sanitize(req.action || 'Action');
      const logic = sanitize(req.logic || 'Logic');
      const output = sanitize(req.output || 'Output');
      const to = sanitize(req.toWhere || '');

      const label = `WHO: ${who}<br/>ACTION: ${action}<br/>LOGIC: ${logic}`;
      syntax += `    ${nodeId}["${label}"]:::logicClass\n`;

      if (to) {
        const targetId = `T${idx}`;
        syntax += `    ${targetId}[("TO: ${to}")]:::targetClass\n`;
        syntax += `    ${nodeId} -->|OUTPUT: ${output}| ${targetId}\n`;
      }

      // Render Branches (If/Else)
      if (req.branches && req.branches.length > 0) {
        req.branches.forEach((b, bIdx) => {
          const bId = `B_${idx}_${bIdx}`;
          const cond = sanitize(b.condition || `Branch ${bIdx + 1}`);
          const brOut = sanitize(b.output || 'Alt Output');
          const brTo = sanitize(b.toWhere || 'Target');
          syntax += `    ${bId}["${cond} -> ${brOut} (TO: ${brTo})"]:::branchClass\n`;
          syntax += `    ${nodeId} -.->|Branch| ${bId}\n`;
        });
      }
    });

    return syntax;
  }

  // --- PERSISTENCE ---
  saveToStorage(): void {
    if (typeof window === 'undefined') return;
    localStorage.setItem('VISUAL_RE_ENGINE_STATE', JSON.stringify(this.state));
  }

  loadFromStorage(): VisualReEngineState | null {
    if (typeof window === 'undefined') return null;
    try {
      const data = localStorage.getItem('VISUAL_RE_ENGINE_STATE');
      if (data) {
        const parsed = JSON.parse(data);
        if (parsed && Array.isArray(parsed.requirements)) {
          return parsed;
        }
      }
    } catch {
      // Fallback
    }

    // Synchronize with active StorageService state
    const activeProject = StorageService.getActiveProject();
    if (activeProject) {
      const state: VisualReEngineState = {
        projectId: activeProject.id,
        projectName: activeProject.name,
        targetTechStack: 'Node.js + React',
        menuHierarchy: StorageService.getMenuItems(activeProject.id),
        requirements: StorageService.getRequirements(activeProject.id),
      };
      return state;
    }
    return null;
  }

  // Sync state with latest storage items
  syncFromGlobalStorage(): void {
    const activeProject = StorageService.getActiveProject();
    if (activeProject) {
      this.state.projectId = activeProject.id;
      this.state.projectName = activeProject.name;
      this.state.menuHierarchy = StorageService.getMenuItems(activeProject.id);
      this.state.requirements = StorageService.getRequirements(activeProject.id);
      this.saveToStorage();
    }
  }
}

// Global Singleton Instance
export const visualReEngineCore = new VisualReEngine();
