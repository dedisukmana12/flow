import { DEFAULT_MENU_ITEMS, DEFAULT_PROJECTS, DEFAULT_REQUIREMENTS } from '../data/defaultData';
import { MenuItem, Project, RequirementNode } from '../types';

const STORAGE_KEYS = {
  PROJECTS: 'visual_re_projects_v2',
  ACTIVE_PROJECT_ID: 'visual_re_active_project_id_v2',
  MENU_ITEMS: 'visual_re_menu_items_v2',
  REQUIREMENTS: 'visual_re_requirements_v2',
};

// Event Dispatcher for cross-view reactive updates
export const STORAGE_EVENT = 'visual_re_storage_updated';

export const triggerStorageUpdate = () => {
  if (typeof window !== 'undefined') {
    window.dispatchEvent(new CustomEvent(STORAGE_EVENT));
  }
};

export const StorageService = {
  // =========================================================================
  // 1. PROJECTS CRUD
  // =========================================================================

  /**
   * READ: Retrieve all projects from persistent storage.
   * Returns empty array if no projects have been created yet (no automatic dummy seeding).
   */
  getProjects(): Project[] {
    try {
      const raw = localStorage.getItem(STORAGE_KEYS.PROJECTS);
      if (!raw) return [];
      const parsed = JSON.parse(raw);
      return Array.isArray(parsed) ? parsed : [];
    } catch {
      return [];
    }
  },

  /**
   * Internal save method for all projects.
   */
  saveProjects(projects: Project[]): void {
    localStorage.setItem(STORAGE_KEYS.PROJECTS, JSON.stringify(projects));
    triggerStorageUpdate();
  },

  /**
   * READ: Get active project ID.
   */
  getActiveProjectId(): string {
    const stored = localStorage.getItem(STORAGE_KEYS.ACTIVE_PROJECT_ID);
    if (stored) return stored;
    const projects = this.getProjects();
    if (projects.length > 0) {
      const firstId = projects[0].id;
      localStorage.setItem(STORAGE_KEYS.ACTIVE_PROJECT_ID, firstId);
      return firstId;
    }
    return '';
  },

  /**
   * UPDATE: Switch active project ID.
   */
  setActiveProjectId(id: string): void {
    localStorage.setItem(STORAGE_KEYS.ACTIVE_PROJECT_ID, id);
    triggerStorageUpdate();
  },

  /**
   * READ: Get active project object.
   */
  getActiveProject(): Project | undefined {
    const id = this.getActiveProjectId();
    const projects = this.getProjects();
    if (!id && projects.length > 0) {
      return projects[0];
    }
    return projects.find((p) => p.id === id);
  },

  /**
   * CREATE: Create and register a brand new project.
   */
  createProject(data: Omit<Project, 'id' | 'createdAt' | 'updatedAt'> & { id?: string }): Project {
    const projects = this.getProjects();
    const now = new Date().toISOString();
    const newProject: Project = {
      ...data,
      id: data.id || `proj-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      createdAt: now,
      updatedAt: now,
      roles: data.roles && data.roles.length > 0 ? data.roles : ['User', 'Admin', 'System Operator'],
    };

    projects.push(newProject);
    this.saveProjects(projects);
    this.setActiveProjectId(newProject.id);
    return newProject;
  },

  /**
   * UPDATE: Update an existing project's metadata, roles, description, etc.
   */
  updateProject(project: Project): Project {
    const projects = this.getProjects();
    const index = projects.findIndex((p) => p.id === project.id);
    const now = new Date().toISOString();

    if (index >= 0) {
      projects[index] = {
        ...projects[index],
        ...project,
        updatedAt: now,
      };
      this.saveProjects(projects);
      return projects[index];
    } else {
      const newProj = { ...project, createdAt: now, updatedAt: now };
      projects.push(newProj);
      this.saveProjects(projects);
      return newProj;
    }
  },

  /**
   * DELETE: Delete a project and cascadingly remove all associated hierarchy items and requirements.
   */
  deleteProject(projectId: string): void {
    const projects = this.getProjects();
    const remainingProjects = projects.filter((p) => p.id !== projectId);
    this.saveProjects(remainingProjects);

    // Cascading clean up menu items for this project
    const allMenus = this.getAllMenuItems();
    const filteredMenus = allMenus.filter((m) => m.projectId !== projectId);
    this.saveAllMenuItems(filteredMenus);

    // Cascading clean up requirements for this project
    const allReqs = this.getAllRequirements();
    const filteredReqs = allReqs.filter((r) => r.projectId !== projectId);
    this.saveAllRequirements(filteredReqs);

    // Switch active project if current one was deleted
    const activeId = this.getActiveProjectId();
    if (activeId === projectId) {
      const nextId = remainingProjects[0]?.id || '';
      this.setActiveProjectId(nextId);
    }
  },

  /**
   * CLONE / DUPLICATE: Duplicate a project structure.
   */
  duplicateProject(projectId: string, newName?: string, newCode?: string): Project | null {
    const projects = this.getProjects();
    const sourceProject = projects.find((p) => p.id === projectId);
    if (!sourceProject) return null;

    const now = new Date().toISOString();
    const newProjectId = `proj-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
    const clonedProject: Project = {
      ...sourceProject,
      id: newProjectId,
      name: newName || `${sourceProject.name} (Copy)`,
      code: newCode || `${sourceProject.code}-CPY`,
      createdAt: now,
      updatedAt: now,
    };

    projects.push(clonedProject);
    this.saveProjects(projects);

    // Clone Menu Items
    const sourceMenus = this.getMenuItems(projectId);
    const idMap = new Map<string, string>(); // oldId -> newId

    const newMenuItems: MenuItem[] = sourceMenus.map((m) => {
      const newId = `mnu-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;
      idMap.set(m.id, newId);
      return {
        ...m,
        id: newId,
        projectId: newProjectId,
        parentId: m.parentId ? idMap.get(m.parentId) || null : null,
        createdAt: now,
        updatedAt: now,
      };
    });
    // Fix forward parent links if any
    newMenuItems.forEach((m, idx) => {
      const original = sourceMenus[idx];
      if (original.parentId && idMap.has(original.parentId)) {
        m.parentId = idMap.get(original.parentId) || null;
      }
    });

    const allMenus = this.getAllMenuItems();
    this.saveAllMenuItems([...allMenus, ...newMenuItems]);

    // Clone Requirements
    const sourceReqs = this.getRequirements(projectId);
    const newReqs: RequirementNode[] = sourceReqs.map((r) => {
      const newReqId = `req-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;
      return {
        ...r,
        id: newReqId,
        projectId: newProjectId,
        moduleId: idMap.get(r.moduleId) || r.moduleId,
        menuId: idMap.get(r.menuId) || r.menuId,
        featureId: idMap.get(r.featureId) || r.featureId,
        createdAt: now,
        updatedAt: now,
      };
    });

    const allReqs = this.getAllRequirements();
    this.saveAllRequirements([...allReqs, ...newReqs]);

    this.setActiveProjectId(newProjectId);
    return clonedProject;
  },

  // =========================================================================
  // 2. MENU ITEMS / HIERARCHY CRUD (Level 1-4)
  // =========================================================================

  /**
   * READ: Get menu hierarchy items for a specific project.
   */
  getMenuItems(projectId?: string): MenuItem[] {
    try {
      const targetProjId = projectId || this.getActiveProjectId();
      if (!targetProjId) return [];
      const allItems = this.getAllMenuItems();
      return allItems.filter((item) => item.projectId === targetProjId);
    } catch {
      return [];
    }
  },

  /**
   * READ: Get all menu items across all projects.
   */
  getAllMenuItems(): MenuItem[] {
    try {
      const raw = localStorage.getItem(STORAGE_KEYS.MENU_ITEMS);
      if (!raw) return [];
      const parsed = JSON.parse(raw);
      return Array.isArray(parsed) ? parsed : [];
    } catch {
      return [];
    }
  },

  /**
   * Internal save method for all menu items.
   */
  saveAllMenuItems(items: MenuItem[]): void {
    localStorage.setItem(STORAGE_KEYS.MENU_ITEMS, JSON.stringify(items));
    triggerStorageUpdate();
  },

  /**
   * CREATE or UPDATE a menu item.
   */
  saveMenuItem(item: Omit<MenuItem, 'id' | 'createdAt' | 'updatedAt'> & { id?: string }): MenuItem {
    const all = this.getAllMenuItems();
    const activeProjId = item.projectId || this.getActiveProjectId();
    const now = new Date().toISOString();

    if (item.id) {
      const idx = all.findIndex((i) => i.id === item.id);
      if (idx >= 0) {
        const updated: MenuItem = {
          ...all[idx],
          ...item,
          id: item.id,
          projectId: activeProjId,
          updatedAt: now,
        };
        all[idx] = updated;
        this.saveAllMenuItems(all);
        return updated;
      }
    }

    // CREATE New Node
    const newId = item.id || `mnu-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
    const newItem: MenuItem = {
      ...item,
      id: newId,
      projectId: activeProjId,
      createdAt: now,
      updatedAt: now,
    };
    all.push(newItem);
    this.saveAllMenuItems(all);
    return newItem;
  },

  /**
   * DELETE a menu item and recursively delete all of its child nodes and linked requirements.
   */
  deleteMenuItem(id: string): void {
    const all = this.getAllMenuItems();

    // Find all descendants recursively
    const idsToDelete = new Set<string>([id]);
    let added = true;
    while (added) {
      added = false;
      for (const item of all) {
        if (item.parentId && idsToDelete.has(item.parentId) && !idsToDelete.has(item.id)) {
          idsToDelete.add(item.id);
          added = true;
        }
      }
    }

    const remaining = all.filter((i) => !idsToDelete.has(i.id));
    this.saveAllMenuItems(remaining);

    // Cascading clean up requirements attached to deleted items
    const reqs = this.getAllRequirements();
    const filteredReqs = reqs.filter(
      (r) => !idsToDelete.has(r.moduleId) && !idsToDelete.has(r.menuId) && !idsToDelete.has(r.featureId)
    );
    this.saveAllRequirements(filteredReqs);
  },

  /**
   * BATCH DELETE Menu Items
   */
  deleteMenuItemsBatch(ids: string[]): void {
    ids.forEach((id) => this.deleteMenuItem(id));
  },

  // =========================================================================
  // 3. REQUIREMENTS CRUD (6-Field Flow Architecture + Branching)
  // =========================================================================

  /**
   * READ: Get requirements for active or given project.
   */
  getRequirements(projectId?: string): RequirementNode[] {
    try {
      const targetProjId = projectId || this.getActiveProjectId();
      if (!targetProjId) return [];
      const allReqs = this.getAllRequirements();
      return allReqs.filter((r) => r.projectId === targetProjId);
    } catch {
      return [];
    }
  },

  /**
   * READ: Get all requirements across all projects.
   */
  getAllRequirements(): RequirementNode[] {
    try {
      const raw = localStorage.getItem(STORAGE_KEYS.REQUIREMENTS);
      if (!raw) return [];
      const parsed = JSON.parse(raw);
      return Array.isArray(parsed) ? parsed : [];
    } catch {
      return [];
    }
  },

  /**
   * Internal save method for all requirements.
   */
  saveAllRequirements(reqs: RequirementNode[]): void {
    localStorage.setItem(STORAGE_KEYS.REQUIREMENTS, JSON.stringify(reqs));
    triggerStorageUpdate();
  },

  /**
   * CREATE or UPDATE a requirement node.
   */
  saveRequirement(req: Omit<RequirementNode, 'id' | 'createdAt' | 'updatedAt'> & { id?: string }): RequirementNode {
    const all = this.getAllRequirements();
    const activeProjId = req.projectId || this.getActiveProjectId();
    const now = new Date().toISOString();

    if (req.id) {
      const idx = all.findIndex((r) => r.id === req.id);
      if (idx >= 0) {
        const updated: RequirementNode = {
          ...all[idx],
          ...req,
          id: req.id,
          projectId: activeProjId,
          updatedAt: now,
        };
        all[idx] = updated;
        this.saveAllRequirements(all);
        return updated;
      }
    }

    // CREATE New Requirement
    const newId = req.id || `req-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
    const newReq: RequirementNode = {
      ...req,
      id: newId,
      projectId: activeProjId,
      createdAt: now,
      updatedAt: now,
    };
    all.push(newReq);
    this.saveAllRequirements(all);
    return newReq;
  },

  /**
   * DUPLICATE a requirement node with a new unique code.
   */
  duplicateRequirement(id: string): RequirementNode | null {
    const all = this.getAllRequirements();
    const source = all.find((r) => r.id === id);
    if (!source) return null;

    const now = new Date().toISOString();
    const newId = `req-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
    const clonedReq: RequirementNode = {
      ...source,
      id: newId,
      reqCode: `${source.reqCode}-COPY`,
      title: `${source.title} (Copy)`,
      createdAt: now,
      updatedAt: now,
    };

    all.push(clonedReq);
    this.saveAllRequirements(all);
    return clonedReq;
  },

  /**
   * DELETE a requirement node.
   */
  deleteRequirement(id: string): void {
    const all = this.getAllRequirements();
    const remaining = all.filter((r) => r.id !== id);
    this.saveAllRequirements(remaining);
  },

  /**
   * BATCH DELETE requirements.
   */
  deleteRequirementsBatch(ids: string[]): void {
    const idSet = new Set(ids);
    const all = this.getAllRequirements();
    const remaining = all.filter((r) => !idSet.has(r.id));
    this.saveAllRequirements(remaining);
  },

  // =========================================================================
  // 4. WORKSPACE RESET, TEMPLATE LOADER & IMPORT/EXPORT
  // =========================================================================

  /**
   * RESET TO CLEAN SLATE: Clear all data completely (no dummy data).
   */
  clearAllData(): void {
    localStorage.removeItem(STORAGE_KEYS.PROJECTS);
    localStorage.removeItem(STORAGE_KEYS.ACTIVE_PROJECT_ID);
    localStorage.removeItem(STORAGE_KEYS.MENU_ITEMS);
    localStorage.removeItem(STORAGE_KEYS.REQUIREMENTS);
    triggerStorageUpdate();
  },

  /**
   * EXPLICIT TEMPLATE LOADER: Only called when the user explicitly requests to load a demo sample template.
   */
  loadDemoTemplate(): void {
    this.saveProjects(DEFAULT_PROJECTS);
    this.setActiveProjectId(DEFAULT_PROJECTS[0].id);
    this.saveAllMenuItems(DEFAULT_MENU_ITEMS);
    this.saveAllRequirements(DEFAULT_REQUIREMENTS);
    triggerStorageUpdate();
  },

  /**
   * Backward-compatibility alias
   */
  resetToDefault(): void {
    this.loadDemoTemplate();
  },

  /**
   * EXPORT Full Workspace Backup as formatted JSON.
   */
  exportFullWorkspaceJSON(): string {
    const payload = {
      version: '2.0.0-canonical',
      exportedAt: new Date().toISOString(),
      activeProjectId: this.getActiveProjectId(),
      projects: this.getProjects(),
      menuItems: this.getAllMenuItems(),
      requirements: this.getAllRequirements(),
    };
    return JSON.stringify(payload, null, 2);
  },

  /**
   * IMPORT Workspace Backup from JSON string.
   */
  importWorkspaceJSON(jsonString: string): boolean {
    try {
      const data = JSON.parse(jsonString);
      if (data.projects && Array.isArray(data.projects)) {
        this.saveProjects(data.projects);
      }
      if (data.menuItems && Array.isArray(data.menuItems)) {
        this.saveAllMenuItems(data.menuItems);
      }
      if (data.requirements && Array.isArray(data.requirements)) {
        this.saveAllRequirements(data.requirements);
      }
      if (data.activeProjectId) {
        this.setActiveProjectId(data.activeProjectId);
      } else if (data.projects && data.projects.length > 0) {
        this.setActiveProjectId(data.projects[0].id);
      }
      triggerStorageUpdate();
      return true;
    } catch (e) {
      console.error('Failed to import JSON workspace', e);
      return false;
    }
  },
};
