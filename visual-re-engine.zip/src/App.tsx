import { useState, useEffect, useCallback } from 'react';
import { ActiveView, MenuItem, Project, RequirementNode } from './types';
import { StorageService, STORAGE_EVENT } from './services/storageService';
import { Navbar } from './components/layout/Navbar';
import { Sidebar } from './components/layout/Sidebar';
import { DashboardView } from './components/views/DashboardView';
import { MenuConfiguratorView } from './components/views/MenuConfiguratorView';
import { RequirementBuilderView } from './components/views/RequirementBuilderView';
import { LogicInspectorView } from './components/views/LogicInspectorView';
import { WorkspaceView } from './components/views/WorkspaceView';
import { ExportHandoffView } from './components/views/ExportHandoffView';
import { HelpCenterView } from './components/views/HelpCenterView';

export default function App() {
  const [activeView, setActiveView] = useState<ActiveView>('menu_configurator');
  const [sidebarCollapsed, setSidebarCollapsed] = useState<boolean>(false);

  // Core Reactive Data State
  const [projects, setProjects] = useState<Project[]>(() => StorageService.getProjects());
  const [activeProjectId, setActiveProjectId] = useState<string>(() => StorageService.getActiveProjectId());
  const [menuItems, setMenuItems] = useState<MenuItem[]>(() => StorageService.getMenuItems());
  const [requirements, setRequirements] = useState<RequirementNode[]>(() => StorageService.getRequirements());

  // Deep Link Selection State
  const [builderFeatureAnchor, setBuilderFeatureAnchor] = useState<{
    moduleId?: string;
    menuId?: string;
    featureId?: string;
  }>({});
  const [diagramReqId, setDiagramReqId] = useState<string | undefined>();

  // Reload all state from LocalStorage
  const loadWorkspaceData = useCallback(() => {
    const projs = StorageService.getProjects();
    const activeId = StorageService.getActiveProjectId();
    const items = StorageService.getMenuItems(activeId);
    const reqs = StorageService.getRequirements(activeId);

    setProjects(projs);
    setActiveProjectId(activeId);
    setMenuItems(items);
    setRequirements(reqs);
  }, []);

  // Listen for storage events across views
  useEffect(() => {
    loadWorkspaceData();

    const handleStorageChange = () => {
      loadWorkspaceData();
    };

    window.addEventListener(STORAGE_EVENT, handleStorageChange);
    return () => {
      window.removeEventListener(STORAGE_EVENT, handleStorageChange);
    };
  }, [loadWorkspaceData]);

  // Project Switch Handler
  const handleSelectProject = (id: string) => {
    StorageService.setActiveProjectId(id);
    setActiveProjectId(id);
    setMenuItems(StorageService.getMenuItems(id));
    setRequirements(StorageService.getRequirements(id));
  };

  // Reset Data Handler
  const handleResetData = () => {
    if (window.confirm('Reset all projects and menu configurations to default enterprise demonstration data?')) {
      StorageService.resetToDefault();
      loadWorkspaceData();
    }
  };

  // Navigation Shortcut: From Menu Configurator Feature -> Requirement Builder
  const handleNavigateToBuilderWithFeature = (moduleId: string, menuId: string, featureId: string) => {
    setBuilderFeatureAnchor({ moduleId, menuId, featureId });
    setActiveView('req_builder');
  };

  // Navigation Shortcut: From Requirement -> Logic Diagram
  const handleNavigateToDiagram = (reqId?: string) => {
    setDiagramReqId(reqId);
    setActiveView('logic_diagram');
  };

  // Navigation Shortcut: From Diagram -> Edit in Requirement Builder
  const handleNavigateToBuilderFromDiagram = (req: RequirementNode) => {
    setBuilderFeatureAnchor({
      moduleId: req.moduleId,
      menuId: req.menuId,
      featureId: req.featureId,
    });
    setActiveView('req_builder');
  };

  // Direct Requirement Update (e.g. from Logic Gap Quick Fix)
  const handleUpdateRequirement = (updatedReq: RequirementNode) => {
    StorageService.saveRequirement(updatedReq);
    loadWorkspaceData();
  };

  const activeProject = projects.find((p) => p.id === activeProjectId) || projects[0];

  return (
    <div className="wrapper min-h-screen flex bg-[#f4f6f9] text-[#212529]">
      {/* AdminLTE 3 Dark Sidebar */}
      <Sidebar
        activeView={activeView}
        setActiveView={setActiveView}
        projects={projects}
        activeProject={activeProject}
        onSelectProject={handleSelectProject}
        totalRequirements={requirements.length}
        totalMenuItems={menuItems.length}
        collapsed={sidebarCollapsed}
      />

      {/* Main Content Wrapper */}
      <div className="content-wrapper flex-1 flex flex-col min-w-0 transition-all duration-300">
        {/* Top Navbar */}
        <Navbar
          activeView={activeView}
          setActiveView={setActiveView}
          projects={projects}
          activeProject={activeProject}
          onSelectProject={handleSelectProject}
          onToggleSidebar={() => setSidebarCollapsed(!sidebarCollapsed)}
          sidebarCollapsed={sidebarCollapsed}
          onResetData={handleResetData}
          totalRequirements={requirements.length}
          totalMenuItems={menuItems.length}
        />

        {/* Dynamic Main Content Container */}
        <main className="content p-4 sm:p-6 flex-1 max-w-7xl w-full mx-auto">
          {activeView === 'dashboard' && (
            <DashboardView
              activeProject={activeProject}
              menuItems={menuItems}
              requirements={requirements}
              setActiveView={setActiveView}
              onNavigateToBuilderWithFeature={handleNavigateToBuilderWithFeature}
            />
          )}

          {activeView === 'workspace' && (
            <WorkspaceView
              projects={projects}
              activeProject={activeProject}
              onSelectProject={handleSelectProject}
              onRefreshData={loadWorkspaceData}
            />
          )}

          {activeView === 'menu_configurator' && (
            <MenuConfiguratorView
              activeProject={activeProject}
              menuItems={menuItems}
              requirements={requirements}
              onRefreshData={loadWorkspaceData}
              onNavigateToBuilderWithFeature={handleNavigateToBuilderWithFeature}
              onNavigateToHelp={() => setActiveView('help_center')}
            />
          )}

          {activeView === 'req_builder' && (
            <RequirementBuilderView
              activeProject={activeProject}
              menuItems={menuItems}
              requirements={requirements}
              onRefreshData={loadWorkspaceData}
              onNavigateToDiagram={handleNavigateToDiagram}
              onNavigateToHelp={() => setActiveView('help_center')}
              initialModuleId={builderFeatureAnchor.moduleId}
              initialMenuId={builderFeatureAnchor.menuId}
              initialFeatureId={builderFeatureAnchor.featureId}
            />
          )}

          {activeView === 'logic_diagram' && (
            <LogicInspectorView
              activeProject={activeProject}
              menuItems={menuItems}
              requirements={requirements}
              selectedReqId={diagramReqId}
              onNavigateToBuilder={handleNavigateToBuilderFromDiagram}
              onUpdateRequirement={handleUpdateRequirement}
            />
          )}

          {activeView === 'export_center' && (
            <ExportHandoffView
              activeProject={activeProject}
              menuItems={menuItems}
              requirements={requirements}
            />
          )}

          {activeView === 'help_center' && (
            <HelpCenterView
              setActiveView={setActiveView}
              onNavigateToBuilderWithFeature={handleNavigateToBuilderWithFeature}
            />
          )}
        </main>

        {/* AdminLTE Footer */}
        <footer className="main-footer bg-white border-t border-gray-200 px-6 py-3 text-xs text-gray-500 flex flex-col sm:flex-row items-center justify-between gap-2">
          <div>
            <strong>Visual RE-Engine &copy; 2026</strong> — Visual System Requirement Gathering & Architecture Tool.
          </div>
          <div className="flex items-center gap-3 font-mono text-[11px]">
            <span className="flex items-center gap-1 text-emerald-600">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping inline-block"></span>
              AdminLTE 3 / Bootstrap 5 + Mermaid.js
            </span>
            <span>|</span>
            <span>LocalStorage Synced</span>
          </div>
        </footer>
      </div>
    </div>
  );
}
