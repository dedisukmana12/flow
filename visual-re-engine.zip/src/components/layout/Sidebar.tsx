import React from 'react';
import { ActiveView, Project } from '../../types';

interface SidebarProps {
  activeView: ActiveView;
  setActiveView: (view: ActiveView) => void;
  projects: Project[];
  activeProject?: Project;
  onSelectProject: (id: string) => void;
  totalRequirements: number;
  totalMenuItems: number;
  collapsed: boolean;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeView,
  setActiveView,
  projects,
  activeProject,
  onSelectProject,
  totalRequirements,
  totalMenuItems,
  collapsed,
}) => {
  const menuItemsList: {
    id: ActiveView;
    title: string;
    icon: string;
    badge?: string;
    badgeVariant?: string;
    highlight?: boolean;
  }[] = [
    {
      id: 'dashboard',
      title: 'Ringkasan / Beranda',
      icon: 'fa-solid fa-gauge-high',
      badge: 'Utama',
      badgeVariant: 'bg-blue-600',
    },
    {
      id: 'workspace',
      title: 'Ruang Kerja & Proyek',
      icon: 'fa-solid fa-folder-open',
      badge: `${projects.length} Proyek`,
      badgeVariant: 'bg-gray-600',
    },
    {
      id: 'menu_configurator',
      title: '1. Susun Menu Aplikasi (A)',
      icon: 'fa-solid fa-folder-tree',
      badge: 'Langkah 1',
      badgeVariant: 'bg-emerald-500 text-white font-bold',
      highlight: true,
    },
    {
      id: 'req_builder',
      title: '2. Catat Alur Kerja (B)',
      icon: 'fa-solid fa-bolt-lightning',
      badge: `${totalRequirements} Alur`,
      badgeVariant: 'bg-amber-500 text-gray-900 font-bold',
      highlight: true,
    },
    {
      id: 'logic_diagram',
      title: '3. Cek Alur & Diagram',
      icon: 'fa-solid fa-diagram-project',
      badge: 'Visual',
      badgeVariant: 'bg-[#17a2b8] text-white font-bold',
      highlight: true,
    },
    {
      id: 'export_center',
      title: '4. Pusat Unduh & Dokumen',
      icon: 'fa-solid fa-box-archive',
      badge: 'Siap Pakai',
      badgeVariant: 'bg-[#6f42c1] text-white font-bold',
    },
    {
      id: 'help_center',
      title: 'Panduan Penggunaan',
      icon: 'fa-solid fa-circle-question',
      badge: 'Bantuan',
      badgeVariant: 'bg-teal-500 text-white font-bold',
      highlight: true,
    },
  ];

  return (
    <aside
      className={`main-sidebar bg-[#343a40] text-[#c2c7d0] min-h-screen flex flex-col transition-all duration-300 z-40 select-none shadow-xl ${
        collapsed ? 'w-16' : 'w-64'
      }`}
    >
      {/* Brand Logo Header (AdminLTE 3 Style) */}
      <div className="brand-link flex items-center px-4 py-3.5 border-b border-[#4b545c] bg-[#343a40] text-white">
        <div className="w-8 h-8 rounded bg-[#007bff] flex items-center justify-center text-white font-bold text-sm shadow-xs flex-shrink-0">
          RE
        </div>
        {!collapsed && (
          <div className="ml-3 truncate">
            <span className="font-semibold text-base tracking-tight text-white">Visual RE-Engine</span>
            <span className="block text-[10px] text-[#c2c7d0] font-medium tracking-wider">
              Penyusun Kebutuhan Sistem
            </span>
          </div>
        )}
      </div>

      {/* Sidebar Content */}
      <div className="sidebar flex-1 flex flex-col overflow-y-auto px-2 py-3">
        {/* Active Project Switcher Widget */}
        {!collapsed ? (
          <div className="user-panel pb-3 mb-3 border-b border-[#4b545c] px-2">
            <div className="text-[11px] font-bold text-[#c2c7d0] uppercase tracking-wider mb-1.5 flex items-center justify-between">
              <span>Proyek Aktif</span>
              <span className="text-[10px] bg-green-900/60 text-green-300 px-1.5 py-0.2 rounded font-mono font-bold">AKTIF</span>
            </div>
            <div className="relative">
              <label htmlFor="sidebar-project-select" className="sr-only">Pilih Proyek Aktif</label>
              <select
                id="sidebar-project-select"
                value={activeProject?.id || ''}
                onChange={(e) => {
                  if (e.target.value === '__create_new__') {
                    setActiveView('workspace');
                  } else if (e.target.value) {
                    onSelectProject(e.target.value);
                  }
                }}
                className="w-full bg-[#4b545c] text-white border-none rounded px-2.5 py-1.5 text-xs outline-none focus:ring-1 focus:ring-blue-400 cursor-pointer font-medium truncate"
              >
                {projects.length === 0 ? (
                  <option value="">Belum ada proyek</option>
                ) : (
                  projects.map((p) => (
                    <option key={p.id} value={p.id} className="bg-[#343a40] text-white">
                      {p.name} ({p.code})
                    </option>
                  ))
                )}
                <option value="__create_new__" className="bg-[#343a40] text-white font-bold">
                  + Buat Proyek Baru...
                </option>
              </select>
            </div>
            <div className="text-[11px] text-[#c2c7d0] mt-1.5 truncate">
              <i className="fa-solid fa-cubes text-blue-400 mr-1"></i>
              {activeProject?.systemName || 'Sistem Terhubung'}
            </div>
          </div>
        ) : (
          <div className="pb-3 mb-3 border-b border-[#4b545c] text-center">
            <button
              type="button"
              onClick={() => setActiveView('workspace')}
              className="w-8 h-8 rounded bg-[#4b545c] hover:bg-[#494e53] text-white flex items-center justify-center mx-auto"
              title={activeProject?.name}
            >
              <i className="fa-solid fa-folder"></i>
            </button>
          </div>
        )}

        {/* Sidebar Menu Header */}
        {!collapsed && (
          <div className="px-3 py-1 text-[10px] font-bold text-[#c2c7d0] uppercase tracking-widest">
            Alat Perancang Alur
          </div>
        )}

        {/* Navigation Links */}
        <nav className="mt-1 flex-1 space-y-1">
          {menuItemsList.map((item) => {
            const isActive = activeView === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => setActiveView(item.id)}
                className={`w-full flex items-center rounded px-3 py-2 text-xs font-medium transition-all group cursor-pointer text-left ${
                  isActive
                    ? 'bg-[#007bff] text-white shadow-xs font-semibold'
                    : 'text-[#c2c7d0] hover:bg-[#494e53] hover:text-white'
                }`}
                title={collapsed ? item.title : undefined}
              >
                <i
                  className={`${item.icon} text-sm flex-shrink-0 ${
                    isActive ? 'text-white' : item.highlight ? 'text-amber-300' : 'text-[#c2c7d0] group-hover:text-white'
                  }`}
                  style={{ width: '20px' }}
                ></i>

                {!collapsed && (
                  <>
                    <span className="ml-2.5 flex-1 truncate">{item.title}</span>
                    {item.badge && (
                      <span
                        className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono font-medium ml-1.5 ${
                          isActive ? 'bg-white/20 text-white' : item.badgeVariant || 'bg-[#4b545c] text-white'
                        }`}
                      >
                        {item.badge}
                      </span>
                    )}
                  </>
                )}
              </button>
            );
          })}
        </nav>

        {/* Bottom System Status Widget */}
        {!collapsed && (
          <div className="mt-auto pt-3 border-t border-[#4b545c] px-2 text-xs text-[#c2c7d0]">
            <div className="bg-[#2b3035] rounded p-2.5 border border-[#4b545c]">
              <div className="flex justify-between items-center mb-1 text-[11px]">
                <span className="font-semibold text-gray-300">Kelengkapan Catatan</span>
                <span className="font-mono text-emerald-400 font-bold">
                  {Math.min(100, Math.round((totalRequirements / Math.max(1, totalMenuItems * 0.8)) * 100))}%
                </span>
              </div>
              <div className="w-full bg-[#4b545c] h-1.5 rounded-full overflow-hidden mb-2">
                <div
                  className="bg-[#28a745] h-full rounded-full transition-all duration-500"
                  style={{
                    width: `${Math.min(100, Math.round((totalRequirements / Math.max(1, totalMenuItems * 0.8)) * 100))}%`,
                  }}
                ></div>
              </div>
              <div className="flex items-center justify-between text-[10px] text-[#c2c7d0]">
                <span>{totalMenuItems} Menu/Tombol</span>
                <span>{totalRequirements} Alur Terdata</span>
              </div>
            </div>
            <div className="mt-2 text-center text-[10px] text-[#c2c7d0]/80">
              Visual RE-Engine v1.4
            </div>
          </div>
        )}
      </div>
    </aside>
  );
};
