import React from 'react';
import { ActiveView, Project } from '../../types';

interface NavbarProps {
  activeView: ActiveView;
  setActiveView: (view: ActiveView) => void;
  projects: Project[];
  activeProject?: Project;
  onSelectProject: (projectId: string) => void;
  onToggleSidebar: () => void;
  sidebarCollapsed: boolean;
  onResetData: () => void;
  totalRequirements: number;
  totalMenuItems: number;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeView,
  setActiveView,
  projects,
  activeProject,
  onSelectProject,
  onToggleSidebar,
  onResetData,
  totalRequirements,
  totalMenuItems,
}) => {
  return (
    <nav className="main-header navbar navbar-expand navbar-white navbar-light bg-white border-b border-[#e9ecef] px-4 py-2 flex items-center justify-between sticky top-0 z-30 shadow-[0_1px_3px_rgba(0,0,0,0.03)] h-14">
      {/* Left navbar links */}
      <div className="flex items-center gap-3">
        <button
          type="button"
          onClick={onToggleSidebar}
          className="p-1.5 rounded hover:bg-gray-100 text-gray-600 transition-colors cursor-pointer"
          title="Buka/Tutup Menu Samping"
        >
          <i className="fa-solid fa-bars text-lg"></i>
        </button>

        {/* Active Breadcrumb pill */}
        <div className="hidden sm:flex items-center gap-2 text-xs">
          <span className="text-[#6c757d] font-semibold">Proyek Aktif:</span>
          <div className="flex items-center bg-[#f8f9fa] border border-gray-200 rounded px-2.5 py-1 gap-1.5 font-semibold text-[#212529]">
            <i className="fa-solid fa-folder text-amber-500"></i>
            <span className="truncate max-w-[180px]">{activeProject?.name || 'Belum Ada Proyek'}</span>
            <span className="bg-[#007bff] text-white text-[10px] px-1.5 py-0.2 rounded font-mono font-bold">
              {activeProject?.code || 'SYS'}
            </span>
          </div>
        </div>
      </div>

      {/* Center View Switcher Quick Tabs (Desktop) */}
      <div className="hidden lg:flex items-center bg-[#f8f9fa] p-1 rounded border border-gray-200 text-xs font-semibold">
        <button
          type="button"
          onClick={() => setActiveView('menu_configurator')}
          className={`px-3 py-1 rounded transition-all flex items-center gap-1.5 cursor-pointer ${
            activeView === 'menu_configurator'
              ? 'bg-white text-[#007bff] shadow-xs'
              : 'text-gray-600 hover:text-gray-900'
          }`}
          title="Langkah A: Susun Menu & Struktur Aplikasi"
        >
          <i className="fa-solid fa-folder-tree text-amber-500"></i>
          <span>1. Susun Menu (A)</span>
          <span className="bg-amber-100 text-amber-800 text-[10px] px-1.5 rounded-full font-mono font-bold">
            {totalMenuItems}
          </span>
        </button>

        <button
          type="button"
          onClick={() => setActiveView('req_builder')}
          className={`px-3 py-1 rounded transition-all flex items-center gap-1.5 cursor-pointer ${
            activeView === 'req_builder'
              ? 'bg-white text-[#007bff] shadow-xs'
              : 'text-gray-600 hover:text-gray-900'
          }`}
          title="Langkah B: Catat Aturan & Cara Kerja Tiap Tombol"
        >
          <i className="fa-solid fa-bolt text-blue-500"></i>
          <span>2. Catat Alur Kerja (B)</span>
          <span className="bg-blue-100 text-blue-800 text-[10px] px-1.5 rounded-full font-mono font-bold">
            {totalRequirements}
          </span>
        </button>

        <button
          type="button"
          onClick={() => setActiveView('logic_diagram')}
          className={`px-3 py-1 rounded transition-all flex items-center gap-1.5 cursor-pointer ${
            activeView === 'logic_diagram'
              ? 'bg-white text-[#007bff] shadow-xs'
              : 'text-gray-600 hover:text-gray-900'
          }`}
          title="Lihat Gambar Alur & Cek Kelengkapan"
        >
          <i className="fa-solid fa-diagram-project text-cyan-600"></i>
          <span>3. Cek Alur & Gambar Diagram</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveView('export_center')}
          className={`px-3 py-1 rounded transition-all flex items-center gap-1.5 cursor-pointer ${
            activeView === 'export_center'
              ? 'bg-white text-[#007bff] shadow-xs'
              : 'text-gray-600 hover:text-gray-900'
          }`}
          title="Unduh Dokumen & Prompt Siap Pakai"
        >
          <i className="fa-solid fa-file-export text-purple-600"></i>
          <span>4. Unduh Dokumen & AI</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveView('help_center')}
          className={`px-3 py-1 rounded transition-all flex items-center gap-1.5 cursor-pointer ${
            activeView === 'help_center'
              ? 'bg-white text-teal-600 shadow-xs'
              : 'text-gray-600 hover:text-gray-900'
          }`}
          title="Buka Pusat Bantuan & Panduan Penggunaan"
        >
          <i className="fa-solid fa-circle-question text-teal-500"></i>
          <span>Panduan</span>
        </button>
      </div>

      {/* Right navbar links & actions */}
      <div className="flex items-center gap-2.5">
        {/* Help button for small screens */}
        <button
          type="button"
          onClick={() => setActiveView('help_center')}
          className={`px-2.5 py-1 rounded text-xs font-bold transition-all flex items-center gap-1 cursor-pointer border ${
            activeView === 'help_center'
              ? 'bg-teal-600 text-white border-teal-700'
              : 'bg-teal-50 text-teal-700 border-teal-200 hover:bg-teal-100'
          }`}
          title="Panduan Penggunaan Lengkap"
        >
          <i className="fa-solid fa-circle-question"></i>
          <span className="hidden sm:inline">Panduan</span>
        </button>
        {/* Status Indicator */}
        <span className="hidden md:inline-flex items-center gap-1.5 bg-green-50 border border-green-200 text-green-700 px-2.5 py-1 rounded-full text-[11px] font-bold tracking-wide">
          <span className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse"></span>
          Tersimpan Otomatis
        </span>

        {/* Project Switcher Dropdown */}
        <div className="relative flex items-center">
          <label htmlFor="navbar-project-select" className="sr-only">Pilih Proyek Aktif</label>
          <select
            id="navbar-project-select"
            value={activeProject?.id || ''}
            onChange={(e) => {
              if (e.target.value === '__create_new__') {
                setActiveView('workspace');
              } else if (e.target.value) {
                onSelectProject(e.target.value);
              }
            }}
            className="text-xs bg-white border border-gray-300 rounded px-2.5 py-1.5 font-semibold text-[#495057] hover:border-gray-400 focus:outline-none focus:ring-1 focus:ring-blue-500 cursor-pointer shadow-xs"
          >
            {projects.length === 0 ? (
              <option value="">Belum Ada Proyek (Klik untuk Buat)</option>
            ) : (
              projects.map((p) => (
                <option key={p.id} value={p.id}>
                  📁 {p.name} ({p.code})
                </option>
              ))
            )}
            <option value="__create_new__">+ Buat Proyek Baru...</option>
          </select>
        </div>

        {/* Quick Add Node Button */}
        <button
          type="button"
          onClick={() => setActiveView('req_builder')}
          className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 bg-[#28a745] hover:bg-[#218838] text-white text-xs font-bold rounded shadow-xs transition-colors cursor-pointer"
        >
          <i className="fa-solid fa-plus"></i>
          <span>+ Tambah Alur</span>
        </button>

        {/* Reset / Demo Data button */}
        <button
          type="button"
          onClick={onResetData}
          title="Muat Contoh Data / Mulai Bersih"
          className="p-1.5 text-gray-500 hover:text-gray-800 hover:bg-gray-100 rounded text-xs transition-colors cursor-pointer"
        >
          <i className="fa-solid fa-arrows-rotate"></i>
        </button>
      </div>
    </nav>
  );
};
