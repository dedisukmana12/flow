import React, { useState, useMemo } from 'react';
import { MenuItem, Project, RequirementNode } from '../../types';
import { AdminCard } from '../common/AdminCard';
import { MermaidViewer } from '../common/MermaidViewer';
import { compileToMermaid } from '../../utils/helpers';

interface ExportHandoffViewProps {
  activeProject?: Project;
  menuItems: MenuItem[];
  requirements: RequirementNode[];
}

export const ExportHandoffView: React.FC<ExportHandoffViewProps> = ({
  activeProject,
  menuItems,
  requirements,
}) => {
  // 3 Primary Tabs as per User Request: TAB 1: JSON Spec, TAB 2: User Stories & Gherkin AC, TAB 3: Mermaid Architecture Diagram
  const [activeTab, setActiveTab] = useState<'TAB_1_JSON' | 'TAB_2_GHERKIN' | 'TAB_3_MERMAID' | 'TAB_4_SRS'>('TAB_1_JSON');
  const [copied, setCopied] = useState<boolean>(false);
  const [mermaidSplitView, setMermaidSplitView] = useState<boolean>(true);

  // TAB 1: JSON Spec
  const jsonSpec = useMemo(() => {
    const dataContract = {
      specVersion: '1.4-canonical',
      generator: 'Visual RE-Engine Enterprise Compiler',
      exportedAt: new Date().toISOString(),
      project: {
        id: activeProject?.id || 'PROJ-DEFAULT',
        name: activeProject?.name || 'Enterprise System',
        code: activeProject?.code || 'SYS',
        systemName: activeProject?.systemName || 'Target App',
        description: activeProject?.description || '',
        targetTechStack: activeProject?.targetTechStack || 'Multi-Tech Stack',
        version: activeProject?.version || '1.0.0',
        author: activeProject?.author || 'Lead Software Architect',
      },
      hierarchy: {
        totalMenuItems: menuItems.length,
        nodes: menuItems.map((m) => ({
          id: m.id,
          code: m.code,
          name: m.name,
          level: m.level,
          parentId: m.parentId,
          icon: m.icon,
          order: m.order,
        })),
      },
      requirements: {
        totalRequirements: requirements.length,
        nodes: requirements.map((r) => ({
          id: r.id,
          reqCode: r.reqCode,
          title: r.title,
          hierarchyPath: {
            moduleId: r.moduleId,
            menuId: r.menuId,
            featureId: r.featureId,
          },
          flow6Fields: {
            who: r.whoRole,
            fromWhere: r.fromWhere,
            action: r.action,
            logic: r.logic,
            output: r.output,
            toWhere: r.toWhere,
            toWhereType: r.toWhereType,
          },
          branching: {
            hasBranching: r.hasBranching,
            branches: r.branches || [],
          },
          priority: r.priority,
          status: r.status,
          notes: r.notes,
        })),
      },
    };

    return JSON.stringify(dataContract, null, 2);
  }, [activeProject, menuItems, requirements]);

  // TAB 2: User Stories & Gherkin AC (Given-When-Then Markdown Document)
  const gherkinUserStories = useMemo(() => {
    const projName = activeProject?.name || 'Sistem Aplikasi';
    const projCode = activeProject?.code || 'SYS';

    let doc = `# Dokumen Cerita Pengguna & Syarat Pengujian (Gherkin)\n`;
    doc += `## Nama Proyek: ${projName} (${projCode})\n`;
    doc += `*Dibuat otomatis oleh Visual RE-Engine*\n\n`;
    doc += `Total Alur Tercatat: **${requirements.length} Cerita Pengguna**\n\n`;
    doc += `===================================================================================\n\n`;

    requirements.forEach((req, idx) => {
      const mod = menuItems.find((m) => m.id === req.moduleId);
      const mnu = menuItems.find((m) => m.id === req.menuId);
      const feat = menuItems.find((m) => m.id === req.featureId);

      doc += `### CP-${idx + 1}: [${req.reqCode}] ${req.title}\n\n`;
      doc += `**Jalur Menu:** \`${mod?.code || 'MOD'} › ${mnu?.code || 'MNU'} › ${feat?.code || 'FT'}\`  \n`;
      doc += `**Prioritas:** \`${req.priority}\` | **Status:** \`${req.status}\`\n\n`;

      doc += `#### 1. Pernyataan Alur Pengguna:\n`;
      doc += `> **Sebagai** ${req.whoRole},\n`;
      doc += `> **Dari Halaman** ${req.fromWhere},\n`;
      doc += `> **Ketika Saya Melakukan** ${req.action},\n`;
      doc += `> **Sistem Harus Memeriksa** ${req.logic},\n`;
      doc += `> **Sehingga Menghasilkan** ${req.output} dan berlanjut ke **${req.toWhere}**.\n\n`;

      doc += `#### 2. Kriteria Penerimaan / Uji (Format Gherkin):\n`;
      doc += `\`\`\`gherkin\n`;
      doc += `@kebutuhan=${req.reqCode} @prioritas=${req.priority.toLowerCase()}\n`;
      doc += `Fitur: ${req.title}\n\n`;
      doc += `  Skenario: Alur Utama Berhasil (Happy Path)\n`;
      doc += `    Dengan pengguna masuk sebagai "${req.whoRole}"\n`;
      doc += `    Dan pengguna berada di layar "${req.fromWhere}"\n`;
      doc += `    Ketika pengguna melakukan tindakan "${req.action}"\n`;
      doc += `    Maka sistem menjalankan aturan pengecekan:\n`;
      doc += `      """\n`;
      doc += `      ${req.logic}\n`;
      doc += `      """\n`;
      doc += `    Dan hasil utama "${req.output}" berhasil dikeluarkan\n`;
      doc += `    Dan layar diteruskan ke "${req.toWhere}" (${req.toWhereType})\n`;

      if (req.hasBranching && req.branches && req.branches.length > 0) {
        req.branches.forEach((br, bIdx) => {
          const isElse = br.label?.toLowerCase().includes('else') || br.condition.toLowerCase().includes('else') || br.condition.toLowerCase().includes('gagal');
          doc += `\n  Skenario: ${isElse ? 'Jalur Penanganan Gagal / Pengecualian' : `Kondisi Khusus ${bIdx + 1}`} - ${br.label || 'Kondisi'}\n`;
          doc += `    Dengan pengguna berada di "${req.fromWhere}"\n`;
          doc += `    Ketika terjadi kondisi: "${br.condition}"\n`;
          doc += `    Maka sistem menghentikan alur utama normal\n`;
          doc += `    Dan menampilkan hasil alternatif: "${br.output}"\n`;
          doc += `    Dan mengarahkan alur ke: "${br.toWhere}"\n`;
        });
      }
      doc += `\`\`\`\n\n`;
      doc += `---\n\n`;
    });

    return doc;
  }, [activeProject, menuItems, requirements]);

  // TAB 3: Mermaid Architecture Diagram Code
  const mermaidDiagramCode = useMemo(() => {
    return compileToMermaid(
      { requirements, menuItems, project: activeProject },
      { direction: 'TD', styleMode: 'CANONICAL' }
    );
  }, [requirements, menuItems, activeProject]);

  // TAB 4 (Bonus): Markdown SRS Specification Document
  const markdownSRS = useMemo(() => {
    const projName = activeProject?.name || 'Sistem Aplikasi';
    const projCode = activeProject?.code || 'SYS';
    const projDesc = activeProject?.description || '';
    const author = activeProject?.author || 'Pengembang / Pemilik Proyek';
    const version = activeProject?.version || '1.0.0';

    const projTechStack = activeProject?.targetTechStack || 'Multi-Tech Stack';

    let doc = `# Dokumen Spesifikasi Kebutuhan Aplikasi (SRS)\n`;
    doc += `## Sistem: ${projName} (${projCode}) - v${version}\n`;
    doc += `**Penyusun:** ${author} | **Dihasilkan oleh:** Visual RE-Engine | **Tanggal:** ${new Date().toISOString().split('T')[0]}\n\n`;
    doc += `### 1. Ringkasan & Rencana Arsitektur Teknologi\n`;
    doc += `- **Deskripsi Aplikasi:** ${projDesc || 'Belum ada deskripsi singkat proyek.'}\n`;
    doc += `- **Rencana Teknologi & Bahasa Target:** \`${projTechStack}\`\n\n`;

    doc += `### 2. Susunan Menu & Struktur Aplikasi\n`;
    const modules = menuItems.filter((m) => m.level === 2);
    const menus = menuItems.filter((m) => m.level === 3);
    const features = menuItems.filter((m) => m.level === 4);

    doc += `- **Modul / Bagian Utama (Tingkat 2):** ${modules.length} bagian\n`;
    doc += `- **Menu / Formulir (Tingkat 3):** ${menus.length} menu\n`;
    doc += `- **Tombol & Fitur Khusus (Tingkat 4):** ${features.length} fitur\n\n`;

    doc += `### 3. Rincian Alur Kerja 6 Pertanyaan (SIAPA - DARI MANA - TINDAKAN - ATURAN - HASIL - TUJUAN)\n\n`;

    requirements.forEach((req, idx) => {
      doc += `#### 3.${idx + 1}. [${req.reqCode}] ${req.title}\n`;
      doc += `- **[1] SIAPA (Pengguna / Peran):** ${req.whoRole}\n`;
      doc += `- **[2] DARI MANA (Halaman / Layar Asal):** ${req.fromWhere}\n`;
      doc += `- **[3] TINDAKAN (Aksi / Tombol):** ${req.action}\n`;
      doc += `- **[4] ATURAN (Pengecekan / Validasi):** ${req.logic}\n`;
      doc += `- **[5] HASIL (Output Saat Sukses):** ${req.output}\n`;
      doc += `- **[6] TUJUAN (Pindah Layar / Simpan):** ${req.toWhere}\n`;

      if (req.hasBranching && req.branches && req.branches.length > 0) {
        doc += `- **Jalur Kondisi Khusus / Gagal (If / Else):**\n`;
        req.branches.forEach((b, bIdx) => {
          doc += `  - **Kondisi ${bIdx + 1} (${b.label}):** JIKA \`${b.condition}\` ➔ HASIL: ${b.output} ➔ TUJUAN: ${b.toWhere}\n`;
        });
      }
      doc += `\n---\n\n`;
    });

    return doc;
  }, [activeProject, menuItems, requirements]);

  // Active text selector for copying and general downloads
  const activeContent = useMemo(() => {
    switch (activeTab) {
      case 'TAB_1_JSON':
        return jsonSpec;
      case 'TAB_2_GHERKIN':
        return gherkinUserStories;
      case 'TAB_3_MERMAID':
        return mermaidDiagramCode;
      case 'TAB_4_SRS':
        return markdownSRS;
    }
  }, [activeTab, jsonSpec, gherkinUserStories, mermaidDiagramCode, markdownSRS]);

  const handleCopy = () => {
    navigator.clipboard.writeText(activeContent);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    let filename = `export-${Date.now()}`;
    let mime = 'text/plain';

    if (activeTab === 'TAB_1_JSON') {
      filename = `${activeProject?.code || 'RE'}-Spec-DataContract.json`;
      mime = 'application/json';
    } else if (activeTab === 'TAB_2_GHERKIN') {
      filename = `${activeProject?.code || 'RE'}-UserStories-Gherkin.md`;
      mime = 'text/markdown';
    } else if (activeTab === 'TAB_3_MERMAID') {
      filename = `${activeProject?.code || 'RE'}-Architecture-Diagram.mmd`;
      mime = 'text/plain';
    } else if (activeTab === 'TAB_4_SRS') {
      filename = `${activeProject?.code || 'RE'}-SRS-Specification.md`;
      mime = 'text/markdown';
    }

    const blob = new Blob([activeContent], { type: mime });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

    return (
    <div className="export-handoff-view space-y-4">
      {/* Header Banner */}
      <div className="bg-white p-4 rounded-[4px] border border-[#e9ecef] shadow-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-3">
        <div>
          <div className="flex items-center gap-2">
            <span className="bg-[#6f42c1] text-white text-xs font-bold px-2 py-0.5 rounded">
              LANGKAH 4
            </span>
            <h1 className="text-xl font-bold text-gray-900 tracking-tight">
              Pusat Unduh & Berkas Siap Pakai
            </h1>
          </div>
          <p className="text-xs text-gray-600 mt-1">
            Unduh rancangan alur kerja aplikasi dalam berbagai format siap pakai: Berkas Data JSON, Cerita Pengguna (User Stories & Syarat Terima), Diagram Visual Arsitektur, serta Dokumen Kebutuhan Aplikasi Lengkap (SRS).
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handleCopy}
            className="px-3.5 py-1.5 bg-[#007bff] hover:bg-[#0069d9] text-white text-xs font-bold rounded shadow-xs transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <i className={`fa-solid ${copied ? 'fa-check' : 'fa-copy'}`}></i>
            <span>{copied ? 'Tersalin ke Clipboard!' : activeTab === 'TAB_1_JSON' ? 'Salin JSON' : 'Salin Teks'}</span>
          </button>

          <button
            type="button"
            onClick={handleDownload}
            className="px-3.5 py-1.5 bg-[#28a745] hover:bg-[#218838] text-white text-xs font-bold rounded shadow-xs transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <i className="fa-solid fa-file-arrow-down"></i>
            <span>
              {activeTab === 'TAB_1_JSON'
                ? 'Unduh Berkas JSON'
                : activeTab === 'TAB_2_GHERKIN'
                ? 'Unduh Dokumen Markdown'
                : activeTab === 'TAB_3_MERMAID'
                ? 'Unduh Berkas Diagram (.mmd)'
                : 'Unduh Dokumen SRS'}
            </span>
          </button>
        </div>
      </div>

      {/* 3 Core Tab Options */}
      <AdminCard
        title="Pilihan Format Dokumen yang Dihasilkan"
        icon="fa-solid fa-boxes-packing"
        variant="outline-primary"
      >
        <div className="flex flex-wrap items-center justify-between border-b border-gray-200 pb-3 mb-3 gap-2">
          <div className="flex flex-wrap gap-2 text-xs font-bold">
            {/* TAB 1: JSON Spec */}
            <button
              type="button"
              onClick={() => setActiveTab('TAB_1_JSON')}
              className={`px-3.5 py-2 rounded transition-all flex items-center gap-2 cursor-pointer ${
                activeTab === 'TAB_1_JSON'
                  ? 'bg-[#007bff] text-white shadow-xs'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              <i className="fa-solid fa-brackets-curly text-amber-300"></i>
              <span>1. Data Mentah (JSON)</span>
              <span className="text-[10px] bg-black/20 px-1.5 py-0.2 rounded font-mono">
                {requirements.length} Alur
              </span>
            </button>

            {/* TAB 2: User Stories & Gherkin AC */}
            <button
              type="button"
              onClick={() => setActiveTab('TAB_2_GHERKIN')}
              className={`px-3.5 py-2 rounded transition-all flex items-center gap-2 cursor-pointer ${
                activeTab === 'TAB_2_GHERKIN'
                  ? 'bg-[#007bff] text-white shadow-xs'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              <i className="fa-solid fa-list-check text-green-300"></i>
              <span>2. Cerita Pengguna & Skenario Uji</span>
              <span className="text-[10px] bg-black/20 px-1.5 py-0.2 rounded font-mono">
                Siap Jira/QA
              </span>
            </button>

            {/* TAB 3: Mermaid Architecture Diagram */}
            <button
              type="button"
              onClick={() => setActiveTab('TAB_3_MERMAID')}
              className={`px-3.5 py-2 rounded transition-all flex items-center gap-2 cursor-pointer ${
                activeTab === 'TAB_3_MERMAID'
                  ? 'bg-[#007bff] text-white shadow-xs'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              <i className="fa-solid fa-diagram-project text-cyan-300"></i>
              <span>3. Diagram Visual (Mermaid)</span>
              <span className="text-[10px] bg-black/20 px-1.5 py-0.2 rounded font-mono">
                Gambar Alur
              </span>
            </button>

            {/* TAB 4: Markdown SRS */}
            <button
              type="button"
              onClick={() => setActiveTab('TAB_4_SRS')}
              className={`px-3 py-2 rounded transition-all flex items-center gap-1.5 cursor-pointer ${
                activeTab === 'TAB_4_SRS'
                  ? 'bg-[#007bff] text-white shadow-xs'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              <i className="fa-solid fa-file-lines text-purple-300"></i>
              <span>4. Dokumen Lengkap (SRS/BRD)</span>
            </button>
          </div>

          {/* Special Toggle for Mermaid Tab */}
          {activeTab === 'TAB_3_MERMAID' && (
            <div className="flex items-center gap-2 text-xs">
              <span className="text-gray-600 font-semibold">Tampilan:</span>
              <button
                type="button"
                onClick={() => setMermaidSplitView(!mermaidSplitView)}
                className={`px-2.5 py-1 rounded text-xs font-bold border transition-colors cursor-pointer ${
                  mermaidSplitView
                    ? 'bg-blue-50 border-blue-300 text-blue-700'
                    : 'bg-gray-100 border-gray-300 text-gray-700'
                }`}
              >
                <i className={`fa-solid ${mermaidSplitView ? 'fa-columns' : 'fa-code'} mr-1`}></i>
                {mermaidSplitView ? 'Berdampingan (Teks + Gambar)' : 'Hanya Teks Kode'}
              </button>
            </div>
          )}
        </div>

        {/* Tab Content Display */}
        {activeTab === 'TAB_1_JSON' && (
          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs text-gray-600 px-1">
              <span>
                Format data terstandarisasi yang berisi identitas Proyek, Susunan Menu 4 Tingkat, dan Alur Kerja 6 Pertanyaan.
              </span>
              <span className="font-mono text-emerald-700 font-bold bg-green-50 px-2 py-0.5 rounded border border-green-200">
                Format Standar Terverifikasi
              </span>
            </div>
            <pre className="p-4 bg-[#1e2227] text-[#abb2bf] rounded text-xs font-mono max-h-[600px] overflow-auto whitespace-pre-wrap leading-relaxed border border-gray-800 shadow-inner">
              {jsonSpec}
            </pre>
          </div>
        )}

        {activeTab === 'TAB_2_GHERKIN' && (
          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs text-gray-600 px-1">
              <span>
                Penulisan alur pengguna dalam bahasa sederhana beserta skenario uji (JIKA-KETIKA-MAKA) untuk tim penguji/QA atau panduan AI pengkodean.
              </span>
              <span className="font-mono text-blue-700 font-bold bg-blue-50 px-2 py-0.5 rounded border border-blue-200">
                Skenario Uji Siap Pakai
              </span>
            </div>
            <pre className="p-4 bg-[#1e2227] text-[#98c379] rounded text-xs font-mono max-h-[600px] overflow-auto whitespace-pre-wrap leading-relaxed border border-gray-800 shadow-inner">
              {gherkinUserStories}
            </pre>
          </div>
        )}

        {activeTab === 'TAB_3_MERMAID' && (
          <div className="space-y-3">
            <div className="flex items-center justify-between text-xs text-gray-600 px-1">
              <span>
                Teks bagan alur Mermaid.js. Dapat disalin ke Notion, GitHub, atau diunduh sebagai gambar diagram alur arsitektur.
              </span>
              <div className="flex items-center gap-2">
                <span className="font-mono text-cyan-800 font-bold bg-cyan-50 px-2 py-0.5 rounded border border-cyan-200">
                  Kompatibel Mermaid v10
                </span>
              </div>
            </div>

            {mermaidSplitView ? (
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
                {/* Raw Code Block */}
                <div className="lg:col-span-5 space-y-2">
                  <div className="flex items-center justify-between text-xs font-bold text-gray-700">
                    <span>Teks Kode Mermaid:</span>
                    <button
                      type="button"
                      onClick={handleCopy}
                      className="text-blue-600 hover:underline text-[11px]"
                    >
                      <i className="fa-solid fa-copy mr-1"></i>Salin Teks
                    </button>
                  </div>
                  <pre className="p-3.5 bg-[#1e2227] text-[#61afef] rounded text-xs font-mono max-h-[500px] overflow-auto whitespace-pre-wrap leading-relaxed border border-gray-800">
                    {mermaidDiagramCode}
                  </pre>
                </div>

                {/* Live Rendered Canvas with Download SVG Button */}
                <div className="lg:col-span-7 min-h-[500px]">
                  <MermaidViewer chart={mermaidDiagramCode} className="h-full min-h-[500px]" />
                </div>
              </div>
            ) : (
              <pre className="p-4 bg-[#1e2227] text-[#61afef] rounded text-xs font-mono max-h-[600px] overflow-auto whitespace-pre-wrap leading-relaxed border border-gray-800 shadow-inner">
                {mermaidDiagramCode}
              </pre>
            )}
          </div>
        )}

        {activeTab === 'TAB_4_SRS' && (
          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs text-gray-600 px-1">
              <span>
                Dokumen Spesifikasi Kebutuhan Perangkat Lunak (SRS) lengkap dan rapi, siap untuk presentasi ke klien, atasan, atau pemangku kepentingan.
              </span>
            </div>
            <pre className="p-4 bg-[#1e2227] text-[#e5c07b] rounded text-xs font-mono max-h-[600px] overflow-auto whitespace-pre-wrap leading-relaxed border border-gray-800 shadow-inner">
              {markdownSRS}
            </pre>
          </div>
        )}
      </AdminCard>
    </div>
  );
};
