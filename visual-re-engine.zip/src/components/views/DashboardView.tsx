import React from 'react';
import { ActiveView, MenuItem, Project, RequirementNode } from '../../types';
import { AdminCard } from '../common/AdminCard';
import { InfoBox } from '../common/InfoBox';

interface DashboardViewProps {
  activeProject?: Project;
  menuItems: MenuItem[];
  requirements: RequirementNode[];
  setActiveView: (view: ActiveView) => void;
  onNavigateToBuilderWithFeature?: (moduleId: string, menuId: string, featureId: string) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  activeProject,
  menuItems,
  requirements,
  setActiveView,
}) => {
  const l1Systems = menuItems.filter((m) => m.level === 1);
  const l2Modules = menuItems.filter((m) => m.level === 2);
  const l3Menus = menuItems.filter((m) => m.level === 3);
  const l4Features = menuItems.filter((m) => m.level === 4);

  const branchingReqs = requirements.filter((r) => r.hasBranching);
  const criticalReqs = requirements.filter((r) => r.priority === 'CRITICAL');
  const approvedReqs = requirements.filter((r) => r.status === 'APPROVED');

  const totalBranches = requirements.reduce((acc, r) => acc + (r.branches?.length || 0), 0);

  // Calculate coverage: how many features have at least 1 requirement node
  const featuresWithReqs = l4Features.filter((ft) =>
    requirements.some((r) => r.featureId === ft.id)
  );
  const coveragePercent = l4Features.length > 0 ? Math.round((featuresWithReqs.length / l4Features.length) * 100) : 0;

  return (
    <div className="dashboard-view space-y-4">
      {/* Welcome Banner */}
      <div className="bg-gradient-to-r from-[#1f2937] to-[#374151] rounded-[4px] p-5 text-white shadow-md flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="bg-blue-500 text-white text-[11px] font-bold px-2 py-0.5 rounded font-mono">
              PROYEK AKTIF
            </span>
            <span className="text-gray-300 text-xs font-mono">{activeProject?.code}</span>
          </div>
          <h1 className="text-2xl font-bold tracking-tight">
            {activeProject?.name || 'Beranda Penyusun Alur Aplikasi'}
          </h1>
          <p className="text-xs text-gray-300 mt-1 max-w-2xl">
            {activeProject?.description ||
              'Ruang kerja visual untuk merancang struktur menu dan alur kerja aplikasi secara mudah, rapi, dan siap diberikan ke pembuat program atau AI.'}
          </p>

          {activeProject?.targetTechStack && (
            <div className="flex flex-wrap items-center gap-1.5 mt-2.5">
              <span className="text-[11px] text-gray-400 font-semibold flex items-center gap-1">
                <i className="fa-solid fa-layer-group text-blue-400"></i>
                <span>Teknologi:</span>
              </span>
              {activeProject.targetTechStack
                .split(/[,+]/)
                .map((s) => s.trim())
                .filter((s) => s.length > 0)
                .map((tech) => (
                  <span
                    key={tech}
                    className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold bg-gray-700/80 text-blue-300 border border-gray-600"
                  >
                    <i className="fa-solid fa-code text-[8px]"></i>
                    <span>{tech}</span>
                  </span>
                ))}
            </div>
          )}
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => setActiveView('help_center')}
            className="px-3.5 py-2 bg-teal-500 hover:bg-teal-600 text-white font-bold text-xs rounded shadow-xs transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <i className="fa-solid fa-circle-question"></i>
            <span>Panduan Penggunaan</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveView('menu_configurator')}
            className="px-3.5 py-2 bg-amber-500 hover:bg-amber-600 text-gray-900 font-bold text-xs rounded shadow-xs transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <i className="fa-solid fa-folder-tree"></i>
            <span>1. Susun Menu (Langkah A)</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveView('req_builder')}
            className="px-3.5 py-2 bg-[#28a745] hover:bg-[#218838] text-white font-bold text-xs rounded shadow-xs transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <i className="fa-solid fa-bolt"></i>
            <span>2. Catat Alur Kerja (Langkah B)</span>
          </button>
        </div>
      </div>

      {/* METRIC INFOBOXES (AdminLTE 3 Style) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <InfoBox
          title="Sistem Utama (Tingkat 1)"
          value={l1Systems.length}
          icon="fa-solid fa-server"
          variant="primary"
          subtitle={`${l2Modules.length} Bagian Modul Terdaftar`}
          onClick={() => setActiveView('menu_configurator')}
        />

        <InfoBox
          title="Total Tombol & Fitur (Tingkat 4)"
          value={l4Features.length}
          icon="fa-solid fa-bolt"
          variant="info"
          subtitle={`${featuresWithReqs.length} Sudah Dibuatkan Alur`}
          progressPercent={coveragePercent}
          progressDescription="Kelengkapan Alur Fitur"
          onClick={() => setActiveView('menu_configurator')}
        />

        <InfoBox
          title="Total Alur Kerja Tercatat"
          value={requirements.length}
          icon="fa-solid fa-code-branch"
          variant="success"
          subtitle={`${branchingReqs.length} Alur Memiliki Kondisi Khusus / Gagal`}
          onClick={() => setActiveView('req_builder')}
        />

        <InfoBox
          title="Jalur Alur Penting (Kritis)"
          value={criticalReqs.length}
          icon="fa-solid fa-triangle-exclamation"
          variant="danger"
          subtitle={`${approvedReqs.length} Sudah Disetujui & Siap Dibuat`}
          onClick={() => setActiveView('logic_diagram')}
        />
      </div>

      {/* WORKFLOW PIPELINE & RECENT REQUIREMENTS */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Left: 6-Field Flow Architecture Guide */}
        <div className="lg:col-span-6">
          <AdminCard
            title="Panduan Alur 6 Pertanyaan Kerja"
            icon="fa-solid fa-diagram-project"
            variant="outline-primary"
          >
            <div className="space-y-3 text-xs">
              <p className="text-gray-600">
                Setiap fungsi atau tombol di aplikasi dijelaskan dengan 6 pertanyaan sederhana agar tidak terjadi salah paham:
              </p>

              {/* Step Flow Pills */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                <div className="p-2.5 bg-blue-50 rounded border border-blue-200">
                  <div className="flex items-center gap-1.5 font-bold text-blue-900 mb-1">
                    <span className="w-4 h-4 rounded-full bg-blue-600 text-white flex items-center justify-center text-[10px]">
                      1
                    </span>
                    <span>1. SIAPA (Pengguna)</span>
                  </div>
                  <p className="text-gray-600 text-[11px]">
                    Siapa yang menjalankan tombol/fitur ini (misal: Guru, Dokter, Kasir, Admin, Siswa).
                  </p>
                </div>

                <div className="p-2.5 bg-gray-50 rounded border border-gray-300">
                  <div className="flex items-center gap-1.5 font-bold text-gray-800 mb-1">
                    <span className="w-4 h-4 rounded-full bg-gray-600 text-white flex items-center justify-center text-[10px]">
                      2
                    </span>
                    <span>2. DARI MANA (Halaman Asal)</span>
                  </div>
                  <p className="text-gray-600 text-[11px]">
                    Halaman, formulir, atau layar tempat pengguna sedang berada saat tombol ditekan.
                  </p>
                </div>

                <div className="p-2.5 bg-green-50 rounded border border-green-200">
                  <div className="flex items-center gap-1.5 font-bold text-green-900 mb-1">
                    <span className="w-4 h-4 rounded-full bg-green-600 text-white flex items-center justify-center text-[10px]">
                      3
                    </span>
                    <span>3. TINDAKAN (Tombol / Aksi)</span>
                  </div>
                  <p className="text-gray-600 text-[11px]">
                    Aksi yang dilakukan pengguna (misal: Klik tombol "Simpan Pasien", Unggah berkas nilai).
                  </p>
                </div>

                <div className="p-2.5 bg-amber-50 rounded border border-amber-200">
                  <div className="flex items-center gap-1.5 font-bold text-amber-900 mb-1">
                    <span className="w-4 h-4 rounded-full bg-amber-500 text-gray-900 flex items-center justify-center text-[10px]">
                      4
                    </span>
                    <span>4. ATURAN (Pengecekan)</span>
                  </div>
                  <p className="text-gray-600 text-[11px]">
                    Syarat yang harus lolos sebelum diproses (misal: Cek nomor NIK, pastikan data tidak kosong).
                  </p>
                </div>

                <div className="p-2.5 bg-cyan-50 rounded border border-cyan-200">
                  <div className="flex items-center gap-1.5 font-bold text-cyan-900 mb-1">
                    <span className="w-4 h-4 rounded-full bg-cyan-600 text-white flex items-center justify-center text-[10px]">
                      5
                    </span>
                    <span>5. HASIL (Saat Berhasil)</span>
                  </div>
                  <p className="text-gray-600 text-[11px]">
                    Apa yang terjadi jika data lolos (misal: Data tersimpan, nomor antrean keluar, tiket terbit).
                  </p>
                </div>

                <div className="p-2.5 bg-purple-50 rounded border border-purple-200">
                  <div className="flex items-center gap-1.5 font-bold text-purple-900 mb-1">
                    <span className="w-4 h-4 rounded-full bg-purple-600 text-white flex items-center justify-center text-[10px]">
                      6
                    </span>
                    <span>6. TUJUAN & KONDISI LAIN</span>
                  </div>
                  <p className="text-gray-600 text-[11px]">
                    Pindah ke layar mana setelahnya, dan apa tindakannya jika syarat gagal atau data salah.
                  </p>
                </div>
              </div>

              {/* Quick Link Button */}
              <div className="pt-2 flex justify-end">
                <button
                  type="button"
                  onClick={() => setActiveView('logic_diagram')}
                  className="px-3 py-1.5 bg-[#17a2b8] hover:bg-[#138496] text-white text-xs font-semibold rounded shadow-xs flex items-center gap-1.5 cursor-pointer"
                >
                  <i className="fa-solid fa-diagram-project"></i>
                  <span>Lihat Diagram Alur & Periksa Kelengkapan</span>
                </button>
              </div>
            </div>
          </AdminCard>
        </div>

        {/* Right: Recent Requirements List */}
        <div className="lg:col-span-6">
          <AdminCard
            title="Daftar Alur Kerja Terakhir"
            icon="fa-solid fa-list-check"
            variant="outline-success"
            tools={
              <button
                type="button"
                onClick={() => setActiveView('req_builder')}
                className="px-2 py-0.5 text-xs bg-green-50 text-green-700 hover:bg-green-100 rounded border border-green-200 font-semibold cursor-pointer"
              >
                + Tambah Alur
              </button>
            }
          >
            <div className="space-y-2.5 max-h-[360px] overflow-y-auto pr-1 text-xs">
              {requirements.length === 0 ? (
                <div className="text-center py-8 bg-gray-50 rounded border border-dashed border-gray-300 text-gray-500 space-y-2">
                  <i className="fa-solid fa-code-branch text-gray-400 text-2xl"></i>
                  <p className="font-semibold text-gray-700">Belum Ada Catatan Alur Kerja</p>
                  <p className="text-[11px] text-gray-500 max-w-xs mx-auto">
                    Mulai dengan menyusun Menu Aplikasi (Langkah A), lalu catat bagaimana tombol bekerja pada Alur Kerja (Langkah B).
                  </p>
                  <button
                    type="button"
                    onClick={() => setActiveView('req_builder')}
                    className="mt-2 px-3 py-1 bg-[#28a745] hover:bg-[#218838] text-white text-xs font-bold rounded shadow-xs cursor-pointer"
                  >
                    + Buat Alur Pertama
                  </button>
                </div>
              ) : (
                requirements.map((r) => (
                  <div
                    key={r.id}
                    onClick={() => setActiveView('req_builder')}
                    className="p-2.5 bg-gray-50 hover:bg-blue-50/60 rounded border border-gray-200 transition-all cursor-pointer"
                  >
                    <div className="flex items-center justify-between mb-1">
                      <div className="flex items-center gap-1.5">
                        <span className="bg-blue-600 text-white font-mono text-[10px] font-bold px-1.5 py-0.2 rounded">
                          {r.reqCode}
                        </span>
                        <span className="font-semibold text-gray-900 truncate max-w-[220px]">
                          {r.title}
                        </span>
                      </div>

                      <div className="flex items-center gap-1">
                        {r.hasBranching && (
                          <span className="bg-purple-100 text-purple-800 text-[10px] font-bold px-1.5 rounded-full">
                            {r.branches.length} Kondisi
                          </span>
                        )}
                        <span
                          className={`text-[9px] font-bold px-1.5 rounded uppercase ${
                            r.priority === 'CRITICAL'
                              ? 'bg-red-600 text-white'
                              : r.priority === 'HIGH'
                              ? 'bg-orange-500 text-white'
                              : 'bg-gray-200 text-gray-700'
                          }`}
                        >
                          {r.priority === 'CRITICAL' ? 'Sangat Penting' : r.priority === 'HIGH' ? 'Tinggi' : r.priority === 'MEDIUM' ? 'Sedang' : 'Rendah'}
                        </span>
                      </div>
                    </div>

                    <div className="text-[11px] text-gray-600 truncate">
                      <span className="text-blue-700 font-medium">{r.whoRole}</span>: {r.action}
                    </div>
                  </div>
                ))
              )}
            </div>
          </AdminCard>
        </div>
      </div>
    </div>
  );
};
