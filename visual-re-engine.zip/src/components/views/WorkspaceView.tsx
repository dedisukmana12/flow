import React, { useState, useEffect, useMemo } from 'react';
import { Project } from '../../types';
import { AdminCard } from '../common/AdminCard';
import { StorageService } from '../../services/storageService';

interface WorkspaceViewProps {
  projects: Project[];
  activeProject?: Project;
  onSelectProject: (id: string) => void;
  onRefreshData: () => void;
}

export const TECH_CATEGORIES = [
  {
    category: '🌐 Frontend & Web UI',
    icon: 'fa-solid fa-desktop',
    color: 'border-blue-500 text-blue-800 bg-blue-50',
    items: [
      'React.js',
      'Next.js',
      'Vue.js',
      'Angular',
      'Svelte',
      'Tailwind CSS',
      'Bootstrap',
      'HTML5 / Vanilla JS',
    ],
  },
  {
    category: '📱 Aplikasi Mobile / HP',
    icon: 'fa-solid fa-mobile-screen',
    color: 'border-emerald-500 text-emerald-800 bg-emerald-50',
    items: [
      'Flutter (Android & iOS)',
      'React Native',
      'Kotlin (Android Native)',
      'Swift (iOS Native)',
      'PWA (Progressive Web App)',
    ],
  },
  {
    category: '⚙️ Server / Backend & API',
    icon: 'fa-solid fa-server',
    color: 'border-purple-500 text-purple-800 bg-purple-50',
    items: [
      'Node.js (Express)',
      'NestJS (TypeScript)',
      'Python (FastAPI)',
      'Python (Django)',
      'PHP (Laravel)',
      'Go (Golang)',
      'Java (Spring Boot)',
      'C# (.NET Core)',
    ],
  },
  {
    category: '🗄️ Basis Data (Database)',
    icon: 'fa-solid fa-database',
    color: 'border-amber-500 text-amber-800 bg-amber-50',
    items: [
      'PostgreSQL',
      'MySQL / MariaDB',
      'Firebase Firestore',
      'Supabase',
      'MongoDB',
      'SQLite (Lokal)',
      'Redis Cache',
    ],
  },
  {
    category: '🤖 AI, Cloud & Integrasi',
    icon: 'fa-solid fa-brain',
    color: 'border-cyan-500 text-cyan-800 bg-cyan-50',
    items: [
      'Google Gemini AI API',
      'OpenAI GPT API',
      'Google Cloud / Cloud Run',
      'AWS Cloud Services',
      'Docker Container',
      'Payment Gateway (Midtrans/Xendit)',
    ],
  },
  {
    category: '📊 Spreadsheet, No-Code & Desktop',
    icon: 'fa-solid fa-table-cells',
    color: 'border-teal-500 text-teal-800 bg-teal-50',
    items: [
      'Google Sheets (AppSheet)',
      'Google Apps Script (GAS)',
      'Microsoft Excel / VBA',
      'Electron (Desktop)',
    ],
  },
];

export const TECH_STACK_PRESETS = [
  {
    name: '🌐 Web Fullstack Modern (React + Node.js + PostgreSQL)',
    stack: ['React.js', 'Tailwind CSS', 'Node.js (Express)', 'PostgreSQL'],
  },
  {
    name: '📱 Mobile Multiplatform (Flutter + Firebase Cloud)',
    stack: ['Flutter (Android & iOS)', 'Firebase Firestore', 'Google Cloud / Cloud Run'],
  },
  {
    name: '💼 Web Bisnis & Instansi (PHP Laravel + MySQL)',
    stack: ['PHP (Laravel)', 'Bootstrap', 'MySQL / MariaDB'],
  },
  {
    name: '🤖 Aplikasi Pintar AI (Next.js + Python FastAPI + Gemini AI + Postgres)',
    stack: ['Next.js', 'Tailwind CSS', 'Python (FastAPI)', 'PostgreSQL', 'Google Gemini AI API'],
  },
  {
    name: '⚡ Serverless Cepat (Next.js + Supabase + PostgreSQL)',
    stack: ['Next.js', 'Tailwind CSS', 'Supabase', 'PostgreSQL'],
  },
  {
    name: '📊 Otomasi Sekolah & Kantor (Google Sheets + AppSheet + GAS)',
    stack: ['Google Sheets (AppSheet)', 'Google Apps Script (GAS)'],
  },
  {
    name: '💻 Aplikasi POS Kasir Desktop (Electron + React + SQLite)',
    stack: ['Electron (Desktop)', 'React.js', 'SQLite (Lokal)'],
  },
];

export const WorkspaceView: React.FC<WorkspaceViewProps> = ({
  projects,
  activeProject,
  onSelectProject,
  onRefreshData,
}) => {
  const [isCreatingNew, setIsCreatingNew] = useState(projects.length === 0);
  const [searchQuery, setSearchQuery] = useState('');
  
  // Project Form State
  const [projectId, setProjectId] = useState(activeProject?.id || '');
  const [projectName, setProjectName] = useState(activeProject?.name || '');
  const [projectCode, setProjectCode] = useState(activeProject?.code || '');
  const [systemName, setSystemName] = useState(activeProject?.systemName || '');
  const [description, setDescription] = useState(activeProject?.description || '');
  const [targetTechStack, setTargetTechStack] = useState(activeProject?.targetTechStack || 'React.js, Node.js (Express), PostgreSQL');
  const [customTechInput, setCustomTechInput] = useState('');
  const [author, setAuthor] = useState(activeProject?.author || '');
  const [version, setVersion] = useState(activeProject?.version || '1.0.0');
  const [roles, setRoles] = useState<string[]>(activeProject?.roles || ['User', 'Admin', 'Operator']);
  const [newRoleInput, setNewRoleInput] = useState('');

  // Parsed list of selected technologies from targetTechStack
  const selectedTechList = useMemo(() => {
    if (!targetTechStack.trim()) return [];
    return targetTechStack
      .split(/[,+]/)
      .map((s) => s.trim())
      .filter((s) => s.length > 0);
  }, [targetTechStack]);

  // Add individual technology to stack
  const handleAddTech = (techName: string) => {
    const trimmed = techName.trim();
    if (!trimmed) return;
    const current = targetTechStack
      .split(/[,+]/)
      .map((s) => s.trim())
      .filter((s) => s.length > 0);
    if (!current.includes(trimmed)) {
      const updated = [...current, trimmed].join(', ');
      setTargetTechStack(updated);
    }
  };

  // Remove individual technology from stack
  const handleRemoveTech = (techToRemove: string) => {
    const current = targetTechStack
      .split(/[,+]/)
      .map((s) => s.trim())
      .filter((s) => s.length > 0);
    const updated = current.filter((s) => s !== techToRemove).join(', ');
    setTargetTechStack(updated);
  };

  // Apply quick architecture preset
  const handleApplyPreset = (presetStack: string[]) => {
    setTargetTechStack(presetStack.join(', '));
  };

  // Clear all tech stack items
  const handleClearTechStack = () => {
    setTargetTechStack('');
  };

  // Modals state
  const [projectToDelete, setProjectToDelete] = useState<Project | null>(null);
  const [projectToDuplicate, setProjectToDuplicate] = useState<Project | null>(null);
  const [duplicateName, setDuplicateName] = useState('');
  const [duplicateCode, setDuplicateCode] = useState('');
  const [showImportModal, setShowImportModal] = useState(false);
  const [jsonInput, setJsonInput] = useState('');
  const [showClearConfirm, setShowClearConfirm] = useState(false);
  const [notification, setNotification] = useState<{ type: 'success' | 'error' | 'info'; message: string } | null>(null);

  // Synchronize form when activeProject changes
  useEffect(() => {
    if (activeProject && !isCreatingNew) {
      setProjectId(activeProject.id);
      setProjectName(activeProject.name);
      setProjectCode(activeProject.code);
      setSystemName(activeProject.systemName);
      setDescription(activeProject.description);
      setTargetTechStack(activeProject.targetTechStack || 'React + Node.js + PostgreSQL');
      setAuthor(activeProject.author);
      setVersion(activeProject.version);
      setRoles(activeProject.roles || ['User', 'Admin']);
    } else if (projects.length === 0) {
      setIsCreatingNew(true);
    }
  }, [activeProject, isCreatingNew, projects.length]);

  // Filtered project list
  const filteredProjects = useMemo(() => {
    if (!searchQuery.trim()) return projects;
    const q = searchQuery.toLowerCase();
    return projects.filter(
      (p) =>
        p.name.toLowerCase().includes(q) ||
        p.code.toLowerCase().includes(q) ||
        p.systemName.toLowerCase().includes(q) ||
        p.description.toLowerCase().includes(q)
    );
  }, [projects, searchQuery]);

  // Handle Switch Project
  const handleSwitchProject = (p: Project) => {
    onSelectProject(p.id);
    setProjectId(p.id);
    setProjectName(p.name);
    setProjectCode(p.code);
    setSystemName(p.systemName);
    setDescription(p.description);
    setTargetTechStack(p.targetTechStack || '');
    setAuthor(p.author);
    setVersion(p.version);
    setRoles(p.roles || ['User', 'Admin']);
    setIsCreatingNew(false);
    setNotification(null);
  };

  // Reset form for new project creation
  const handleInitCreateNew = () => {
    setIsCreatingNew(true);
    setProjectId('');
    setProjectName('');
    setProjectCode('');
    setSystemName('');
    setDescription('');
    setTargetTechStack('React + Node.js + PostgreSQL');
    setAuthor('');
    setVersion('1.0.0');
    setRoles(['User', 'Admin', 'Operator']);
    setNotification(null);
  };

  // Add Actor Role
  const handleAddRole = () => {
    const trimmed = newRoleInput.trim();
    if (!trimmed) return;
    if (!roles.includes(trimmed)) {
      setRoles([...roles, trimmed]);
    }
    setNewRoleInput('');
  };

  // Remove Actor Role
  const handleRemoveRole = (roleToRemove: string) => {
    if (roles.length <= 1) {
      setNotification({ type: 'error', message: 'Proyek harus memiliki minimal 1 peran pengguna.' });
      return;
    }
    setRoles(roles.filter((r) => r !== roleToRemove));
  };

  // SAVE / CREATE PROJECT (CRUD: C & U)
  const handleSaveProject = (e: React.FormEvent) => {
    e.preventDefault();
    if (!projectName.trim()) {
      setNotification({ type: 'error', message: 'Nama Proyek wajib diisi.' });
      return;
    }
    if (!projectCode.trim()) {
      setNotification({ type: 'error', message: 'Kode Singkat Proyek wajib diisi.' });
      return;
    }

    if (isCreatingNew) {
      // CREATE
      const newProj = StorageService.createProject({
        name: projectName.trim(),
        code: projectCode.trim().toUpperCase(),
        systemName: systemName.trim() || 'Arsitektur Sistem',
        description: description.trim(),
        targetTechStack: targetTechStack.trim(),
        version: version.trim() || '1.0.0',
        author: author.trim() || 'Pengembang Utama',
        roles: roles.length > 0 ? roles : ['Pengguna', 'Admin'],
      });

      onRefreshData();
      setIsCreatingNew(false);
      setProjectId(newProj.id);
      setNotification({
        type: 'success',
        message: `Proyek "${newProj.name}" [${newProj.code}] berhasil dibuat!`,
      });
    } else {
      // UPDATE
      if (!projectId) return;
      const updated = StorageService.updateProject({
        id: projectId,
        name: projectName.trim(),
        code: projectCode.trim().toUpperCase(),
        systemName: systemName.trim(),
        description: description.trim(),
        targetTechStack: targetTechStack.trim(),
        version: version.trim() || '1.0.0',
        author: author.trim(),
        roles: roles.length > 0 ? roles : ['Pengguna', 'Admin'],
        createdAt: activeProject?.createdAt || new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      });

      onRefreshData();
      setNotification({
        type: 'success',
        message: `Proyek "${updated.name}" berhasil diperbarui!`,
      });
    }
  };

  // DELETE PROJECT (CRUD: D)
  const handleConfirmDeleteProject = () => {
    if (!projectToDelete) return;
    const deletedName = projectToDelete.name;
    StorageService.deleteProject(projectToDelete.id);
    setProjectToDelete(null);
    onRefreshData();
    setNotification({
      type: 'info',
      message: `Proyek "${deletedName}" dan semua data menu & alur kerja di dalamnya telah dihapus.`,
    });
  };

  // DUPLICATE PROJECT
  const handleConfirmDuplicate = () => {
    if (!projectToDuplicate) return;
    const cloned = StorageService.duplicateProject(
      projectToDuplicate.id,
      duplicateName.trim() || `${projectToDuplicate.name} (Salinan)`,
      duplicateCode.trim().toUpperCase() || `${projectToDuplicate.code}-CPY`
    );
    setProjectToDuplicate(null);
    onRefreshData();
    if (cloned) {
      setNotification({
        type: 'success',
        message: `Proyek berhasil digandakan sebagai "${cloned.name}"!`,
      });
    }
  };

  // EXPORT JSON BACKUP
  const handleExportJSON = () => {
    const jsonStr = StorageService.exportFullWorkspaceJSON();
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `cadangan-proyek-${Date.now()}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  // IMPORT JSON BACKUP
  const handleImportJSON = () => {
    if (!jsonInput.trim()) return;
    const ok = StorageService.importWorkspaceJSON(jsonInput);
    if (ok) {
      onRefreshData();
      setShowImportModal(false);
      setJsonInput('');
      setNotification({ type: 'success', message: 'Data proyek berhasil dipulihkan / diimpor!' });
    } else {
      setNotification({ type: 'error', message: 'Format data tidak valid. Silakan periksa kembali berkas Anda.' });
    }
  };

  // CLEAR ALL DATA (CLEAN SLATE)
  const handleConfirmClearAll = () => {
    StorageService.clearAllData();
    setShowClearConfirm(false);
    onRefreshData();
    setIsCreatingNew(true);
    setProjectName('');
    setProjectCode('');
    setSystemName('');
    setDescription('');
    setAuthor('');
    setNotification({
      type: 'info',
      message: 'Semua data telah dibersihkan. Anda dapat mulai membuat proyek baru dari awal.',
    });
  };

  // OPTIONAL DEMO TEMPLATE LOADER
  const handleLoadDemoTemplate = () => {
    if (
      window.confirm(
        'Muat data contoh sistem rumah sakit & keuangan? (Ini akan menambahkan contoh alur siap pakai).'
      )
    ) {
      StorageService.loadDemoTemplate();
      onRefreshData();
      setIsCreatingNew(false);
      setNotification({
        type: 'success',
        message: 'Contoh data berhasil dimuat.',
      });
    }
  };

  return (
    <div className="workspace-view space-y-4">
      {/* Header Banner */}
      <div className="bg-white p-4 rounded-[4px] border border-gray-200 shadow-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-3">
        <div>
          <div className="flex items-center gap-2">
            <span className="bg-[#6c757d] text-white text-xs font-bold px-2 py-0.5 rounded font-mono">
              RUANG KERJA
            </span>
            <h1 className="text-xl font-bold text-gray-900 tracking-tight">
              Manajemen Proyek &amp; Data Utama
            </h1>
          </div>
          <p className="text-xs text-gray-600 mt-1">
            Buat dan kelola proyek aplikasi Anda, atur peran pengguna (siapa yang memakai aplikasi), serta simpan cadangan data dengan mudah.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={handleInitCreateNew}
            className="px-3 py-1.5 bg-[#007bff] hover:bg-[#0069d9] text-white text-xs font-bold rounded shadow-xs transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <i className="fa-solid fa-folder-plus"></i>
            <span>+ Buat Proyek Baru</span>
          </button>

          <button
            type="button"
            onClick={handleExportJSON}
            className="px-3 py-1.5 bg-[#28a745] hover:bg-[#218838] text-white text-xs font-semibold rounded shadow-xs transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <i className="fa-solid fa-download"></i>
            <span>Unduh Cadangan (JSON)</span>
          </button>

          <button
            type="button"
            onClick={() => setShowImportModal(true)}
            className="px-3 py-1.5 bg-gray-100 hover:bg-gray-200 text-gray-800 text-xs font-semibold rounded border border-gray-300 transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <i className="fa-solid fa-file-import"></i>
            <span>Buka / Impor Berkas</span>
          </button>
        </div>
      </div>

      {/* Notification banner */}
      {notification && (
        <div
          className={`p-3 rounded-[4px] text-xs font-medium flex items-center justify-between gap-2 shadow-xs ${
            notification.type === 'success'
              ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
              : notification.type === 'error'
              ? 'bg-red-50 text-red-800 border border-red-200'
              : 'bg-blue-50 text-blue-800 border border-blue-200'
          }`}
        >
          <div className="flex items-center gap-2">
            <i
              className={`fa-solid ${
                notification.type === 'success'
                  ? 'fa-circle-check text-emerald-600'
                  : notification.type === 'error'
                  ? 'fa-circle-exclamation text-red-600'
                  : 'fa-circle-info text-blue-600'
              }`}
            ></i>
            <span>{notification.message}</span>
          </div>
          <button
            type="button"
            onClick={() => setNotification(null)}
            className="text-gray-400 hover:text-gray-700 cursor-pointer"
          >
            <i className="fa-solid fa-xmark"></i>
          </button>
        </div>
      )}

      {/* Main Grid: Projects List (Left) & Project Form / Settings (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Left Column: Project Catalog (CRUD: READ & SELECT) */}
        <div className="lg:col-span-5 space-y-3">
          <AdminCard
            title={`Daftar Proyek Anda (${projects.length})`}
            icon="fa-solid fa-folder-tree"
            variant="outline-primary"
            tools={
              <button
                type="button"
                onClick={handleInitCreateNew}
                className="btn btn-xs bg-white text-[#007bff] font-bold border border-blue-300 hover:bg-blue-50 px-2 py-0.5 rounded cursor-pointer"
              >
                + Baru
              </button>
            }
          >
            {/* Search Input */}
            <div className="mb-2.5">
              <div className="relative">
                <input
                  type="text"
                  placeholder="Cari proyek berdasarkan nama atau kode..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-7 pr-2 py-1.5 text-xs bg-gray-50 border border-gray-300 rounded focus:bg-white focus:outline-none focus:ring-1 focus:ring-blue-500"
                />
                <i className="fa-solid fa-magnifying-glass absolute left-2.5 top-2.5 text-gray-400 text-xs"></i>
              </div>
            </div>

            {/* Projects List */}
            {filteredProjects.length === 0 ? (
              <div className="text-center py-8 bg-gray-50 rounded border border-dashed border-gray-300 text-xs text-gray-500 space-y-2">
                <i className="fa-solid fa-folder-open text-gray-400 text-3xl"></i>
                <p className="font-semibold text-gray-700">Belum ada proyek</p>
                <p className="text-[11px] text-gray-500 max-w-xs mx-auto">
                  Klik "+ Buat Proyek Baru" untuk mulai mendesain aplikasi Anda dari nol tanpa data contoh.
                </p>
                <button
                  type="button"
                  onClick={handleInitCreateNew}
                  className="mt-2 px-3 py-1 bg-[#007bff] text-white rounded text-xs font-bold cursor-pointer"
                >
                  Buat Proyek Pertama
                </button>
              </div>
            ) : (
              <div className="space-y-2 max-h-[550px] overflow-y-auto pr-1">
                {filteredProjects.map((p) => {
                  const isActive = activeProject?.id === p.id && !isCreatingNew;
                  const menuCount = StorageService.getMenuItems(p.id).length;
                  const reqCount = StorageService.getRequirements(p.id).length;

                  return (
                    <div
                      key={p.id}
                      className={`p-3 rounded border transition-all ${
                        isActive
                          ? 'bg-blue-50/90 border-[#007bff] shadow-xs ring-1 ring-blue-500'
                          : 'bg-white hover:bg-gray-50 border-gray-200'
                      }`}
                    >
                      <div className="flex items-start justify-between gap-2 mb-1.5">
                        <div
                          className="flex-1 cursor-pointer"
                          onClick={() => handleSwitchProject(p)}
                        >
                          <div className="flex items-center gap-1.5 font-bold text-xs text-gray-900">
                            <i className={`fa-solid fa-folder ${isActive ? 'text-blue-600' : 'text-amber-500'}`}></i>
                            <span>{p.name}</span>
                            {isActive && (
                              <span className="bg-blue-600 text-white text-[9px] px-1.5 py-0.2 rounded font-bold uppercase">
                                AKTIF
                              </span>
                            )}
                          </div>
                          <div className="text-[11px] text-gray-500 font-mono mt-0.5">
                            Kode: <span className="font-bold text-gray-700">{p.code}</span> &bull; Jenis: {p.systemName || 'Umum'}
                          </div>
                        </div>

                        {/* Action buttons (Duplicate, Delete) */}
                        <div className="flex items-center gap-1">
                          <button
                            type="button"
                            title="Duplikat / Salin Proyek"
                            onClick={(e) => {
                              e.stopPropagation();
                              setProjectToDuplicate(p);
                              setDuplicateName(`${p.name} (Salinan)`);
                              setDuplicateCode(`${p.code}-CPY`);
                            }}
                            className="p-1 text-gray-400 hover:text-blue-600 rounded hover:bg-gray-100 transition-colors cursor-pointer"
                          >
                            <i className="fa-solid fa-copy text-xs"></i>
                          </button>

                          <button
                            type="button"
                            title="Hapus Proyek"
                            onClick={(e) => {
                              e.stopPropagation();
                              setProjectToDelete(p);
                            }}
                            className="p-1 text-gray-400 hover:text-red-600 rounded hover:bg-red-50 transition-colors cursor-pointer"
                          >
                            <i className="fa-solid fa-trash-can text-xs"></i>
                          </button>
                        </div>
                      </div>

                      {p.description && (
                        <p
                          className="text-[11px] text-gray-600 line-clamp-2 mb-2 cursor-pointer"
                          onClick={() => handleSwitchProject(p)}
                        >
                          {p.description}
                        </p>
                      )}

                      <div className="flex items-center justify-between text-[10px] text-gray-500 border-t border-gray-100 pt-2">
                        <div className="flex items-center gap-2">
                          <span className="bg-amber-100 text-amber-900 px-1.5 py-0.5 rounded font-semibold font-mono">
                            {menuCount} Menu
                          </span>
                          <span className="bg-blue-100 text-blue-900 px-1.5 py-0.5 rounded font-semibold font-mono">
                            {reqCount} Alur
                          </span>
                        </div>
                        <div className="flex items-center gap-2">
                          <span>v{p.version}</span>
                          <button
                            type="button"
                            onClick={() => handleSwitchProject(p)}
                            className="text-[#007bff] font-bold hover:underline cursor-pointer"
                          >
                            {isActive ? 'Ubah' : 'Pilih Proyek'}
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </AdminCard>

          {/* Clean Slate & Maintenance */}
          <AdminCard
            title="Pilihan Pembersihan & Contoh"
            icon="fa-solid fa-screwdriver-wrench"
            variant="outline-secondary"
          >
            <div className="space-y-2 text-xs">
              <button
                type="button"
                onClick={handleLoadDemoTemplate}
                className="w-full px-3 py-2 bg-blue-50 hover:bg-blue-100 text-blue-800 rounded border border-blue-200 font-semibold flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
              >
                <i className="fa-solid fa-wand-magic-sparkles text-blue-600"></i>
                <span>Muat Contoh Data Lengkap (Opsional)</span>
              </button>

              <button
                type="button"
                onClick={() => setShowClearConfirm(true)}
                className="w-full px-3 py-2 bg-red-50 hover:bg-red-100 text-red-700 rounded border border-red-200 font-semibold flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
              >
                <i className="fa-solid fa-trash-can text-red-600"></i>
                <span>Kosongkan Semua Data (Mulai Bersih)</span>
              </button>
            </div>
          </AdminCard>
        </div>

        {/* Right Column: Project Form (CRUD: CREATE / UPDATE) */}
        <div className="lg:col-span-7">
          <form onSubmit={handleSaveProject}>
            <AdminCard
              title={
                isCreatingNew
                  ? 'Formulir Buat Proyek Aplikasi Baru'
                  : `Ubah Pengaturan Proyek: ${activeProject?.name || 'Proyek'}`
              }
              icon={isCreatingNew ? 'fa-solid fa-folder-plus' : 'fa-solid fa-gear'}
              variant={isCreatingNew ? 'outline-success' : 'outline-primary'}
              tools={
                !isCreatingNew && (
                  <button
                    type="button"
                    onClick={handleInitCreateNew}
                    className="btn btn-xs bg-[#007bff] text-white font-bold px-2 py-0.5 rounded shadow-xs cursor-pointer"
                  >
                    + Buat Proyek Lain
                  </button>
                )
              }
              footer={
                <div className="w-full flex justify-between items-center">
                  <span className="text-[11px] text-gray-500 font-mono">
                    Status: {isCreatingNew ? 'MENAMBAH PROYEK BARU' : `MENGUBAH [${projectId}]`}
                  </span>
                  <div className="flex items-center gap-2">
                    {isCreatingNew && projects.length > 0 && (
                      <button
                        type="button"
                        onClick={() => {
                          setIsCreatingNew(false);
                          if (activeProject) handleSwitchProject(activeProject);
                        }}
                        className="px-3 py-1.5 bg-gray-100 hover:bg-gray-200 text-gray-700 text-xs font-semibold rounded cursor-pointer"
                      >
                        Batal
                      </button>
                    )}
                    <button
                      type="submit"
                      className={`px-4 py-2 text-white text-xs font-bold rounded shadow-xs transition-colors flex items-center gap-1.5 cursor-pointer ${
                        isCreatingNew ? 'bg-[#28a745] hover:bg-[#218838]' : 'bg-[#007bff] hover:bg-[#0069d9]'
                      }`}
                    >
                      <i className="fa-solid fa-floppy-disk"></i>
                      <span>{isCreatingNew ? 'Simpan Proyek Sekarang' : 'Simpan Perubahan'}</span>
                    </button>
                  </div>
                </div>
              }
            >
              <div className="space-y-3.5 text-xs">
                {/* Name & Code */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-bold text-gray-700 uppercase mb-1">
                      Nama Proyek / Aplikasi <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      required
                      value={projectName}
                      onChange={(e) => setProjectName(e.target.value)}
                      placeholder="Contoh: Sistem Logistik Pintar"
                      className="w-full p-2 text-xs bg-white border border-gray-300 rounded font-semibold text-gray-900 focus:ring-1 focus:ring-blue-500 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-gray-700 uppercase mb-1">
                      Kode Singkat Proyek <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      required
                      value={projectCode}
                      onChange={(e) => setProjectCode(e.target.value.toUpperCase())}
                      placeholder="Contoh: LOGISTIK-APP"
                      className="w-full p-2 text-xs bg-white border border-gray-300 rounded font-mono font-bold text-blue-900 focus:ring-1 focus:ring-blue-500 focus:outline-none uppercase"
                    />
                  </div>
                </div>

                {/* System Domain & Tech Stack */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-bold text-gray-700 uppercase mb-1">
                      Kategori / Bidang Sistem
                    </label>
                    <input
                      type="text"
                      value={systemName}
                      onChange={(e) => setSystemName(e.target.value)}
                      placeholder="Contoh: Manajemen Pengiriman & Gudang"
                      className="w-full p-2 text-xs bg-white border border-gray-300 rounded text-gray-900"
                    />
                  </div>

                  <div className="sm:col-span-2 bg-gray-50/80 p-3 rounded border border-gray-200 space-y-2.5">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <label className="text-xs font-bold text-gray-800 uppercase flex items-center gap-1.5">
                        <i className="fa-solid fa-layer-group text-blue-600"></i>
                        <span>Rencana Teknologi & Bahasa (Bisa Multi-Teknologi)</span>
                      </label>

                      {/* Clear & Count */}
                      <div className="flex items-center gap-2">
                        <span className="text-[11px] text-gray-500 font-medium">
                          {selectedTechList.length} teknologi dipilih
                        </span>
                        {selectedTechList.length > 0 && (
                          <button
                            type="button"
                            onClick={handleClearTechStack}
                            className="text-[11px] text-red-600 hover:text-red-800 font-semibold cursor-pointer underline"
                          >
                            Reset
                          </button>
                        )}
                      </div>
                    </div>

                    {/* Quick Presets & Dropdown Selector Controls */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                      {/* Presets Dropdown */}
                      <div>
                        <label className="block text-[11px] font-semibold text-gray-600 mb-0.5">
                          1. Pilih Paket Kombinasi Cepat (Preset):
                        </label>
                        <select
                          className="w-full p-2 text-xs bg-white border border-gray-300 rounded font-medium text-gray-800 focus:ring-1 focus:ring-blue-500 focus:outline-none cursor-pointer"
                          value=""
                          onChange={(e) => {
                            const val = e.target.value;
                            if (val) {
                              const found = TECH_STACK_PRESETS.find((p) => p.name === val);
                              if (found) handleApplyPreset(found.stack);
                            }
                          }}
                        >
                          <option value="">-- Pilih Paket Arsitektur Siap Pakai --</option>
                          {TECH_STACK_PRESETS.map((p) => (
                            <option key={p.name} value={p.name}>
                              {p.name}
                            </option>
                          ))}
                        </select>
                      </div>

                      {/* Add from Categorized Dropdown */}
                      <div>
                        <label className="block text-[11px] font-semibold text-gray-600 mb-0.5">
                          2. Tambah Pilihan Teknologi / Bahasa:
                        </label>
                        <select
                          className="w-full p-2 text-xs bg-white border border-gray-300 rounded font-medium text-gray-800 focus:ring-1 focus:ring-blue-500 focus:outline-none cursor-pointer"
                          value=""
                          onChange={(e) => {
                            const val = e.target.value;
                            if (val) {
                              handleAddTech(val);
                            }
                          }}
                        >
                          <option value="">-- Tambah Pilihan dari Menu Dropdown --</option>
                          {TECH_CATEGORIES.map((cat) => (
                            <optgroup key={cat.category} label={cat.category}>
                              {cat.items.map((item) => (
                                <option
                                  key={item}
                                  value={item}
                                  disabled={selectedTechList.includes(item)}
                                >
                                  {selectedTechList.includes(item) ? `✓ ${item} (Terpilih)` : item}
                                </option>
                              ))}
                            </optgroup>
                          ))}
                        </select>
                      </div>
                    </div>

                    {/* Custom Technology Input */}
                    <div className="flex items-center gap-2">
                      <input
                        type="text"
                        placeholder="Atau ketik nama teknologi / bahasa kustom lain (lalu klik + Tambah)..."
                        value={customTechInput}
                        onChange={(e) => setCustomTechInput(e.target.value)}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') {
                            e.preventDefault();
                            if (customTechInput.trim()) {
                              handleAddTech(customTechInput.trim());
                              setCustomTechInput('');
                            }
                          }
                        }}
                        className="flex-1 p-1.5 text-xs bg-white border border-gray-300 rounded text-gray-900 focus:ring-1 focus:ring-blue-500 focus:outline-none"
                      />
                      <button
                        type="button"
                        onClick={() => {
                          if (customTechInput.trim()) {
                            handleAddTech(customTechInput.trim());
                            setCustomTechInput('');
                          }
                        }}
                        className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs rounded transition-colors flex items-center gap-1 cursor-pointer"
                      >
                        <i className="fa-solid fa-plus"></i>
                        <span>Tambah</span>
                      </button>
                    </div>

                    {/* Selected Tech Chips / Badges */}
                    <div>
                      <span className="block text-[11px] font-semibold text-gray-600 mb-1">
                        Teknologi & Bahasa Aktif dalam Proyek:
                      </span>
                      {selectedTechList.length === 0 ? (
                        <div className="p-2.5 bg-white rounded border border-dashed border-gray-300 text-center text-[11px] text-gray-500">
                          Belum ada teknologi yang dipilih. Pilih dari menu dropdown di atas atau ketik nama teknologi kustom.
                        </div>
                      ) : (
                        <div className="flex flex-wrap gap-1.5 p-2 bg-white rounded border border-gray-200 max-h-36 overflow-y-auto">
                          {selectedTechList.map((tech) => (
                            <span
                              key={tech}
                              className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-blue-50 text-blue-800 border border-blue-200 shadow-2xs"
                            >
                              <i className="fa-solid fa-code text-[10px] text-blue-600"></i>
                              <span>{tech}</span>
                              <button
                                type="button"
                                title={`Hapus ${tech}`}
                                onClick={() => handleRemoveTech(tech)}
                                className="w-4 h-4 flex items-center justify-center rounded-full hover:bg-blue-200 text-blue-700 cursor-pointer ml-0.5"
                              >
                                &times;
                              </button>
                            </span>
                          ))}
                        </div>
                      )}
                    </div>

                    {/* Raw string preview/edit for full flexibility */}
                    <div>
                      <label className="block text-[10px] font-mono text-gray-500 uppercase">
                        Teks Ringkasan Rencana Teknologi (Tersimpan ke Dokumen SRS & JSON):
                      </label>
                      <input
                        type="text"
                        value={targetTechStack}
                        onChange={(e) => setTargetTechStack(e.target.value)}
                        placeholder="Contoh: React.js, Node.js (Express), PostgreSQL, Google Gemini AI API"
                        className="w-full p-1.5 text-[11px] bg-white border border-gray-300 rounded font-mono text-gray-800 focus:outline-none focus:ring-1 focus:ring-blue-500"
                      />
                    </div>
                  </div>
                </div>

                {/* Scope Description */}
                <div>
                  <label className="block text-xs font-bold text-gray-700 uppercase mb-1">
                    Deskripsi Singkat Tujuan Aplikasi
                  </label>
                  <textarea
                    rows={2}
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    placeholder="Jelaskan secara ringkas apa tujuan aplikasi ini dan masalah apa yang ingin diselesaikan..."
                    className="w-full p-2 text-xs bg-white border border-gray-300 rounded text-gray-900"
                  />
                </div>

                {/* Author & Version */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-bold text-gray-700 uppercase mb-1">
                      Penanggung Jawab / Pemilik Proyek
                    </label>
                    <input
                      type="text"
                      value={author}
                      onChange={(e) => setAuthor(e.target.value)}
                      placeholder="Contoh: Tim IT / Pak Budi"
                      className="w-full p-2 text-xs bg-white border border-gray-300 rounded text-gray-900"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-gray-700 uppercase mb-1">
                      Versi Catatan
                    </label>
                    <input
                      type="text"
                      value={version}
                      onChange={(e) => setVersion(e.target.value)}
                      placeholder="1.0.0"
                      className="w-full p-2 text-xs bg-white border border-gray-300 rounded font-mono text-gray-900"
                    />
                  </div>
                </div>

                {/* Actor Roles Catalog (CRUD: Roles) */}
                <div className="pt-3 border-t border-gray-200">
                  <div className="flex items-center justify-between mb-1.5">
                    <label className="text-xs font-bold text-gray-700 uppercase flex items-center gap-1.5">
                      <i className="fa-solid fa-users text-blue-600"></i>
                      <span>Daftar Peran Pengguna (Siapa yang Memakai Aplikasi)</span>
                    </label>
                    <span className="text-[10px] text-gray-500 font-mono">
                      {roles.length} peran terdaftar (Digunakan pada pilihan SIAPA)
                    </span>
                  </div>

                  <div className="flex flex-wrap items-center gap-1.5 mb-2.5 p-2 bg-gray-50 rounded border border-gray-200 min-h-[42px]">
                    {roles.map((r) => (
                      <span
                        key={r}
                        className="inline-flex items-center gap-1 px-2.5 py-1 rounded bg-blue-100 text-blue-900 text-xs font-semibold shadow-xs"
                      >
                        <i className="fa-solid fa-user-tag text-blue-600 text-[10px]"></i>
                        <span>{r}</span>
                        <button
                          type="button"
                          onClick={() => handleRemoveRole(r)}
                          className="text-blue-400 hover:text-red-600 ml-1 text-xs cursor-pointer"
                          title={`Hapus peran ${r}`}
                        >
                          <i className="fa-solid fa-xmark"></i>
                        </button>
                      </span>
                    ))}
                  </div>

                  <div className="flex items-center gap-2">
                    <input
                      type="text"
                      placeholder="Ketik peran baru (misal: Staf Gudang, Sopir, Dokter, Kasir, Siswa)..."
                      value={newRoleInput}
                      onChange={(e) => setNewRoleInput(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') {
                          e.preventDefault();
                          handleAddRole();
                        }
                      }}
                      className="flex-1 p-2 text-xs bg-white border border-gray-300 rounded focus:ring-1 focus:ring-blue-500 focus:outline-none"
                    />
                    <button
                      type="button"
                      onClick={handleAddRole}
                      className="px-3 py-2 bg-gray-800 hover:bg-black text-white text-xs font-bold rounded shadow-xs transition-colors cursor-pointer"
                    >
                      + Tambah Peran
                    </button>
                  </div>
                </div>
              </div>
            </AdminCard>
          </form>
        </div>
      </div>

      {/* MODAL: DELETE CONFIRMATION */}
      {projectToDelete && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-[4px] shadow-2xl max-w-md w-full overflow-hidden border border-red-200 animate-in fade-in zoom-in-95">
            <div className="bg-red-600 text-white px-4 py-3 flex items-center justify-between">
              <div className="flex items-center gap-2 font-bold text-sm">
                <i className="fa-solid fa-triangle-exclamation"></i>
                <span>Konfirmasi Hapus Proyek</span>
              </div>
              <button
                type="button"
                onClick={() => setProjectToDelete(null)}
                className="text-white/80 hover:text-white cursor-pointer"
              >
                <i className="fa-solid fa-xmark"></i>
              </button>
            </div>
            <div className="p-4 text-xs space-y-3">
              <p className="text-gray-700">
                Apakah Anda yakin ingin menghapus permanen proyek{' '}
                <strong className="text-red-700 font-bold">"{projectToDelete.name}"</strong> (
                <span className="font-mono font-bold">{projectToDelete.code}</span>)?
              </p>
              <div className="p-3 bg-red-50 text-red-900 rounded border border-red-200 space-y-1 text-[11px]">
                <div className="font-bold flex items-center gap-1">
                  <i className="fa-solid fa-radiation"></i>
                  <span>Pemberitahuan Penting:</span>
                </div>
                <p>
                  Semua susunan menu, tombol, dan alur kerja yang ada di dalam proyek ini akan ikut terhapus secara permanen.
                </p>
              </div>
            </div>
            <div className="bg-gray-50 px-4 py-3 border-t border-gray-200 flex justify-end gap-2 text-xs">
              <button
                type="button"
                onClick={() => setProjectToDelete(null)}
                className="px-3 py-1.5 bg-gray-200 hover:bg-gray-300 text-gray-800 rounded font-semibold cursor-pointer"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={handleConfirmDeleteProject}
                className="px-3 py-1.5 bg-red-600 hover:bg-red-700 text-white rounded font-bold shadow-xs cursor-pointer"
              >
                Hapus Proyek &amp; Data
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: DUPLICATE PROJECT */}
      {projectToDuplicate && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-[4px] shadow-2xl max-w-md w-full overflow-hidden border border-blue-200 animate-in fade-in zoom-in-95">
            <div className="bg-[#007bff] text-white px-4 py-3 flex items-center justify-between">
              <div className="flex items-center gap-2 font-bold text-sm">
                <i className="fa-solid fa-copy"></i>
                <span>Gandakan / Salin Struktur Proyek</span>
              </div>
              <button
                type="button"
                onClick={() => setProjectToDuplicate(null)}
                className="text-white/80 hover:text-white cursor-pointer"
              >
                <i className="fa-solid fa-xmark"></i>
              </button>
            </div>
            <div className="p-4 text-xs space-y-3">
              <p className="text-gray-700">
                Buat salinan baru dari proyek <strong>"{projectToDuplicate.name}"</strong> beserta seluruh susunan menu dan alur kerjanya.
              </p>
              <div>
                <label className="block font-bold text-gray-700 uppercase mb-1">Nama Proyek Hasil Salinan</label>
                <input
                  type="text"
                  value={duplicateName}
                  onChange={(e) => setDuplicateName(e.target.value)}
                  className="w-full p-2 bg-white border border-gray-300 rounded font-semibold text-xs"
                  required
                />
              </div>
              <div>
                <label className="block font-bold text-gray-700 uppercase mb-1">Kode Singkat Baru</label>
                <input
                  type="text"
                  value={duplicateCode}
                  onChange={(e) => setDuplicateCode(e.target.value.toUpperCase())}
                  className="w-full p-2 bg-white border border-gray-300 rounded font-mono font-bold uppercase text-xs text-blue-900"
                  required
                />
              </div>
            </div>
            <div className="bg-gray-50 px-4 py-3 border-t border-gray-200 flex justify-end gap-2 text-xs">
              <button
                type="button"
                onClick={() => setProjectToDuplicate(null)}
                className="px-3 py-1.5 bg-gray-200 hover:bg-gray-300 text-gray-800 rounded font-semibold cursor-pointer"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={handleConfirmDuplicate}
                className="px-3 py-1.5 bg-[#007bff] hover:bg-[#0069d9] text-white rounded font-bold shadow-xs cursor-pointer"
              >
                Salin Sekarang
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: IMPORT JSON */}
      {showImportModal && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-[4px] shadow-2xl max-w-lg w-full overflow-hidden border border-gray-300 animate-in fade-in zoom-in-95">
            <div className="bg-gray-800 text-white px-4 py-3 flex items-center justify-between">
              <div className="flex items-center gap-2 font-bold text-sm">
                <i className="fa-solid fa-file-import"></i>
                <span>Impor Data Cadangan</span>
              </div>
              <button
                type="button"
                onClick={() => setShowImportModal(false)}
                className="text-white/80 hover:text-white cursor-pointer"
              >
                <i className="fa-solid fa-xmark"></i>
              </button>
            </div>
            <div className="p-4 text-xs space-y-3">
              <p className="text-gray-600">
                Tempelkan teks data cadangan JSON yang sebelumnya Anda unduh untuk memulihkan proyek:
              </p>
              <textarea
                rows={8}
                value={jsonInput}
                onChange={(e) => setJsonInput(e.target.value)}
                placeholder='{\n  "projects": [...],\n  "menuItems": [...],\n  "requirements": [...]\n}'
                className="w-full p-2 bg-gray-900 text-green-400 font-mono text-[11px] rounded border border-gray-700"
              />
            </div>
            <div className="bg-gray-50 px-4 py-3 border-t border-gray-200 flex justify-end gap-2 text-xs">
              <button
                type="button"
                onClick={() => setShowImportModal(false)}
                className="px-3 py-1.5 bg-gray-200 hover:bg-gray-300 text-gray-800 rounded font-semibold cursor-pointer"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={handleImportJSON}
                className="px-3 py-1.5 bg-[#28a745] hover:bg-[#218838] text-white rounded font-bold shadow-xs cursor-pointer"
              >
                Impor Data Sekarang
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: CLEAR ALL DATA CONFIRM */}
      {showClearConfirm && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-[4px] shadow-2xl max-w-md w-full overflow-hidden border border-red-300 animate-in fade-in zoom-in-95">
            <div className="bg-red-700 text-white px-4 py-3 flex items-center justify-between">
              <div className="flex items-center gap-2 font-bold text-sm">
                <i className="fa-solid fa-trash-can"></i>
                <span>Kosongkan Semua Data Proyek</span>
              </div>
              <button
                type="button"
                onClick={() => setShowClearConfirm(false)}
                className="text-white/80 hover:text-white cursor-pointer"
              >
                <i className="fa-solid fa-xmark"></i>
              </button>
            </div>
            <div className="p-4 text-xs space-y-3">
              <p className="text-gray-800 font-semibold">
                Apakah Anda yakin ingin mengosongkan seluruh proyek, susunan menu, dan catatan alur kerja?
              </p>
              <p className="text-gray-600 text-[11px]">
                Tindakan ini akan mengembalikan aplikasi ke kondisi kosong bersih sehingga Anda dapat mulai merancang dari awal tanpa data contoh.
              </p>
            </div>
            <div className="bg-gray-50 px-4 py-3 border-t border-gray-200 flex justify-end gap-2 text-xs">
              <button
                type="button"
                onClick={() => setShowClearConfirm(false)}
                className="px-3 py-1.5 bg-gray-200 hover:bg-gray-300 text-gray-800 rounded font-semibold cursor-pointer"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={handleConfirmClearAll}
                className="px-3 py-1.5 bg-red-700 hover:bg-red-800 text-white rounded font-bold shadow-xs cursor-pointer"
              >
                Ya, Kosongkan Semua
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
