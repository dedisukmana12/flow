import React, { useState, useEffect, useMemo } from 'react';
import { BranchCondition, MenuItem, Project, RequirementNode, RequirementPriority, RequirementStatus } from '../../types';
import { AdminCard } from '../common/AdminCard';
import { StorageService } from '../../services/storageService';

interface RequirementBuilderViewProps {
  activeProject?: Project;
  menuItems: MenuItem[];
  requirements: RequirementNode[];
  onRefreshData: () => void;
  onNavigateToDiagram?: (reqId?: string) => void;
  onNavigateToHelp?: () => void;
  initialModuleId?: string;
  initialMenuId?: string;
  initialFeatureId?: string;
}

export const RequirementBuilderView: React.FC<RequirementBuilderViewProps> = ({
  activeProject,
  menuItems,
  requirements,
  onRefreshData,
  onNavigateToDiagram,
  onNavigateToHelp,
  initialModuleId,
  initialMenuId,
  initialFeatureId,
}) => {
  // Cascading Selectors State
  const [selectedModuleId, setSelectedModuleId] = useState<string>(initialModuleId || '');
  const [selectedMenuId, setSelectedMenuId] = useState<string>(initialMenuId || '');
  const [selectedFeatureId, setSelectedFeatureId] = useState<string>(initialFeatureId || '');

  // Form State
  const [editingReqId, setEditingReqId] = useState<string | null>(null);
  const [reqCode, setReqCode] = useState<string>('');
  const [title, setTitle] = useState<string>('');
  
  // 6-Field Flow Architecture
  const [whoRole, setWhoRole] = useState<string>('Attending Physician');
  const [whoCustom, setWhoCustom] = useState<string>('');
  const [fromWhere, setFromWhere] = useState<string>('Clinical Worksheet Form');
  const [action, setAction] = useState<string>('Clicks "Commit & Sign Prescription" button');
  const [logic, setLogic] = useState<string>(
    'Validate patient allergen register for drug contraindications. Verify active renal clearance score (eGFR).'
  );
  const [output, setOutput] = useState<string>(
    'Digital prescription signed and dispatched to Pharmacy Dispensary Queue with notification flag.'
  );
  const [toWhere, setToWhere] = useState<string>('Pharmacy Dispensary Queue');
  const [toWhereType, setToWhereType] = useState<RequirementNode['toWhereType']>('internal_menu');

  // Branching Architecture
  const [hasBranching, setHasBranching] = useState<boolean>(false);
  const [branches, setBranches] = useState<BranchCondition[]>([]);

  // Metadata
  const [priority, setPriority] = useState<RequirementPriority>('HIGH');
  const [status, setStatus] = useState<RequirementStatus>('DRAFT');
  const [notes, setNotes] = useState<string>('');

  // UI Feedback
  const [notification, setNotification] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  // Available Modules (Level 2)
  const availableModules = useMemo(() => {
    return menuItems.filter((i) => i.level === 2);
  }, [menuItems]);

  // Available Menus (Level 3) under selected Module
  const availableMenus = useMemo(() => {
    if (!selectedModuleId) return [];
    return menuItems.filter((i) => i.level === 3 && i.parentId === selectedModuleId);
  }, [menuItems, selectedModuleId]);

  // Available Features (Level 4) under selected Menu
  const availableFeatures = useMemo(() => {
    if (!selectedMenuId) return [];
    return menuItems.filter((i) => i.level === 4 && i.parentId === selectedMenuId);
  }, [menuItems, selectedMenuId]);

  // Initialize selectors on mount or changes
  useEffect(() => {
    if (initialModuleId) setSelectedModuleId(initialModuleId);
    if (initialMenuId) setSelectedMenuId(initialMenuId);
    if (initialFeatureId) setSelectedFeatureId(initialFeatureId);
  }, [initialModuleId, initialMenuId, initialFeatureId]);

  // Default to first module if not selected
  useEffect(() => {
    if (!selectedModuleId && availableModules.length > 0) {
      setSelectedModuleId(availableModules[0].id);
    }
  }, [availableModules, selectedModuleId]);

  // Sync menu when module changes
  useEffect(() => {
    if (selectedModuleId) {
      const validMenus = menuItems.filter((i) => i.level === 3 && i.parentId === selectedModuleId);
      if (validMenus.length > 0 && (!selectedMenuId || !validMenus.some((m) => m.id === selectedMenuId))) {
        setSelectedMenuId(validMenus[0].id);
      }
    }
  }, [selectedModuleId, menuItems, selectedMenuId]);

  // Sync feature when menu changes
  useEffect(() => {
    if (selectedMenuId) {
      const validFeatures = menuItems.filter((i) => i.level === 4 && i.parentId === selectedMenuId);
      if (validFeatures.length > 0 && (!selectedFeatureId || !validFeatures.some((f) => f.id === selectedFeatureId))) {
        setSelectedFeatureId(validFeatures[0].id);
      }
    }
  }, [selectedMenuId, menuItems, selectedFeatureId]);

  // Roles list
  const projectRoles = useMemo(() => {
    return activeProject?.roles || ['User', 'Admin', 'Operator', 'System Gateway'];
  }, [activeProject]);

  // Add Branch
  const handleAddBranch = () => {
    const branchCount = branches.length + 1;
    const newBranch: BranchCondition = {
      id: `br-${Date.now()}-${branchCount}`,
      label: `Cabang ${String.fromCharCode(64 + branchCount)}: Kondisi Alternatif`,
      condition: 'Jika pemeriksaan gagal atau kondisi khusus terpenuhi',
      output: 'Tampilkan pesan pemberitahuan dan batalkan tindakan',
      toWhere: 'Layar Peringatan / Konfirmasi Ulang',
      toWhereType: 'ui_view',
    };
    setBranches([...branches, newBranch]);
    setHasBranching(true);
  };

  const handleUpdateBranch = (idx: number, field: keyof BranchCondition, value: any) => {
    const updated = [...branches];
    updated[idx] = { ...updated[idx], [field]: value };
    setBranches(updated);
  };

  const handleRemoveBranch = (idx: number) => {
    const updated = branches.filter((_, i) => i !== idx);
    setBranches(updated);
    if (updated.length === 0) {
      setHasBranching(false);
    }
  };

  // Reset Form
  const handleResetForm = () => {
    setEditingReqId(null);
    setReqCode('');
    setTitle('');
    setWhoRole(projectRoles[0] || 'Pengguna');
    setWhoCustom('');
    setFromWhere('Layar Formulir Utama');
    setAction('Mengisi data dan menekan tombol Kirim / Simpan');
    setLogic('Periksa kelengkapan data, verifikasi aturan yang berlaku, dan simpan perubahan.');
    setOutput('Data berhasil disimpan dan status diperbarui.');
    setToWhere('Layar Konfirmasi / Menu Selanjutnya');
    setToWhereType('internal_menu');
    setHasBranching(false);
    setBranches([]);
    setPriority('HIGH');
    setStatus('DRAFT');
    setNotes('');
    setNotification(null);
  };

  // Populate for Edit
  const handleEditRequirement = (req: RequirementNode) => {
    setEditingReqId(req.id);
    setSelectedModuleId(req.moduleId);
    setSelectedMenuId(req.menuId);
    setSelectedFeatureId(req.featureId);
    setReqCode(req.reqCode);
    setTitle(req.title);
    setWhoRole(req.whoRole);
    setWhoCustom(req.whoCustom || '');
    setFromWhere(req.fromWhere);
    setAction(req.action);
    setLogic(req.logic);
    setOutput(req.output);
    setToWhere(req.toWhere);
    setToWhereType(req.toWhereType || 'internal_menu');
    setHasBranching(req.hasBranching);
    setBranches(req.branches || []);
    setPriority(req.priority);
    setStatus(req.status);
    setNotes(req.notes || '');
    setNotification(null);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Handle Save
  const handleSaveNode = (e: React.FormEvent) => {
    e.preventDefault();

    if (!selectedModuleId || !selectedMenuId || !selectedFeatureId) {
      setNotification({
        type: 'error',
        message: 'Silakan pilih Modul, Menu, dan Fitur yang valid pada pilihan di atas.',
      });
      return;
    }

    if (!action.trim() || !logic.trim() || !output.trim()) {
      setNotification({
        type: 'error',
        message: 'Kolom TINDAKAN, ATURAN/LOGIKA, dan HASIL wajib diisi.',
      });
      return;
    }

    // Auto-generate title & code if empty
    let code = reqCode.trim();
    if (!code) {
      const feat = menuItems.find((m) => m.id === selectedFeatureId);
      const featCode = feat ? feat.code.replace('FTR-', '').replace('FT-', '') : 'ALUR';
      code = `REQ-${featCode}-${Math.floor(Math.random() * 900 + 100)}`;
    }

    let nodeTitle = title.trim();
    if (!nodeTitle) {
      const feat = menuItems.find((m) => m.id === selectedFeatureId);
      nodeTitle = `${whoRole === 'Lainnya / Kustom' || whoRole === 'Other / Custom' ? whoCustom : whoRole} - ${feat?.name || action.substring(0, 30)}`;
    }

    const payload = {
      ...(editingReqId ? { id: editingReqId } : {}),
      projectId: activeProject?.id || 'proj-medicare-01',
      reqCode: code,
      title: nodeTitle,
      moduleId: selectedModuleId,
      menuId: selectedMenuId,
      featureId: selectedFeatureId,
      whoRole: (whoRole === 'Lainnya / Kustom' || whoRole === 'Other / Custom') && whoCustom ? whoCustom : whoRole,
      whoCustom: whoCustom,
      fromWhere: fromWhere.trim(),
      action: action.trim(),
      logic: logic.trim(),
      output: output.trim(),
      toWhere: toWhere.trim(),
      toWhereType: toWhereType,
      hasBranching: branches.length > 0,
      branches: branches,
      priority,
      status,
      notes: notes.trim(),
    };

    const saved = StorageService.saveRequirement(payload);
    onRefreshData();

    setNotification({
      type: 'success',
      message: `Alur kebutuhan "${saved.reqCode}: ${saved.title}" berhasil disimpan!`,
    });

    setEditingReqId(saved.id);
  };

  // Delete
  const handleDeleteRequirement = (id: string) => {
    const target = requirements.find((r) => r.id === id);
    if (!target) return;

    if (window.confirm(`Apakah Anda yakin ingin menghapus alur kebutuhan "${target.reqCode}: ${target.title}"?`)) {
      StorageService.deleteRequirement(id);
      onRefreshData();
      if (editingReqId === id) {
        handleResetForm();
      }
      setNotification({
        type: 'success',
        message: `Berhasil menghapus alur kebutuhan ${target.reqCode}.`,
      });
    }
  };

  // Active module/menu/feature objects
  const activeModule = menuItems.find((m) => m.id === selectedModuleId);
  const activeMenu = menuItems.find((m) => m.id === selectedMenuId);
  const activeFeature = menuItems.find((m) => m.id === selectedFeatureId);

  // Requirements linked to this active feature
  const featureRequirements = useMemo(() => {
    return requirements.filter((r) => r.featureId === selectedFeatureId);
  }, [requirements, selectedFeatureId]);

  return (
    <div className="requirement-builder-view">
      {/* Header Banner */}
      <div className="mb-4 bg-white p-4 rounded-[4px] border border-gray-200 shadow-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-3">
        <div>
          <div className="flex items-center gap-2">
            <span className="bg-[#28a745] text-white text-xs font-bold px-2 py-0.5 rounded">
              MENU B
            </span>
            <h1 className="text-xl font-bold text-gray-900 tracking-tight">
              Penyusun Alur Kebutuhan Sistem
            </h1>
          </div>
          <p className="text-xs text-gray-600 mt-1">
            Rancang alur kerja fitur menggunakan 6 langkah mudah: <strong>[SIAPA]</strong> → <strong>[DARI MANA]</strong> → <strong>[TINDAKAN]</strong> → <strong>[ATURAN/LOGIKA]</strong> → <strong>[HASIL]</strong> → <strong>[TUJUAN]</strong> beserta pilihan percabangan kondisi jika diperlukan.
          </p>
        </div>

        <div className="flex items-center gap-2">
          {onNavigateToHelp && (
            <button
              type="button"
              onClick={onNavigateToHelp}
              className="px-3 py-1.5 bg-teal-50 hover:bg-teal-100 text-teal-800 text-xs font-semibold rounded border border-teal-300 transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <i className="fa-solid fa-circle-question text-teal-600"></i>
              <span>Panduan 6 Pertanyaan</span>
            </button>
          )}

          <button
            type="button"
            onClick={handleResetForm}
            className="px-3 py-1.5 bg-gray-100 hover:bg-gray-200 text-gray-700 text-xs font-semibold rounded border border-gray-300 transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <i className="fa-solid fa-file-circle-plus"></i>
            <span>+ Buat Alur Baru</span>
          </button>

          {onNavigateToDiagram && (
            <button
              type="button"
              onClick={() => onNavigateToDiagram(editingReqId || undefined)}
              className="px-3 py-1.5 bg-[#17a2b8] hover:bg-[#138496] text-white text-xs font-semibold rounded shadow-xs transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <i className="fa-solid fa-diagram-project"></i>
              <span>Lihat Diagram Alur</span>
            </button>
          )}
        </div>
      </div>

      {/* Notifications */}
      {notification && (
        <div
          className={`mb-4 p-3 rounded-[4px] text-xs font-medium flex items-center justify-between gap-2 shadow-xs ${
            notification.type === 'success'
              ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
              : 'bg-red-50 text-red-800 border border-red-200'
          }`}
        >
          <div className="flex items-center gap-2">
            <i
              className={`fa-solid ${
                notification.type === 'success' ? 'fa-circle-check text-emerald-600' : 'fa-circle-exclamation text-red-600'
              }`}
            ></i>
            <span>{notification.message}</span>
          </div>
          <button
            type="button"
            onClick={() => setNotification(null)}
            className="text-gray-400 hover:text-gray-700"
          >
            <i className="fa-solid fa-xmark"></i>
          </button>
        </div>
      )}

      {/* TOP HIERARCHY SELECTORS CARD (Synced with View A) */}
      <AdminCard
        title="Lokasi Penempatan Fitur"
        icon="fa-solid fa-crosshairs"
        variant="primary"
        className="mb-4"
        tools={
          <span className="text-xs bg-white/20 text-white px-2 py-0.5 rounded font-mono">
            Terhubung Otomatis dengan Pengaturan Menu
          </span>
        }
      >
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {/* Target Module (Level 2) */}
          <div>
            <label htmlFor="req-target-module-select" className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1 flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-[#28a745]"></span>
              1. Pilih Modul / Bagian
            </label>
            <select
              id="req-target-module-select"
              value={selectedModuleId}
              onChange={(e) => {
                setSelectedModuleId(e.target.value);
                setSelectedMenuId('');
                setSelectedFeatureId('');
              }}
              className="w-full p-2 text-xs bg-white border border-gray-300 rounded font-semibold text-gray-900 focus:ring-1 focus:ring-blue-500 focus:outline-none"
            >
              <option value="">-- Pilih Modul / Bagian --</option>
              {availableModules.map((mod) => (
                <option key={mod.id} value={mod.id}>
                  {mod.code} - {mod.name}
                </option>
              ))}
            </select>
            {availableModules.length === 0 && (
              <p className="text-[11px] text-amber-600 mt-1">
                ⚠️ Belum ada modul. Silakan buat modul tingkat 2 di menu Pengaturan Menu.
              </p>
            )}
          </div>

          {/* Target Menu (Level 3) */}
          <div>
            <label htmlFor="req-target-menu-select" className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1 flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-[#ffc107]"></span>
              2. Pilih Menu Layar
            </label>
            <select
              id="req-target-menu-select"
              value={selectedMenuId}
              onChange={(e) => {
                setSelectedMenuId(e.target.value);
                setSelectedFeatureId('');
              }}
              disabled={!selectedModuleId}
              className="w-full p-2 text-xs bg-white border border-gray-300 rounded font-semibold text-gray-900 disabled:bg-gray-100 disabled:text-gray-400 focus:ring-1 focus:ring-blue-500 focus:outline-none"
            >
              <option value="">-- Pilih Menu Layar --</option>
              {availableMenus.map((mnu) => (
                <option key={mnu.id} value={mnu.id}>
                  {mnu.code} - {mnu.name}
                </option>
              ))}
            </select>
          </div>

          {/* Target Feature (Level 4) */}
          <div>
            <label htmlFor="req-target-feature-select" className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1 flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-[#17a2b8]"></span>
              3. Pilih Tombol / Fitur
            </label>
            <select
              id="req-target-feature-select"
              value={selectedFeatureId}
              onChange={(e) => setSelectedFeatureId(e.target.value)}
              disabled={!selectedMenuId}
              className="w-full p-2 text-xs bg-white border border-gray-300 rounded font-semibold text-gray-900 disabled:bg-gray-100 disabled:text-gray-400 focus:ring-1 focus:ring-blue-500 focus:outline-none"
            >
              <option value="">-- Pilih Tombol / Fitur --</option>
              {availableFeatures.map((ft) => (
                <option key={ft.id} value={ft.id}>
                  {ft.code} - {ft.name}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Selected Hierarchy Breadcrumb Pill */}
        {activeModule && activeMenu && activeFeature && (
          <div className="mt-3 pt-3 border-t border-gray-100 flex flex-wrap items-center justify-between text-xs gap-2">
            <div className="flex items-center gap-1.5 text-gray-700 font-medium">
              <span className="text-gray-400">Jalur Fitur:</span>
              <span className="bg-green-100 text-green-800 px-2 py-0.5 rounded font-mono text-[11px]">
                {activeModule.code} ({activeModule.name})
              </span>
              <span>›</span>
              <span className="bg-amber-100 text-amber-800 px-2 py-0.5 rounded font-mono text-[11px]">
                {activeMenu.code} ({activeMenu.name})
              </span>
              <span>›</span>
              <span className="bg-cyan-100 text-cyan-800 px-2 py-0.5 rounded font-mono text-[11px] font-bold">
                {activeFeature.code} ({activeFeature.name})
              </span>
            </div>

            <div className="text-[11px] text-gray-500">
              {featureRequirements.length} alur kebutuhan terdaftar pada fitur ini
            </div>
          </div>
        )}
      </AdminCard>

      {/* MAIN REQUIREMENT FORM (AdminLTE 3 Card Form) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Form Column */}
        <div className="lg:col-span-8">
          <form onSubmit={handleSaveNode}>
            <AdminCard
              title={
                <div className="flex items-center gap-2">
                  <span>
                    {editingReqId ? `Ubah Alur: ${reqCode}` : 'Formulir Rincian Alur Kebutuhan'}
                  </span>
                  <span
                    className={`text-[10px] font-bold px-2 py-0.5 rounded font-mono ${
                      branches.length > 0 ? 'bg-purple-600 text-white' : 'bg-blue-600 text-white'
                    }`}
                  >
                    {branches.length > 0 ? 'DENGAN PERCABANGAN' : 'ALUR LURUS'}
                  </span>
                </div>
              }
              icon="fa-solid fa-code-branch"
              variant="outline-primary"
              footer={
                <div className="w-full flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <button
                      type="submit"
                      className="px-4 py-2 bg-[#28a745] hover:bg-[#218838] text-white text-xs font-bold rounded shadow-xs transition-colors flex items-center gap-1.5 cursor-pointer"
                    >
                      <i className="fa-solid fa-floppy-disk"></i>
                      <span>Simpan Alur Ini</span>
                    </button>

                    <button
                      type="button"
                      onClick={handleAddBranch}
                      className="px-3 py-2 bg-[#6f42c1] hover:bg-[#5a32a3] text-white text-xs font-bold rounded shadow-xs transition-colors flex items-center gap-1.5 cursor-pointer"
                    >
                      <i className="fa-solid fa-code-branch"></i>
                      <span>+ Tambah Cabang (Jika/Maka)</span>
                    </button>

                    <button
                      type="button"
                      onClick={handleResetForm}
                      className="px-3 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 text-xs font-semibold rounded border border-gray-300 transition-colors flex items-center gap-1 cursor-pointer"
                    >
                      <i className="fa-solid fa-rotate-left"></i>
                      <span>Kosongkan Formulir</span>
                    </button>
                  </div>

                  {editingReqId && (
                    <button
                      type="button"
                      onClick={() => handleDeleteRequirement(editingReqId)}
                      className="px-3 py-2 bg-red-50 hover:bg-red-100 text-red-700 text-xs font-semibold rounded border border-red-300 transition-colors flex items-center gap-1 cursor-pointer"
                    >
                      <i className="fa-solid fa-trash-can"></i>
                      <span>Hapus Alur</span>
                    </button>
                  )}
                </div>
              }
            >
              {/* Requirement Identification Row */}
              <div className="grid grid-cols-1 sm:grid-cols-12 gap-3 mb-4 pb-3 border-b border-gray-200">
                <div className="sm:col-span-3">
                  <label htmlFor="req-code-input" className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1">
                    Kode Alur
                  </label>
                  <input
                    id="req-code-input"
                    type="text"
                    placeholder="Contoh: REQ-AUTH-001"
                    value={reqCode}
                    onChange={(e) => setReqCode(e.target.value)}
                    className="w-full p-2 text-xs bg-gray-50 border border-gray-300 rounded font-mono font-bold text-blue-900 focus:bg-white focus:outline-none focus:ring-1 focus:ring-blue-500"
                  />
                </div>

                <div className="sm:col-span-5">
                  <label htmlFor="req-summary-title-input" className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1">
                    Judul / Ringkasan Kebutuhan <span className="text-red-500">*</span>
                  </label>
                  <input
                    id="req-summary-title-input"
                    type="text"
                    required
                    placeholder="Contoh: Verifikasi Data Pasien & Buat Nomor Antrean"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    className="w-full p-2 text-xs bg-white border border-gray-300 rounded font-semibold text-gray-900 focus:outline-none focus:ring-1 focus:ring-blue-500"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label htmlFor="req-priority-select" className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1">
                    Prioritas
                  </label>
                  <select
                    id="req-priority-select"
                    value={priority}
                    onChange={(e) => setPriority(e.target.value as RequirementPriority)}
                    className="w-full p-2 text-xs bg-white border border-gray-300 rounded font-medium text-gray-700 focus:outline-none focus:ring-1 focus:ring-blue-500"
                  >
                    <option value="CRITICAL">🔥 Sangat Penting (Kritis)</option>
                    <option value="HIGH">🔴 Tinggi</option>
                    <option value="MEDIUM">🟡 Sedang</option>
                    <option value="LOW">🟢 Rendah</option>
                  </select>
                </div>

                <div className="sm:col-span-2">
                  <label htmlFor="req-status-select" className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1">
                    Status Pengerjaan
                  </label>
                  <select
                    id="req-status-select"
                    value={status}
                    onChange={(e) => setStatus(e.target.value as RequirementStatus)}
                    className="w-full p-2 text-xs bg-white border border-gray-300 rounded font-medium text-gray-700 focus:outline-none focus:ring-1 focus:ring-blue-500"
                  >
                    <option value="DRAFT">📝 Konsep (Draft)</option>
                    <option value="IN_REVIEW">🔍 Sedang Ditinjau</option>
                    <option value="APPROVED">✅ Disetujui</option>
                    <option value="IMPLEMENTED">🚀 Selesai Dibuat</option>
                  </select>
                </div>
              </div>

              {/* 6-FIELD CORE FLOW ARCHITECTURE */}
              <div className="space-y-4">
                {/* 1. WHO */}
                <div className="p-3 bg-blue-50/50 rounded border border-blue-200">
                  <div className="flex items-center gap-2 mb-2">
                    <span className="w-5 h-5 rounded-full bg-[#007bff] text-white flex items-center justify-center text-[10px] font-bold">
                      1
                    </span>
                    <label className="text-xs font-bold text-blue-900 uppercase tracking-wider">
                      SIAPA (Pengguna / Pelaku)
                    </label>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    <div>
                      <label htmlFor="req-who-role-select" className="block text-[10px] font-semibold text-gray-500 uppercase mb-1">
                        Pilih Peran yang Sudah Ada
                      </label>
                      <select
                        id="req-who-role-select"
                        value={whoRole}
                        onChange={(e) => setWhoRole(e.target.value)}
                        className="w-full p-2 text-xs bg-white border border-gray-300 rounded font-semibold text-gray-900 focus:ring-1 focus:ring-blue-500 focus:outline-none"
                      >
                        {projectRoles.map((r) => (
                          <option key={r} value={r}>
                            👤 {r}
                          </option>
                        ))}
                        <option value="Other / Custom">➕ Peran Lainnya / Tulis Sendiri...</option>
                      </select>
                    </div>

                    <div>
                      <label htmlFor="req-who-custom-input" className="block text-[10px] font-semibold text-gray-500 uppercase mb-1">
                        Tuliskan Nama Peran Kustom
                      </label>
                      <input
                        id="req-who-custom-input"
                        type="text"
                        placeholder="Contoh: Petugas Loket Pendaftaran"
                        value={whoCustom}
                        onChange={(e) => {
                          setWhoCustom(e.target.value);
                          if (whoRole !== 'Other / Custom') setWhoRole('Other / Custom');
                        }}
                        className="w-full p-2 text-xs bg-white border border-gray-300 rounded text-gray-900 focus:ring-1 focus:ring-blue-500 focus:outline-none"
                      />
                    </div>
                  </div>
                </div>

                {/* 2. FROM WHERE & 3. ACTION */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {/* 2. FROM WHERE */}
                  <div className="p-3 bg-gray-50 rounded border border-gray-300">
                    <div className="flex items-center gap-2 mb-2">
                      <span className="w-5 h-5 rounded-full bg-gray-600 text-white flex items-center justify-center text-[10px] font-bold">
                        2
                      </span>
                      <label htmlFor="req-from-where-input" className="text-xs font-bold text-gray-800 uppercase tracking-wider">
                        DARI MANA (Layar Asal / Pemicu Awal)
                      </label>
                    </div>
                    <input
                      id="req-from-where-input"
                      type="text"
                      required
                      placeholder="Contoh: Formulir Pendaftaran Pasien Baru"
                      value={fromWhere}
                      onChange={(e) => setFromWhere(e.target.value)}
                      className="w-full p-2 text-xs bg-white border border-gray-300 rounded font-medium text-gray-900 focus:ring-1 focus:ring-blue-500 focus:outline-none"
                    />
                    <p className="text-[10px] text-gray-500 mt-1">
                      Layar tempat pengguna berada, tombol fisik, atau sumber pemicu awal.
                    </p>
                  </div>

                  {/* 3. ACTION */}
                  <div className="p-3 bg-green-50/50 rounded border border-green-200">
                    <div className="flex items-center gap-2 mb-2">
                      <span className="w-5 h-5 rounded-full bg-[#28a745] text-white flex items-center justify-center text-[10px] font-bold">
                        3
                      </span>
                      <label htmlFor="req-action-input" className="text-xs font-bold text-green-900 uppercase tracking-wider">
                        TINDAKAN (Apa yang Dilakukan) <span className="text-red-500">*</span>
                      </label>
                    </div>
                    <input
                      id="req-action-input"
                      type="text"
                      required
                      placeholder="Contoh: Mengisi NIK pasien dan mengklik tombol 'Simpan & Daftarkan'"
                      value={action}
                      onChange={(e) => setAction(e.target.value)}
                      className="w-full p-2 text-xs bg-white border border-gray-300 rounded font-medium text-gray-900 focus:ring-1 focus:ring-blue-500 focus:outline-none"
                    />
                    <p className="text-[10px] text-gray-500 mt-1">
                      Tombol yang diklik, aksi memindai kartu, atau berkas yang diunggah.
                    </p>
                  </div>
                </div>

                {/* 4. LOGIC */}
                <div className="p-3 bg-amber-50/60 rounded border border-amber-200">
                  <div className="flex items-center gap-2 mb-2">
                    <span className="w-5 h-5 rounded-full bg-[#ffc107] text-gray-900 flex items-center justify-center text-[10px] font-bold">
                      4
                    </span>
                    <label htmlFor="req-logic-textarea" className="text-xs font-bold text-amber-900 uppercase tracking-wider">
                      ATURAN / LOGIKA (Pemeriksaan Sistem) <span className="text-red-500">*</span>
                    </label>
                  </div>
                  <textarea
                    id="req-logic-textarea"
                    rows={3}
                    required
                    placeholder="Contoh: Periksa format NIK 16 digit. Cek apakah pasien sudah pernah terdaftar di database. Jika belum, buat nomor rekam medis baru..."
                    value={logic}
                    onChange={(e) => setLogic(e.target.value)}
                    className="w-full p-2 text-xs bg-white border border-gray-300 rounded font-mono text-gray-900 focus:ring-1 focus:ring-blue-500 focus:outline-none"
                  />
                  <p className="text-[10px] text-gray-500 mt-1">
                    Aturan bisnis, pengecekan keabsahan data, perhitungan, dan syarat yang harus dipenuhi.
                  </p>
                </div>

                {/* 5. OUTPUT & 6. TO WHERE */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {/* 5. OUTPUT */}
                  <div className="p-3 bg-cyan-50/50 rounded border border-cyan-200">
                    <div className="flex items-center gap-2 mb-2">
                      <span className="w-5 h-5 rounded-full bg-[#17a2b8] text-white flex items-center justify-center text-[10px] font-bold">
                        5
                      </span>
                      <label htmlFor="req-output-input" className="text-xs font-bold text-cyan-900 uppercase tracking-wider">
                        HASIL (Yang Dihasilkan Sistem) <span className="text-red-500">*</span>
                      </label>
                    </div>
                    <textarea
                      id="req-output-input"
                      rows={2}
                      required
                      placeholder="Contoh: Data pasien tersimpan, nomor rekam medis terbit, dan struk antrean tercetak"
                      value={output}
                      onChange={(e) => setOutput(e.target.value)}
                      className="w-full p-2 text-xs bg-white border border-gray-300 rounded text-gray-900 focus:ring-1 focus:ring-blue-500 focus:outline-none"
                    />
                    <p className="text-[10px] text-gray-500 mt-1">
                      Hasil utama jika berhasil: perubahan data, notifikasi sukses, atau berkas tercetak.
                    </p>
                  </div>

                  {/* 6. TO WHERE */}
                  <div className="p-3 bg-gray-50 rounded border border-gray-300">
                    <div className="flex items-center gap-2 mb-2">
                      <span className="w-5 h-5 rounded-full bg-[#343a40] text-white flex items-center justify-center text-[10px] font-bold">
                        6
                      </span>
                      <label htmlFor="req-to-where-input" className="text-xs font-bold text-gray-800 uppercase tracking-wider">
                        TUJUAN (Layar / Sistem Selanjutnya)
                      </label>
                    </div>

                    <div className="space-y-2">
                      <input
                        id="req-to-where-input"
                        type="text"
                        placeholder="Contoh: Layar Antrean Poli & Ruang Dokter"
                        value={toWhere}
                        onChange={(e) => setToWhere(e.target.value)}
                        className="w-full p-2 text-xs bg-white border border-gray-300 rounded text-gray-900 font-semibold focus:ring-1 focus:ring-blue-500 focus:outline-none"
                      />

                      <div className="grid grid-cols-2 gap-1.5">
                        <div>
                          <label htmlFor="req-target-type-select" className="block text-[10px] text-gray-500 uppercase font-semibold mb-0.5">
                            Jenis Tujuan
                          </label>
                          <select
                            id="req-target-type-select"
                            value={toWhereType}
                            onChange={(e) => setToWhereType(e.target.value as any)}
                            className="w-full p-1.5 text-[11px] bg-white border border-gray-300 rounded text-gray-700"
                          >
                            <option value="internal_menu">Menu / Layar Aplikasi</option>
                            <option value="ui_view">Jendela Pesan (Pop-up)</option>
                            <option value="external_api">Layanan Luar (API)</option>
                            <option value="db_operation">Penyimpanan Data (Database)</option>
                          </select>
                        </div>

                        <div>
                          <label htmlFor="req-target-hierarchy-preset-select" className="block text-[10px] text-gray-500 uppercase font-semibold mb-0.5">
                            Pilih Cepat dari Menu
                          </label>
                          <select
                            id="req-target-hierarchy-preset-select"
                            onChange={(e) => {
                              if (e.target.value) setToWhere(e.target.value);
                            }}
                            className="w-full p-1.5 text-[11px] bg-white border border-gray-300 rounded text-gray-700"
                          >
                            <option value="">-- Isi dari Daftar Menu --</option>
                            {menuItems
                              .filter((m) => m.level === 3)
                              .map((m) => (
                                <option key={m.id} value={m.name}>
                                  {m.name}
                                </option>
                              ))}
                          </select>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* CONDITIONAL BRANCHES (IF/ELSE) SECTION */}
              {branches.length > 0 && (
                <div className="mt-4 pt-4 border-t border-purple-200">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-2">
                      <span className="w-5 h-5 rounded-full bg-purple-600 text-white flex items-center justify-center text-xs">
                        <i className="fa-solid fa-code-branch text-[10px]"></i>
                      </span>
                      <h4 className="text-xs font-bold text-purple-900 uppercase tracking-wider">
                        Cabang Kondisi Alternatif ({branches.length})
                      </h4>
                    </div>

                    <button
                      type="button"
                      onClick={handleAddBranch}
                      className="px-2 py-1 bg-purple-100 hover:bg-purple-200 text-purple-800 rounded text-xs font-semibold flex items-center gap-1 cursor-pointer"
                    >
                      <i className="fa-solid fa-plus"></i>
                      <span>+ Tambah Cabang Lain</span>
                    </button>
                  </div>

                  <div className="space-y-3">
                    {branches.map((br, idx) => (
                      <div
                        key={br.id}
                        className="p-3 bg-purple-50/70 rounded border border-purple-200 relative text-xs"
                      >
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center gap-1.5">
                            <span className="bg-purple-600 text-white text-[10px] font-bold px-2 py-0.5 rounded font-mono">
                              Cabang {String.fromCharCode(65 + idx)}
                            </span>
                            <input
                              type="text"
                              value={br.label}
                              onChange={(e) => handleUpdateBranch(idx, 'label', e.target.value)}
                              className="p-1 text-xs bg-white border border-purple-300 rounded font-semibold text-purple-900 w-64"
                              placeholder="Nama / Label Cabang"
                            />
                          </div>

                          <button
                            type="button"
                            onClick={() => handleRemoveBranch(idx)}
                            className="p-1 text-red-500 hover:text-red-700 hover:bg-red-100 rounded text-xs cursor-pointer"
                            title="Hapus Cabang"
                          >
                            <i className="fa-solid fa-trash-can"></i>
                          </button>
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                          <div>
                            <label className="block text-[10px] font-bold text-gray-600 uppercase mb-0.5">
                              Kondisi (JIKA...)
                            </label>
                            <input
                              type="text"
                              value={br.condition}
                              onChange={(e) => handleUpdateBranch(idx, 'condition', e.target.value)}
                              placeholder="Contoh: Jika NIK tidak ditemukan / salah"
                              className="w-full p-1.5 text-xs bg-white border border-gray-300 rounded"
                            />
                          </div>

                          <div>
                            <label className="block text-[10px] font-bold text-gray-600 uppercase mb-0.5">
                              Hasil yang Terjadi
                            </label>
                            <input
                              type="text"
                              value={br.output}
                              onChange={(e) => handleUpdateBranch(idx, 'output', e.target.value)}
                              placeholder="Contoh: Tampilkan pesan 'Data tidak ditemukan'"
                              className="w-full p-1.5 text-xs bg-white border border-gray-300 rounded"
                            />
                          </div>

                          <div>
                            <label className="block text-[10px] font-bold text-gray-600 uppercase mb-0.5">
                              Layar / Tujuan Khusus
                            </label>
                            <input
                              type="text"
                              value={br.toWhere}
                              onChange={(e) => handleUpdateBranch(idx, 'toWhere', e.target.value)}
                              placeholder="Contoh: Jendela Peringatan / Menu Bantuan"
                              className="w-full p-1.5 text-xs bg-white border border-gray-300 rounded"
                            />
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </AdminCard>
          </form>
        </div>

        {/* Existing Requirements for this Feature / Project */}
        <div className="lg:col-span-4 space-y-4">
          <AdminCard
            title={
              <div className="flex items-center gap-2">
                <span>Daftar Alur pada Fitur Ini</span>
                <span className="text-xs bg-gray-100 text-gray-700 px-2 py-0.5 rounded font-mono">
                  {featureRequirements.length}
                </span>
              </div>
            }
            icon="fa-solid fa-list-ol"
            variant="outline-info"
          >
            <div className="space-y-2.5 max-h-[580px] overflow-y-auto pr-1">
              {featureRequirements.length === 0 ? (
                <div className="text-center py-8 bg-gray-50 rounded border border-dashed border-gray-300 text-gray-500 text-xs">
                  <i className="fa-solid fa-bolt text-2xl text-gray-300 mb-2"></i>
                  <p className="font-semibold">Belum Ada Alur untuk Fitur Ini</p>
                  <p className="text-[11px] text-gray-400 mt-1">
                    Silakan isi formulir di sebelah kiri lalu klik "Simpan Alur Ini".
                  </p>
                </div>
              ) : (
                featureRequirements.map((req) => {
                  const isSelected = editingReqId === req.id;
                  return (
                    <div
                      key={req.id}
                      onClick={() => handleEditRequirement(req)}
                      className={`p-3 rounded border transition-all cursor-pointer ${
                        isSelected
                          ? 'bg-blue-50/90 border-[#007bff] shadow-xs ring-1 ring-blue-500'
                          : 'bg-white hover:bg-gray-50 border-gray-200'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1.5">
                        <span className="font-mono text-xs font-bold text-blue-800 bg-blue-100 px-1.5 py-0.2 rounded">
                          {req.reqCode}
                        </span>

                        <div className="flex items-center gap-1">
                          {req.hasBranching && (
                            <span className="bg-purple-100 text-purple-800 text-[10px] font-bold px-1.5 rounded-full">
                              <i className="fa-solid fa-code-branch mr-0.5"></i>
                              {req.branches.length} Cabang
                            </span>
                          )}
                          <span
                            className={`text-[9px] font-bold px-1.5 py-0.2 rounded uppercase ${
                              req.priority === 'CRITICAL'
                                ? 'bg-red-600 text-white'
                                : req.priority === 'HIGH'
                                ? 'bg-orange-500 text-white'
                                : 'bg-gray-200 text-gray-800'
                            }`}
                          >
                            {req.priority === 'CRITICAL' ? 'KRITIS' : req.priority === 'HIGH' ? 'TINGGI' : req.priority === 'MEDIUM' ? 'SEDANG' : 'RENDAH'}
                          </span>
                        </div>
                      </div>

                      <div className="text-xs font-semibold text-gray-900 mb-1 line-clamp-2">
                        {req.title}
                      </div>

                      <div className="text-[11px] text-gray-600 space-y-0.5 bg-gray-50 p-2 rounded border border-gray-100">
                        <div>
                          <strong className="text-blue-700">SIAPA:</strong> {req.whoRole}
                        </div>
                        <div>
                          <strong className="text-green-700">AKSI:</strong> {req.action}
                        </div>
                        <div>
                          <strong className="text-gray-700">TUJUAN:</strong> {req.toWhere}
                        </div>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </AdminCard>
        </div>
      </div>
    </div>
  );
};
