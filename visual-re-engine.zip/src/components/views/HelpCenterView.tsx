import React, { useState } from 'react';
import { ActiveView } from '../../types';
import { AdminCard } from '../common/AdminCard';

interface HelpCenterViewProps {
  setActiveView: (view: ActiveView) => void;
  onNavigateToBuilderWithFeature?: (moduleId: string, menuId: string, featureId: string) => void;
}

type GuideTab = 
  | 'QUICK_START'
  | 'STEP_1_MENU'
  | 'STEP_2_SIX_QUESTIONS'
  | 'STEP_BRANCHES'
  | 'STEP_3_DIAGRAM'
  | 'STEP_4_EXPORT'
  | 'REAL_EXAMPLES'
  | 'GLOSSARY';

export const HelpCenterView: React.FC<HelpCenterViewProps> = ({ setActiveView }) => {
  const [activeTab, setActiveTab] = useState<GuideTab>('QUICK_START');
  const [searchQuery, setSearchQuery] = useState('');
  const [interactiveField, setInteractiveField] = useState<'who' | 'from' | 'action' | 'logic' | 'output' | 'to'>('who');
  const [expandedCaseStudy, setExpandedCaseStudy] = useState<number | null>(0);

  // Quick 6 Questions Interactive Field Helper Data
  const fieldGuides = {
    who: {
      number: 1,
      title: 'SIAPA (Pengguna / Peran)',
      analogy: 'Siapa orang yang sedang duduk memegang HP atau mengetik di komputer?',
      question: 'Siapa aktor yang menjalankan tindakan ini?',
      goodExample: 'Perawat Poli Gigi, Kasir Toko, Pasien Baru, Admin Keuangan',
      badExample: 'Sistem komputer, Tombol, Layar, Otomatis',
      why: 'Aplikasi harus tahu hak akses siapa yang boleh menekan tombol tersebut agar data tidak diakses orang yang salah.',
      tips: 'Gunakan nama peran atau profesi yang nyata di lapangan, bukan istilah teknis server.',
    },
    from: {
      number: 2,
      title: 'DARI MANA (Halaman / Layar Asal)',
      analogy: 'Di ruangan atau layar mana orang tersebut saat ini sedang berdiri?',
      question: 'Di halaman atau formulir mana tombol/tindakan ini berada?',
      goodExample: 'Formulir Pendaftaran Pasien, Halaman Keranjang Belanja, Menu Pengaturan Profil',
      badExample: 'Internet, Database, Luar Aplikasi',
      why: 'Memastikan programmer tahu di tampilan layar mana tombol atau fungsi tersebut harus diletakkan.',
      tips: 'Biasanya ini adalah nama Menu atau Formulir yang sudah Anda buat di Langkah 1.',
    },
    action: {
      number: 3,
      title: 'TINDAKAN (Aksi / Tombol yang Ditekan)',
      analogy: 'Tindakan fisik apa yang dilakukan jari pengguna?',
      question: 'Apa aksi yang memicu proses ini berjalan?',
      goodExample: 'Menekan tombol "Simpan Pendaftaran", Mengklik "Bayar Sekarang", Menggeser slider diskon',
      badExample: 'Data tersimpan, Sistem membaca',
      why: 'Programmer dan AI perlu tahu pemicu persis (klik tombol, ketik teks, atau pilih opsi) yang memulai alur.',
      tips: 'Tulis dengan kata kerja aktif yang jelas seperti "Klik tombol X" atau "Pilih opsi Y".',
    },
    logic: {
      number: 4,
      title: 'ATURAN (Pengecekan / Validasi Sebelum Diproses)',
      analogy: 'Syarat apa yang harus dicek petugas sebelum memberi stempel persetujuan?',
      question: 'Aturan atau pemeriksaan apa yang wajib dipenuhi sebelum sistem menyimpan?',
      goodExample: 'Cek apakah NIK sudah 16 angka, pastikan stok barang > 0, periksa apakah password minimal 8 huruf',
      badExample: 'Proses data dengan cepat dan aman',
      why: 'Komputer tidak punya akal sehat. Kita wajib memberi tahu aturan apa saja yang boleh dan tidak boleh.',
      tips: 'Sebutkan angka atau syarat yang pasti (misal: "tidak boleh kosong", "harus angka positif", "status harus aktif").',
    },
    output: {
      number: 5,
      title: 'HASIL (Output Saat Berhasil)',
      analogy: 'Barang atau bukti apa yang diterima pengguna setelah proses selesai?',
      question: 'Apa bukti atau perubahan yang terjadi saat semua syarat terpenuhi?',
      goodExample: 'Muncul pesan hijau "Data Pasien Berhasil Disimpan" dan nomor antrean pasien dibuat',
      badExample: 'Selesai, Sukses',
      why: 'Pengguna butuh kepastian visual bahwa permintaannya berhasil diproses oleh komputer.',
      tips: 'Jelaskan pesan apa yang muncul di layar dan data apa yang berhasil tersimpan di sistem.',
    },
    to: {
      number: 6,
      title: 'TUJUAN (Ke Mana Layar Berpindah)',
      analogy: 'Setelah urusan di meja ini selesai, pengguna dipersilakan pindah ke meja mana?',
      question: 'Setelah proses sukses, layar apa yang harus dibuka selanjutnya?',
      goodExample: 'Pindah ke Layar Cetak Kartu Berobat, atau Buka Halaman Daftar Riwayat Transaksi',
      badExample: 'Selesai, Tidak ke mana-mana (tanpa penjelasan)',
      why: 'Mencegah alur aplikasi buntu atau membingungkan pengguna setelah menekan tombol simpan.',
      tips: 'Tentukan tujuan yang jelas: bisa kembali ke tabel daftar, pindah ke layar cetak, atau tetap di layar yang sama dengan form dikosongkan.',
    },
  };

  // Case Studies
  const caseStudies = [
    {
      title: 'Contoh 1: Pendaftaran Pasien di Klinik / Rumah Sakit',
      icon: 'fa-solid fa-hospital',
      badge: 'Layanan Kesehatan',
      color: 'border-l-4 border-emerald-500',
      description: 'Bagaimana perawat mendaftarkan pasien baru sampai nomor rekam medis keluar.',
      steps: [
        { label: 'Struktur Menu', text: 'Modul Pelayanan Pasien ➔ Menu Pendaftaran Baru ➔ Tombol Simpan Pasien' },
        { label: 'SIAPA', text: 'Petugas Pendaftaran / Perawat' },
        { label: 'DARI MANA', text: 'Formulir Pendaftaran Pasien Baru' },
        { label: 'TINDAKAN', text: 'Mengisi form data diri dan menekan tombol "Simpan & Buat No. Antrean"' },
        { label: 'ATURAN', text: '1. NIK wajib 16 digit angka\n2. Nama dan Tanggal Lahir tidak boleh kosong\n3. NIK belum pernah terdaftar sebelumnya' },
        { label: 'HASIL', text: 'Data pasien tersimpan di sistem dan Nomor Rekam Medis otomatis terbuat' },
        { label: 'TUJUAN', text: 'Layar Cetak Kartu Pasien & Nomor Antrean Poli' },
        { label: 'Kondisi Gagal (If / Else)', text: 'JIKA NIK sudah terdaftar ➔ Tampilkan pesan "Pasien sudah pernah terdaftar" ➔ Arahkan ke Layar Pencarian Pasien Lama.' },
      ],
    },
    {
      title: 'Contoh 2: Pembayaran Pesanan di Toko Online / E-Commerce',
      icon: 'fa-solid fa-cart-shopping',
      badge: 'Toko Online',
      color: 'border-l-4 border-blue-500',
      description: 'Bagaimana pembeli melakukan checkout dan membayar menggunakan saldo e-wallet.',
      steps: [
        { label: 'Struktur Menu', text: 'Modul Transaksi ➔ Menu Pembayaran & Checkout ➔ Tombol Bayar Sekarang' },
        { label: 'SIAPA', text: 'Pembeli / Pelanggan' },
        { label: 'DARI MANA', text: 'Halaman Konfirmasi Pembayaran' },
        { label: 'TINDAKAN', text: 'Memasukkan PIN 6 digit dan menekan tombol "Bayar Sekarang"' },
        { label: 'ATURAN', text: '1. PIN dompet digital harus sesuai\n2. Saldo dompet harus >= total belanja\n3. Stok barang masih tersedia di gudang' },
        { label: 'HASIL', text: 'Saldo terpotong, status pesanan berubah menjadi "Lunas / Sedang Diproses", dan struk digital dibuat' },
        { label: 'TUJUAN', text: 'Halaman Rincian Pesanan & Lacak Pengiriman' },
        { label: 'Kondisi Gagal (If / Else)', text: 'JIKA Saldo Kurang ➔ Munculkan pesan merah "Saldo tidak mencukupi" ➔ Tawarkan tombol "Isi Saldo (Top-Up)" tanpa menghapus keranjang.' },
      ],
    },
    {
      title: 'Contoh 3: Pengajuan Cuti Karyawan di Perusahaan',
      icon: 'fa-solid fa-calendar-check',
      badge: 'HR & Kepegawaian',
      color: 'border-l-4 border-purple-500',
      description: 'Bagaimana staf mengajukan cuti tahunan dan diteruskan ke atasan untuk persetujuan.',
      steps: [
        { label: 'Struktur Menu', text: 'Modul Kepegawaian ➔ Menu Formulir Cuti ➔ Tombol Ajukan Permohonan' },
        { label: 'SIAPA', text: 'Karyawan / Staf' },
        { label: 'DARI MANA', text: 'Layar Permohonan Cuti Tahunan' },
        { label: 'TINDAKAN', text: 'Memilih tanggal mulai & selesai, lalu mengklik "Kirim Pengajuan Cuti"' },
        { label: 'ATURAN', text: '1. Sisa kuota cuti tahunan masih mencukupi\n2. Tanggal pengajuan minimal 3 hari sebelum hari H cuti\n3. Alasan cuti wajib diisi minimal 10 karakter' },
        { label: 'HASIL', text: 'Permohonan cuti tercatat dengan status "Menunggu Persetujuan Atasan", dan notifikasi dikirim ke email atasan' },
        { label: 'TUJUAN', text: 'Tabel Riwayat Pengajuan Cuti Pribadi' },
        { label: 'Kondisi Gagal (If / Else)', text: 'JIKA Sisa Cuti Habis ➔ Munculkan peringatan "Sisa cuti Anda 0 hari" ➔ Tetap di halaman cuti dengan tombol ajukan dinonaktifkan.' },
      ],
    },
  ];

  // Glossary Items
  const glossaryItems = [
    {
      term: 'Struktur Menu 4 Tingkat',
      simpleMeaning: 'Susunan urutan dari nama aplikasi, ke kelompok menu besar, ke halaman menu, hingga ke tombol paling kecil.',
      example: 'Rumah Sakit (Tingkat 1) ➔ Rawat Jalan (Tingkat 2) ➔ Pendaftaran (Tingkat 3) ➔ Tombol Simpan (Tingkat 4).',
    },
    {
      term: '6 Pertanyaan Emas (6-Field Flow)',
      simpleMeaning: 'Rumus 6 pertanyaan wajib untuk mencatat apa yang terjadi saat sebuah tombol ditekan agar tidak ada alur yang terlupakan.',
      example: 'SIAPA ➔ DARI MANA ➔ TINDAKAN ➔ ATURAN ➔ HASIL ➔ TUJUAN.',
    },
    {
      term: 'Kondisi Khusus (If / Else / Branching)',
      simpleMeaning: 'Jalan alternatif jika ada yang salah atau jika syarat tidak terpenuhi (misal: jika password salah atau saldo habis).',
      example: 'JIKA benar ➔ berhasil login. JIKA salah ➔ muncul pesan merah "Password Salah".',
    },
    {
      term: 'Alur Buntu / Logic Gap',
      simpleMeaning: 'Catatan alur kerja yang belum lengkap, misalnya lupa menentukan setelah tombol ditekan layarnya pindah ke mana.',
      example: 'Pengguna klik tombol Simpan, data tersimpan, tapi tidak tahu harus buka layar apa selanjutnya.',
    },
    {
      term: 'Bagan Visual / Diagram Mermaid',
      simpleMeaning: 'Gambar kotak-kotak dan panah yang menunjukkan urutan langkah aplikasi secara otomatis dari atas ke bawah.',
      example: 'Kotak Hijau (Pengguna) ➔ Panah Klik ➔ Kotak Kuning (Pengecekan) ➔ Kotak Biru (Layar Tujuan).',
    },
    {
      term: 'Dokumen Kebutuhan (SRS / User Story)',
      simpleMeaning: 'Berkas tulisan rapi berisi semua aturan aplikasi yang siap diberikan ke programmer atau AI untuk langsung dibuatkan programnya.',
      example: 'Format cerita pengguna: "Sebagai Pasien, Ketika Saya klik Bayar, Sistem mengecek saldo, Sehingga pesanan berhasil".',
    },
  ];

  const filteredGlossary = glossaryItems.filter(
    (g) =>
      g.term.toLowerCase().includes(searchQuery.toLowerCase()) ||
      g.simpleMeaning.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="help-center-view space-y-4">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-[#007bff] to-[#0056b3] text-white p-5 rounded-[4px] shadow-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="bg-white/20 text-white text-xs font-bold px-2.5 py-0.5 rounded-full backdrop-blur-xs flex items-center gap-1">
              <i className="fa-solid fa-circle-question"></i>
              PANDUAN LENGKAP & RAMAH AWAM
            </span>
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-white">
            Pusat Bantuan & Panduan Penggunaan
          </h1>
          <p className="text-xs text-blue-100 mt-1 max-w-3xl leading-relaxed">
            Selamat datang! Visual RE-Engine dirancang agar <strong>siapa saja</strong> (bahkan tanpa latar belakang IT atau coding) dapat merancang alur kerja aplikasi secara rapi, jelas, dan siap diwujudkan oleh tim pembuat software atau AI.
          </p>
        </div>

        <div className="flex items-center gap-2 self-stretch sm:self-auto">
          <button
            type="button"
            onClick={() => setActiveView('menu_configurator')}
            className="flex-1 sm:flex-initial px-4 py-2 bg-emerald-500 hover:bg-emerald-600 text-white text-xs font-bold rounded shadow-sm transition-all flex items-center justify-center gap-1.5 cursor-pointer"
          >
            <i className="fa-solid fa-play"></i>
            <span>Mulai Praktik (Langkah 1)</span>
          </button>
        </div>
      </div>

      {/* Navigation Tab Bar */}
      <div className="bg-white p-2 rounded-[4px] border border-gray-200 shadow-xs flex flex-wrap items-center gap-1.5">
        <button
          type="button"
          onClick={() => setActiveTab('QUICK_START')}
          className={`px-3 py-2 rounded text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
            activeTab === 'QUICK_START'
              ? 'bg-[#007bff] text-white shadow-xs'
              : 'text-gray-700 hover:bg-gray-100'
          }`}
        >
          <i className="fa-solid fa-rocket text-amber-300"></i>
          <span>1. Ringkasan 4 Langkah</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('STEP_1_MENU')}
          className={`px-3 py-2 rounded text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
            activeTab === 'STEP_1_MENU'
              ? 'bg-[#007bff] text-white shadow-xs'
              : 'text-gray-700 hover:bg-gray-100'
          }`}
        >
          <i className="fa-solid fa-folder-tree text-emerald-400"></i>
          <span>2. Cara Susun Menu (Tingkat 1-4)</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('STEP_2_SIX_QUESTIONS')}
          className={`px-3 py-2 rounded text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
            activeTab === 'STEP_2_SIX_QUESTIONS'
              ? 'bg-[#007bff] text-white shadow-xs'
              : 'text-gray-700 hover:bg-gray-100'
          }`}
        >
          <i className="fa-solid fa-bolt text-yellow-300"></i>
          <span>3. Rumus 6 Pertanyaan Emas</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('STEP_BRANCHES')}
          className={`px-3 py-2 rounded text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
            activeTab === 'STEP_BRANCHES'
              ? 'bg-[#007bff] text-white shadow-xs'
              : 'text-gray-700 hover:bg-gray-100'
          }`}
        >
          <i className="fa-solid fa-code-branch text-orange-400"></i>
          <span>4. Jalur Khusus (If / Else)</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('STEP_3_DIAGRAM')}
          className={`px-3 py-2 rounded text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
            activeTab === 'STEP_3_DIAGRAM'
              ? 'bg-[#007bff] text-white shadow-xs'
              : 'text-gray-700 hover:bg-gray-100'
          }`}
        >
          <i className="fa-solid fa-diagram-project text-cyan-300"></i>
          <span>5. Cek Alur & Gambar Diagram</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('STEP_4_EXPORT')}
          className={`px-3 py-2 rounded text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
            activeTab === 'STEP_4_EXPORT'
              ? 'bg-[#007bff] text-white shadow-xs'
              : 'text-gray-700 hover:bg-gray-100'
          }`}
        >
          <i className="fa-solid fa-box-archive text-purple-300"></i>
          <span>6. Unduh Hasil & Prompt AI</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('REAL_EXAMPLES')}
          className={`px-3 py-2 rounded text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
            activeTab === 'REAL_EXAMPLES'
              ? 'bg-[#007bff] text-white shadow-xs'
              : 'text-gray-700 hover:bg-gray-100'
          }`}
        >
          <i className="fa-solid fa-lightbulb text-amber-400"></i>
          <span>Contoh Nyata (3 Kasus)</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('GLOSSARY')}
          className={`px-3 py-2 rounded text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
            activeTab === 'GLOSSARY'
              ? 'bg-[#007bff] text-white shadow-xs'
              : 'text-gray-700 hover:bg-gray-100'
          }`}
        >
          <i className="fa-solid fa-book text-blue-300"></i>
          <span>Kamus Istilah Awam</span>
        </button>
      </div>

      {/* TAB 1: QUICK START (4 STEPS) */}
      {activeTab === 'QUICK_START' && (
        <div className="space-y-4">
          <AdminCard
            title="Cara Kerja Aplikasi dalam 4 Langkah Sederhana"
            icon="fa-solid fa-map-location-dot"
            variant="outline-primary"
          >
            <p className="text-xs text-gray-600 mb-4 leading-relaxed">
              Bayangkan Anda sedang membuat <strong>resep masakan</strong> atau <strong>cetak biru denah rumah</strong>. Anda tidak perlu tahu cara mengaduk semen atau memprogram coding. Cukup tentukan ruangannya apa saja, tombolnya apa saja, dan apa yang terjadi jika tombol itu ditekan:
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3">
              {/* Step 1 Card */}
              <div className="p-3.5 bg-emerald-50 border border-emerald-200 rounded-[4px] relative flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="w-6 h-6 rounded-full bg-emerald-600 text-white font-bold text-xs flex items-center justify-center">
                      1
                    </span>
                    <span className="text-[10px] font-bold uppercase text-emerald-800 bg-emerald-100 px-1.5 py-0.2 rounded">
                      Langkah Awal
                    </span>
                  </div>
                  <h3 className="font-bold text-gray-900 text-xs mb-1">
                    Susun Struktur Menu (Tingkat 1-4)
                  </h3>
                  <p className="text-[11px] text-gray-600 leading-relaxed mb-3">
                    Buat daftar menu dan tombol yang akan ada di aplikasi Anda. Mulai dari nama sistem, modul utama, halaman formulir, sampai tombol aksi.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => setActiveView('menu_configurator')}
                  className="w-full py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded text-[11px] font-bold transition-colors cursor-pointer flex items-center justify-center gap-1"
                >
                  <span>Buka Susun Menu</span>
                  <i className="fa-solid fa-arrow-right text-[10px]"></i>
                </button>
              </div>

              {/* Step 2 Card */}
              <div className="p-3.5 bg-amber-50 border border-amber-200 rounded-[4px] relative flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="w-6 h-6 rounded-full bg-amber-600 text-white font-bold text-xs flex items-center justify-center">
                      2
                    </span>
                    <span className="text-[10px] font-bold uppercase text-amber-800 bg-amber-100 px-1.5 py-0.2 rounded">
                      Inti Alur
                    </span>
                  </div>
                  <h3 className="font-bold text-gray-900 text-xs mb-1">
                    Catat Alur Kerja (6 Pertanyaan)
                  </h3>
                  <p className="text-[11px] text-gray-600 leading-relaxed mb-3">
                    Pilih tombol yang ingin dijelaskan, lalu jawab 6 pertanyaan mudah: <strong>Siapa</strong> yang klik, <strong>Di mana</strong>, apa <strong>Tindakan</strong>nya, apa <strong>Aturan</strong>nya, apa <strong>Hasil</strong>nya, dan ke mana <strong>Tujuan</strong>nya.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => setActiveView('req_builder')}
                  className="w-full py-1.5 bg-amber-600 hover:bg-amber-700 text-white rounded text-[11px] font-bold transition-colors cursor-pointer flex items-center justify-center gap-1"
                >
                  <span>Buka Form Alur</span>
                  <i className="fa-solid fa-arrow-right text-[10px]"></i>
                </button>
              </div>

              {/* Step 3 Card */}
              <div className="p-3.5 bg-cyan-50 border border-cyan-200 rounded-[4px] relative flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="w-6 h-6 rounded-full bg-[#17a2b8] text-white font-bold text-xs flex items-center justify-center">
                      3
                    </span>
                    <span className="text-[10px] font-bold uppercase text-cyan-800 bg-cyan-100 px-1.5 py-0.2 rounded">
                      Otomatis
                    </span>
                  </div>
                  <h3 className="font-bold text-gray-900 text-xs mb-1">
                    Lihat Gambar Alur & Cek Kelengkapan
                  </h3>
                  <p className="text-[11px] text-gray-600 leading-relaxed mb-3">
                    Sistem langsung menggambar diagram kotak-kotak otomatis. Jika ada alur yang buntu atau lupa tujuan layarnya, sistem akan memberitahu dan bisa diperbaiki otomatis.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => setActiveView('logic_diagram')}
                  className="w-full py-1.5 bg-[#17a2b8] hover:bg-[#138496] text-white rounded text-[11px] font-bold transition-colors cursor-pointer flex items-center justify-center gap-1"
                >
                  <span>Lihat Diagram Alur</span>
                  <i className="fa-solid fa-arrow-right text-[10px]"></i>
                </button>
              </div>

              {/* Step 4 Card */}
              <div className="p-3.5 bg-purple-50 border border-purple-200 rounded-[4px] relative flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="w-6 h-6 rounded-full bg-[#6f42c1] text-white font-bold text-xs flex items-center justify-center">
                      4
                    </span>
                    <span className="text-[10px] font-bold uppercase text-purple-800 bg-purple-100 px-1.5 py-0.2 rounded">
                      Siap Pakai
                    </span>
                  </div>
                  <h3 className="font-bold text-gray-900 text-xs mb-1">
                    Unduh Dokumen & Salin ke AI
                  </h3>
                  <p className="text-[11px] text-gray-600 leading-relaxed mb-3">
                    Unduh dokumen kebutuhan (SRS) untuk presentasi ke bos/klien, atau salin instruksi alur ke AI (seperti ChatGPT / Claude) agar langsung dibuatkan aplikasinya tanpa salah paham!
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => setActiveView('export_center')}
                  className="w-full py-1.5 bg-[#6f42c1] hover:bg-[#5a32a3] text-white rounded text-[11px] font-bold transition-colors cursor-pointer flex items-center justify-center gap-1"
                >
                  <span>Buka Pusat Unduh</span>
                  <i className="fa-solid fa-arrow-right text-[10px]"></i>
                </button>
              </div>
            </div>
          </AdminCard>

          {/* Analogy & Core Mindset Box */}
          <div className="bg-amber-50 border border-amber-200 rounded-[4px] p-4 text-xs text-amber-900">
            <div className="flex items-center gap-2 font-bold text-sm mb-1.5">
              <i className="fa-solid fa-lightbulb text-amber-600 text-base"></i>
              <span>Prinsip Emas: "Jelaskan Seperti Menjelaskan ke Manusia Biasa"</span>
            </div>
            <p className="leading-relaxed">
              Anda tidak perlu memikirkan kode rumit seperti <code>SQL</code>, <code>API</code>, atau <code>Database</code>. Tuliskan saja apa yang pengguna lihat di mata mereka: <em>"Perawat mengklik tombol Simpan, sistem mengecek apakah NIK sudah diisi, jika sudah maka muncul pesan hijau dan nomor antrean dicetak."</em>
            </p>
          </div>
        </div>
      )}

      {/* TAB 2: STEP 1 - MENU HIERARCHY */}
      {activeTab === 'STEP_1_MENU' && (
        <div className="space-y-4">
          <AdminCard
            title="Langkah 1: Menyusun Struktur Menu Aplikasi (Tingkat 1 sampai 4)"
            icon="fa-solid fa-folder-tree"
            variant="outline-success"
          >
            <p className="text-xs text-gray-700 mb-3 leading-relaxed">
              Sebelum mencatat alur tombol, kita perlu membuat denah atau daftar menu aplikasi kita. Di Visual RE-Engine, menu dibagi menjadi <strong>4 Tingkat (Level)</strong> agar sangat rapi dan mudah dicari:
            </p>

            <div className="space-y-3">
              {/* Level 1 */}
              <div className="p-3 bg-gray-50 border-l-4 border-gray-700 rounded text-xs">
                <div className="flex items-center justify-between font-bold text-gray-900 mb-1">
                  <span className="flex items-center gap-2">
                    <span className="bg-gray-800 text-white text-[10px] px-2 py-0.5 rounded">Tingkat 1</span>
                    <span>Sistem Utama (Nama Aplikasi / Proyek)</span>
                  </span>
                  <span className="text-[10px] text-gray-500 font-mono">Kode: SYS-01</span>
                </div>
                <p className="text-gray-600 text-[11px] mb-1">
                  Ini adalah nama besar keseluruhan aplikasi Anda.
                </p>
                <div className="p-1.5 bg-white border border-gray-200 rounded text-[11px] text-gray-800">
                  <strong>Contoh:</strong> <em>"Sistem Informasi Manajemen Rumah Sakit Sehat Sejahtera"</em> atau <em>"Aplikasi Toko Online Berkah"</em>.
                </div>
              </div>

              {/* Level 2 */}
              <div className="p-3 bg-blue-50 border-l-4 border-blue-600 rounded text-xs">
                <div className="flex items-center justify-between font-bold text-blue-900 mb-1">
                  <span className="flex items-center gap-2">
                    <span className="bg-blue-600 text-white text-[10px] px-2 py-0.5 rounded">Tingkat 2</span>
                    <span>Bagian / Modul Utama</span>
                  </span>
                  <span className="text-[10px] text-blue-700 font-mono">Kode: MOD-PELAYANAN</span>
                </div>
                <p className="text-gray-600 text-[11px] mb-1">
                  Kelompok menu besar yang mengelompokkan urusan sejenis (seperti pembagian departemen kantor).
                </p>
                <div className="p-1.5 bg-white border border-blue-200 rounded text-[11px] text-gray-800">
                  <strong>Contoh:</strong> <em>"Modul Rawat Jalan"</em>, <em>"Modul Apotek & Obat"</em>, <em>"Modul Kasir & Keuangan"</em>.
                </div>
              </div>

              {/* Level 3 */}
              <div className="p-3 bg-emerald-50 border-l-4 border-emerald-600 rounded text-xs">
                <div className="flex items-center justify-between font-bold text-emerald-900 mb-1">
                  <span className="flex items-center gap-2">
                    <span className="bg-emerald-600 text-white text-[10px] px-2 py-0.5 rounded">Tingkat 3</span>
                    <span>Menu / Halaman / Formulir</span>
                  </span>
                  <span className="text-[10px] text-emerald-700 font-mono">Kode: MNU-DAFTAR-PASIEN</span>
                </div>
                <p className="text-gray-600 text-[11px] mb-1">
                  Halaman spesifik yang dibuka pengguna di layar (tempat formulir atau tabel data berada).
                </p>
                <div className="p-1.5 bg-white border border-emerald-200 rounded text-[11px] text-gray-800">
                  <strong>Contoh:</strong> <em>"Formulir Pendaftaran Pasien Baru"</em>, <em>"Daftar Riwayat Rekam Medis"</em>, <em>"Laporan Stok Obat"</em>.
                </div>
              </div>

              {/* Level 4 */}
              <div className="p-3 bg-amber-50 border-l-4 border-amber-500 rounded text-xs">
                <div className="flex items-center justify-between font-bold text-amber-900 mb-1">
                  <span className="flex items-center gap-2">
                    <span className="bg-amber-500 text-white text-[10px] px-2 py-0.5 rounded">Tingkat 4</span>
                    <span>Tombol / Fitur Khusus yang Bisa Diklik</span>
                  </span>
                  <span className="text-[10px] text-amber-800 font-mono">Kode: FT-SIMPAN-PASIEN</span>
                </div>
                <p className="text-gray-600 text-[11px] mb-1">
                  Tombol atau aksi interaktif di dalam halaman menu tersebut yang akan menjalankan alur kerja.
                </p>
                <div className="p-1.5 bg-white border border-amber-200 rounded text-[11px] text-gray-800">
                  <strong>Contoh:</strong> <em>"Tombol Simpan Pasien Baru"</em>, <em>"Tombol Cetak Kartu Berobat"</em>, <em>"Tombol Batalkan Pendaftaran"</em>.
                </div>
              </div>
            </div>

            <div className="mt-4 pt-3 border-t border-gray-200 flex items-center justify-between">
              <span className="text-xs text-gray-600">
                Sudah siap menyusun daftar menu dan tombol aplikasi Anda?
              </span>
              <button
                type="button"
                onClick={() => setActiveView('menu_configurator')}
                className="px-3 py-1.5 bg-[#28a745] hover:bg-[#218838] text-white text-xs font-bold rounded shadow-xs transition-colors cursor-pointer flex items-center gap-1.5"
              >
                <i className="fa-solid fa-plus"></i>
                <span>Buka Form Susun Menu (Langkah 1)</span>
              </button>
            </div>
          </AdminCard>
        </div>
      )}

      {/* TAB 3: STEP 2 - 6 GOLDEN QUESTIONS (INTERACTIVE) */}
      {activeTab === 'STEP_2_SIX_QUESTIONS' && (
        <div className="space-y-4">
          <AdminCard
            title="Langkah 2: Menjawab 6 Pertanyaan Emas untuk Tiap Tombol"
            icon="fa-solid fa-bolt-lightning"
            variant="outline-warning"
          >
            <p className="text-xs text-gray-700 mb-3 leading-relaxed">
              Inilah inti kekuatan dari Visual RE-Engine. Setiap kali Anda ingin menjelaskan apa yang terjadi saat sebuah tombol ditekan, Anda cukup menjawab <strong>6 pertanyaan runtut</strong> berikut. Klik tombol di bawah untuk melihat penjelasan dan contoh setiap pertanyaan:
            </p>

            {/* Interactive Selector Buttons */}
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2 mb-4">
              <button
                type="button"
                onClick={() => setInteractiveField('who')}
                className={`p-2 rounded text-left border transition-all cursor-pointer ${
                  interactiveField === 'who'
                    ? 'bg-blue-600 text-white border-blue-700 shadow-xs font-bold'
                    : 'bg-gray-50 text-gray-700 border-gray-200 hover:bg-gray-100'
                }`}
              >
                <span className="block text-[10px] opacity-80 uppercase">Pertanyaan 1</span>
                <span className="text-xs font-semibold flex items-center gap-1">
                  <i className="fa-solid fa-user text-[11px]"></i> SIAPA
                </span>
              </button>

              <button
                type="button"
                onClick={() => setInteractiveField('from')}
                className={`p-2 rounded text-left border transition-all cursor-pointer ${
                  interactiveField === 'from'
                    ? 'bg-blue-600 text-white border-blue-700 shadow-xs font-bold'
                    : 'bg-gray-50 text-gray-700 border-gray-200 hover:bg-gray-100'
                }`}
              >
                <span className="block text-[10px] opacity-80 uppercase">Pertanyaan 2</span>
                <span className="text-xs font-semibold flex items-center gap-1">
                  <i className="fa-solid fa-window-maximize text-[11px]"></i> DARI MANA
                </span>
              </button>

              <button
                type="button"
                onClick={() => setInteractiveField('action')}
                className={`p-2 rounded text-left border transition-all cursor-pointer ${
                  interactiveField === 'action'
                    ? 'bg-blue-600 text-white border-blue-700 shadow-xs font-bold'
                    : 'bg-gray-50 text-gray-700 border-gray-200 hover:bg-gray-100'
                }`}
              >
                <span className="block text-[10px] opacity-80 uppercase">Pertanyaan 3</span>
                <span className="text-xs font-semibold flex items-center gap-1">
                  <i className="fa-solid fa-hand-pointer text-[11px]"></i> TINDAKAN
                </span>
              </button>

              <button
                type="button"
                onClick={() => setInteractiveField('logic')}
                className={`p-2 rounded text-left border transition-all cursor-pointer ${
                  interactiveField === 'logic'
                    ? 'bg-blue-600 text-white border-blue-700 shadow-xs font-bold'
                    : 'bg-gray-50 text-gray-700 border-gray-200 hover:bg-gray-100'
                }`}
              >
                <span className="block text-[10px] opacity-80 uppercase">Pertanyaan 4</span>
                <span className="text-xs font-semibold flex items-center gap-1">
                  <i className="fa-solid fa-scale-balanced text-[11px]"></i> ATURAN
                </span>
              </button>

              <button
                type="button"
                onClick={() => setInteractiveField('output')}
                className={`p-2 rounded text-left border transition-all cursor-pointer ${
                  interactiveField === 'output'
                    ? 'bg-blue-600 text-white border-blue-700 shadow-xs font-bold'
                    : 'bg-gray-50 text-gray-700 border-gray-200 hover:bg-gray-100'
                }`}
              >
                <span className="block text-[10px] opacity-80 uppercase">Pertanyaan 5</span>
                <span className="text-xs font-semibold flex items-center gap-1">
                  <i className="fa-solid fa-circle-check text-[11px]"></i> HASIL
                </span>
              </button>

              <button
                type="button"
                onClick={() => setInteractiveField('to')}
                className={`p-2 rounded text-left border transition-all cursor-pointer ${
                  interactiveField === 'to'
                    ? 'bg-blue-600 text-white border-blue-700 shadow-xs font-bold'
                    : 'bg-gray-50 text-gray-700 border-gray-200 hover:bg-gray-100'
                }`}
              >
                <span className="block text-[10px] opacity-80 uppercase">Pertanyaan 6</span>
                <span className="text-xs font-semibold flex items-center gap-1">
                  <i className="fa-solid fa-location-arrow text-[11px]"></i> TUJUAN
                </span>
              </button>
            </div>

            {/* Interactive Details Panel */}
            {(() => {
              const guide = fieldGuides[interactiveField];
              return (
                <div className="p-4 bg-white border-2 border-blue-200 rounded-[4px] shadow-xs space-y-3">
                  <div className="flex items-center justify-between border-b border-gray-200 pb-2">
                    <div>
                      <span className="text-[10px] font-bold bg-blue-100 text-blue-800 px-2 py-0.5 rounded">
                        Pertanyaan {guide.number} dari 6
                      </span>
                      <h2 className="text-base font-bold text-gray-900 mt-1">{guide.title}</h2>
                    </div>
                    <span className="text-xs text-gray-500 font-medium italic hidden sm:inline">
                      "{guide.analogy}"
                    </span>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                    {/* Good Example */}
                    <div className="p-3 bg-emerald-50 border border-emerald-200 rounded">
                      <div className="font-bold text-emerald-900 flex items-center gap-1.5 mb-1">
                        <i className="fa-solid fa-circle-check text-emerald-600"></i>
                        <span>Contoh Pengisian yang Baik & Jelas:</span>
                      </div>
                      <p className="text-gray-800 text-[11px] font-medium leading-relaxed">
                        {guide.goodExample}
                      </p>
                    </div>

                    {/* Bad Example */}
                    <div className="p-3 bg-red-50 border border-red-200 rounded">
                      <div className="font-bold text-red-900 flex items-center gap-1.5 mb-1">
                        <i className="fa-solid fa-circle-xmark text-red-600"></i>
                        <span>Contoh yang Terlalu Singkat / Membingungkan:</span>
                      </div>
                      <p className="text-gray-800 text-[11px] font-medium leading-relaxed">
                        {guide.badExample}
                      </p>
                    </div>
                  </div>

                  <div className="p-3 bg-blue-50 border border-blue-200 rounded text-xs text-blue-900">
                    <strong>Mengapa kolom ini sangat penting?</strong> {guide.why}
                    <div className="mt-1 text-[11px] text-blue-800">
                      💡 <strong>Tips Menulis:</strong> {guide.tips}
                    </div>
                  </div>
                </div>
              );
            })()}

            <div className="mt-4 pt-3 border-t border-gray-200 flex items-center justify-between">
              <span className="text-xs text-gray-600">
                Ingin langsung mencoba mengisi form 6 pertanyaan ini?
              </span>
              <button
                type="button"
                onClick={() => setActiveView('req_builder')}
                className="px-3 py-1.5 bg-[#007bff] hover:bg-[#0069d9] text-white text-xs font-bold rounded shadow-xs transition-colors cursor-pointer flex items-center gap-1.5"
              >
                <i className="fa-solid fa-pen-to-square"></i>
                <span>Buka Form Catat Alur Kerja (Langkah 2)</span>
              </button>
            </div>
          </AdminCard>
        </div>
      )}

      {/* TAB 4: STEP BRANCHES (IF / ELSE) */}
      {activeTab === 'STEP_BRANCHES' && (
        <div className="space-y-4">
          <AdminCard
            title="Panduan Jalur Khusus & Penanganan Saat Gagal (If / Else)"
            icon="fa-solid fa-code-branch"
            variant="outline-warning"
          >
            <p className="text-xs text-gray-700 mb-3 leading-relaxed">
              Di kehidupan nyata, tidak semua proses selalu berjalan mulus. Kadang pengguna salah memasukkan password, saldo tidak cukup, atau ada kolom wajib yang terlewat. Di Visual RE-Engine, Anda bisa menambahkan <strong>Jalur Kondisi Khusus (If / Else)</strong> dengan sangat mudah!
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs mb-4">
              {/* Jalur Normal */}
              <div className="p-3 bg-emerald-50 border border-emerald-300 rounded">
                <div className="flex items-center gap-1.5 font-bold text-emerald-900 mb-2">
                  <i className="fa-solid fa-road text-emerald-600 text-sm"></i>
                  <span>Alur Utama Normal (Semua Data Benar / Sukses)</span>
                </div>
                <p className="text-[11px] text-gray-700 leading-relaxed mb-2">
                  Ini adalah alur ketika semua syarat terpenuhi tanpa hambatan.
                </p>
                <div className="p-2 bg-white rounded border border-emerald-200 text-[11px]">
                  <strong>Contoh:</strong> Password benar ➔ Langsung masuk ke Halaman Beranda.
                </div>
              </div>

              {/* Jalur Gagal */}
              <div className="p-3 bg-amber-50 border border-amber-300 rounded">
                <div className="flex items-center gap-1.5 font-bold text-amber-900 mb-2">
                  <i className="fa-solid fa-triangle-exclamation text-amber-600 text-sm"></i>
                  <span>Jalur Khusus / Penanganan Gagal (If / Else)</span>
                </div>
                <p className="text-[11px] text-gray-700 leading-relaxed mb-2">
                  Ini adalah alur cadangan jika terjadi kesalahan atau syarat tidak terpenuhi.
                </p>
                <div className="p-2 bg-white rounded border border-amber-200 text-[11px]">
                  <strong>Contoh:</strong> JIKA password salah ➔ Munculkan pesan merah "Password Salah" ➔ Tetap di halaman login dan beri tombol "Lupa Password".
                </div>
              </div>
            </div>

            <div className="p-3.5 bg-gray-50 border border-gray-200 rounded text-xs">
              <h4 className="font-bold text-gray-900 mb-2 flex items-center gap-1.5">
                <i className="fa-solid fa-list-check text-blue-600"></i>
                <span>3 Hal yang Diisi pada Jalur Khusus (If / Else):</span>
              </h4>
              <ul className="space-y-1.5 text-[11px] text-gray-700 list-disc list-inside">
                <li>
                  <strong>Kondisi (JIKA):</strong> Kejadian apa yang memicu jalur ini? <em>(Contoh: "Jika saldo dompet kurang dari total belanja")</em>.
                </li>
                <li>
                  <strong>Hasil (MAKA):</strong> Apa pesan atau respon yang keluar? <em>(Contoh: "Tampilkan pesan merah 'Saldo Tidak Mencukupi'")</em>.
                </li>
                <li>
                  <strong>Tujuan (KE MANA):</strong> Layar mana yang dituju? <em>(Contoh: "Tampilkan tombol Isi Saldo / Tetap di Halaman Pembayaran")</em>.
                </li>
              </ul>
            </div>
          </AdminCard>
        </div>
      )}

      {/* TAB 5: STEP 3 - DIAGRAM & GAP CHECKER */}
      {activeTab === 'STEP_3_DIAGRAM' && (
        <div className="space-y-4">
          <AdminCard
            title="Langkah 3: Membaca Gambar Alur Visual & Memperbaiki Alur Terputus"
            icon="fa-solid fa-diagram-project"
            variant="outline-info"
          >
            <p className="text-xs text-gray-700 mb-3 leading-relaxed">
              Setelah Anda mencatat alur kerja, Anda tidak perlu repot menggambar panah satu per satu di aplikasi desain. Visual RE-Engine <strong>secara otomatis menyusun diagram alur</strong> dan memeriksa apakah ada yang terputus atau terlupakan:
            </p>

            <div className="space-y-3 text-xs mb-4">
              <div className="p-3 bg-blue-50 border-l-4 border-blue-600 rounded">
                <h4 className="font-bold text-blue-900 mb-1 flex items-center gap-1.5">
                  <i className="fa-solid fa-eye text-blue-600"></i>
                  <span>Cara Membaca Kotak-Kotak Diagram:</span>
                </h4>
                <p className="text-gray-700 text-[11px] leading-relaxed">
                  Diagram dibaca runtut dari atas ke bawah: Kotak <strong>SIAPA</strong> (Pengguna) ➔ Panah <strong>TINDAKAN</strong> (Klik tombol) ➔ Kotak <strong>ATURAN</strong> (Pemeriksaan data) ➔ Panah <strong>HASIL</strong> (Sukses) ➔ Kotak <strong>TUJUAN</strong> (Pindah layar).
                </p>
              </div>

              <div className="p-3 bg-red-50 border-l-4 border-red-500 rounded">
                <h4 className="font-bold text-red-900 mb-1 flex items-center gap-1.5">
                  <i className="fa-solid fa-triangle-exclamation text-red-600"></i>
                  <span>Apa itu "Catatan Perlu Diperhatikan / Logic Gap"?</span>
                </h4>
                <p className="text-gray-700 text-[11px] leading-relaxed mb-2">
                  Sistem kami memiliki kecerdasan buatan untuk mendeteksi alur buntu. Misalnya jika Anda lupa mengisi tujuan layar setelah tombol diklik, atau tombol belum pernah dibuatkan alur sama sekali.
                </p>
                <div className="p-2 bg-white border border-red-200 rounded text-[11px] text-gray-800">
                  💡 <strong>Solusi Cepat:</strong> Cukup klik tombol hijau <strong>"Perbaiki Otomatis"</strong> di halaman Cek Alur, dan sistem akan langsung melengkapi bagian yang terputus!
                </div>
              </div>
            </div>

            <div className="pt-2 flex justify-end">
              <button
                type="button"
                onClick={() => setActiveView('logic_diagram')}
                className="px-3 py-1.5 bg-[#17a2b8] hover:bg-[#138496] text-white text-xs font-bold rounded shadow-xs transition-colors cursor-pointer flex items-center gap-1.5"
              >
                <i className="fa-solid fa-diagram-project"></i>
                <span>Buka Pemeriksa Diagram Alur (Langkah 3)</span>
              </button>
            </div>
          </AdminCard>
        </div>
      )}

      {/* TAB 6: STEP 4 - EXPORT & AI HANDOFF */}
      {activeTab === 'STEP_4_EXPORT' && (
        <div className="space-y-4">
          <AdminCard
            title="Langkah 4: Mengunduh Hasil & Membagikan ke Tim Programmer / AI"
            icon="fa-solid fa-box-archive"
            variant="outline-primary"
          >
            <p className="text-xs text-gray-700 mb-3 leading-relaxed">
              Setelah alur Anda selesai dan tidak ada alur yang buntu, rancangan Anda sudah 100% siap diwujudkan menjadi software nyata. Anda memiliki 4 pilihan berkas unduhan di <strong>Pusat Unduh</strong>:
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs mb-4">
              <div className="p-3 bg-gray-50 border border-gray-200 rounded">
                <div className="font-bold text-gray-900 flex items-center gap-1.5 mb-1">
                  <i className="fa-solid fa-file-lines text-purple-600"></i>
                  <span>1. Dokumen Kebutuhan Lengkap (SRS)</span>
                </div>
                <p className="text-[11px] text-gray-600 leading-relaxed">
                  Dokumen resmi dan rapi yang bisa dicetak dalam format PDF atau Word untuk presentasi ke pimpinan, klien, atau pemangku kepentingan.
                </p>
              </div>

              <div className="p-3 bg-blue-50 border border-blue-200 rounded">
                <div className="font-bold text-blue-900 flex items-center gap-1.5 mb-1">
                  <i className="fa-solid fa-robot text-blue-600"></i>
                  <span>2. Cerita Pengguna & Skenario Uji (Siap AI)</span>
                </div>
                <p className="text-[11px] text-gray-600 leading-relaxed">
                  Format bahasa terstruktur (JIKA-KETIKA-MAKA) yang bisa Anda salin ke ChatGPT, Claude, atau Gemini agar AI langsung membuatkan kode aplikasinya tanpa ada salah tafsir.
                </p>
              </div>

              <div className="p-3 bg-cyan-50 border border-cyan-200 rounded">
                <div className="font-bold text-cyan-900 flex items-center gap-1.5 mb-1">
                  <i className="fa-solid fa-diagram-project text-cyan-600"></i>
                  <span>3. Gambar Diagram Alur (Mermaid)</span>
                </div>
                <p className="text-[11px] text-gray-600 leading-relaxed">
                  Bagan alur visual yang bisa ditempel ke aplikasi dokumentasi seperti Notion, GitHub, atau presentasi PowerPoint.
                </p>
              </div>

              <div className="p-3 bg-amber-50 border border-amber-200 rounded">
                <div className="font-bold text-amber-900 flex items-center gap-1.5 mb-1">
                  <i className="fa-solid fa-brackets-curly text-amber-600"></i>
                  <span>4. Berkas Data Mentah (JSON Backup)</span>
                </div>
                <p className="text-[11px] text-gray-600 leading-relaxed">
                  Berkas cadangan untuk menyimpan seluruh data rancangan Anda agar bisa dibuka kembali di komputer lain kapan saja.
                </p>
              </div>
            </div>

            <div className="pt-2 flex justify-end">
              <button
                type="button"
                onClick={() => setActiveView('export_center')}
                className="px-3 py-1.5 bg-[#6f42c1] hover:bg-[#5a32a3] text-white text-xs font-bold rounded shadow-xs transition-colors cursor-pointer flex items-center gap-1.5"
              >
                <i className="fa-solid fa-file-export"></i>
                <span>Buka Pusat Unduh & Dokumen (Langkah 4)</span>
              </button>
            </div>
          </AdminCard>
        </div>
      )}

      {/* TAB 7: REAL WORLD EXAMPLES */}
      {activeTab === 'REAL_EXAMPLES' && (
        <div className="space-y-4">
          <AdminCard
            title="3 Contoh Studi Kasus Nyata dari Berbagai Bidang"
            icon="fa-solid fa-lightbulb"
            variant="outline-warning"
          >
            <p className="text-xs text-gray-700 mb-3 leading-relaxed">
              Pelajari bagaimana merancang alur kerja dari awal hingga akhir dengan melihat contoh nyata berikut. Klik salah satu studi kasus di bawah ini untuk melihat rincian pengisiannya:
            </p>

            <div className="space-y-3">
              {caseStudies.map((cs, idx) => {
                const isExpanded = expandedCaseStudy === idx;
                return (
                  <div
                    key={idx}
                    className={`bg-white border rounded-[4px] overflow-hidden transition-all shadow-2xs ${cs.color}`}
                  >
                    <button
                      type="button"
                      onClick={() => setExpandedCaseStudy(isExpanded ? null : idx)}
                      className="w-full p-3.5 flex items-center justify-between text-left hover:bg-gray-50/80 cursor-pointer"
                    >
                      <div className="flex items-center gap-2.5">
                        <div className="w-8 h-8 rounded bg-gray-100 flex items-center justify-center text-gray-700 text-sm">
                          <i className={cs.icon}></i>
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <h3 className="font-bold text-gray-900 text-xs">{cs.title}</h3>
                            <span className="text-[10px] bg-gray-100 text-gray-700 font-bold px-2 py-0.5 rounded">
                              {cs.badge}
                            </span>
                          </div>
                          <p className="text-[11px] text-gray-500 mt-0.5">{cs.description}</p>
                        </div>
                      </div>
                      <i className={`fa-solid ${isExpanded ? 'fa-chevron-up' : 'fa-chevron-down'} text-xs text-gray-400`}></i>
                    </button>

                    {isExpanded && (
                      <div className="p-3.5 bg-gray-50/60 border-t border-gray-200 text-xs space-y-2">
                        {cs.steps.map((st, sIdx) => (
                          <div
                            key={sIdx}
                            className="p-2 bg-white border border-gray-200 rounded flex flex-col sm:flex-row sm:items-start gap-1 sm:gap-2.5"
                          >
                            <span className="font-bold text-blue-900 sm:w-36 flex-shrink-0 text-[11px]">
                              {st.label}:
                            </span>
                            <span className="text-gray-800 text-[11px] leading-relaxed whitespace-pre-line">
                              {st.text}
                            </span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </AdminCard>
        </div>
      )}

      {/* TAB 8: GLOSSARY */}
      {activeTab === 'GLOSSARY' && (
        <div className="space-y-4">
          <AdminCard
            title="Kamus Istilah Awam (Glosarium)"
            icon="fa-solid fa-book"
            variant="outline-info"
            tools={
              <div className="relative w-48 sm:w-64">
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Cari arti kata..."
                  className="w-full text-xs px-2.5 py-1 bg-white border border-gray-300 rounded text-gray-800 outline-none focus:ring-1 focus:ring-blue-500"
                />
              </div>
            }
          >
            <p className="text-xs text-gray-700 mb-3 leading-relaxed">
              Menemukan istilah yang terdengar asing? Jangan khawatir, berikut adalah arti istilah teknis yang kami terjemahkan ke dalam bahasa sehari-hari:
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {filteredGlossary.map((item, idx) => (
                <div key={idx} className="p-3 bg-white border border-gray-200 rounded-[4px] shadow-2xs space-y-1.5">
                  <h4 className="font-bold text-blue-900 text-xs flex items-center gap-1.5">
                    <i className="fa-solid fa-bookmark text-blue-500 text-[11px]"></i>
                    <span>{item.term}</span>
                  </h4>
                  <p className="text-gray-700 text-[11px] leading-relaxed">
                    <strong>Arti Sederhana:</strong> {item.simpleMeaning}
                  </p>
                  <div className="p-1.5 bg-gray-50 border border-gray-200 rounded text-[10px] text-gray-600">
                    <strong>Contoh Nyata:</strong> {item.example}
                  </div>
                </div>
              ))}
            </div>

            {filteredGlossary.length === 0 && (
              <div className="text-center py-6 text-gray-400 text-xs">
                Tidak ada istilah yang cocok dengan kata pencarian "{searchQuery}".
              </div>
            )}
          </AdminCard>
        </div>
      )}
    </div>
  );
};
