import React, { useState, useMemo, useEffect } from 'react';
import { MenuItem, Project, RequirementNode } from '../../types';
import { AdminCard } from '../common/AdminCard';
import { MermaidViewer } from '../common/MermaidViewer';
import {
  compileToMermaid,
  generateSequenceDiagram,
  analyzeLogicGaps,
  LogicGapIssue,
} from '../../utils/helpers';

interface LogicInspectorViewProps {
  activeProject?: Project;
  menuItems: MenuItem[];
  requirements: RequirementNode[];
  selectedReqId?: string;
  onNavigateToBuilder?: (req: RequirementNode, fieldToFocus?: string) => void;
  onUpdateRequirement?: (req: RequirementNode) => void;
}

export const LogicInspectorView: React.FC<LogicInspectorViewProps> = ({
  activeProject,
  menuItems,
  requirements,
  selectedReqId,
  onNavigateToBuilder,
  onUpdateRequirement,
}) => {
  const [activeTab, setActiveTab] = useState<'SPLIT_VIEW' | 'DIAGRAM_ONLY' | 'CODE_ONLY' | 'SEQUENCE'>('SPLIT_VIEW');
  const [diagramDirection, setDiagramDirection] = useState<'TD' | 'LR'>('TD');
  const [styleMode, setStyleMode] = useState<'CANONICAL' | 'SUBGRAPH'>('CANONICAL');
  const [filterModuleId, setFilterModuleId] = useState<string>('ALL');
  const [filterFeatureId, setFilterFeatureId] = useState<string>('ALL');
  const [inspectedReqId, setInspectedReqId] = useState<string | null>(selectedReqId || null);

  // Manual code override state for live compiler experimentation
  const [customCode, setCustomCode] = useState<string>('');
  const [isCustomMode, setIsCustomMode] = useState<boolean>(false);
  const [copiedCode, setCopiedCode] = useState<boolean>(false);

  // Filtered requirements
  const modules = useMemo(() => menuItems.filter((m) => m.level === 2), [menuItems]);
  const features = useMemo(() => menuItems.filter((m) => m.level === 4), [menuItems]);

  const filteredRequirements = useMemo(() => {
    return requirements.filter((r) => {
      if (filterModuleId !== 'ALL' && r.moduleId !== filterModuleId) return false;
      if (filterFeatureId !== 'ALL' && r.featureId !== filterFeatureId) return false;
      return true;
    });
  }, [requirements, filterModuleId, filterFeatureId]);

  // Automated Logic Gap Inspector Analysis
  const logicGaps = useMemo(() => {
    return analyzeLogicGaps(requirements, menuItems);
  }, [requirements, menuItems]);

  const criticalGapsCount = useMemo(
    () => logicGaps.filter((g) => g.severity === 'CRITICAL').length,
    [logicGaps]
  );
  const warningGapsCount = useMemo(
    () => logicGaps.filter((g) => g.severity === 'WARNING').length,
    [logicGaps]
  );
  const infoGapsCount = useMemo(
    () => logicGaps.filter((g) => g.severity === 'INFO').length,
    [logicGaps]
  );

  // Compile Mermaid Flowchart via compileToMermaid(projectState)
  const compiledCode = useMemo(() => {
    if (activeTab === 'SEQUENCE') {
      return generateSequenceDiagram(filteredRequirements);
    }
    return compileToMermaid(
      { requirements: filteredRequirements, menuItems, project: activeProject },
      {
        direction: diagramDirection,
        styleMode: styleMode,
      }
    );
  }, [filteredRequirements, menuItems, activeProject, diagramDirection, styleMode, activeTab]);

  // Active chart code passed to renderer
  const activeChart = isCustomMode ? customCode : compiledCode;

  // Keep customCode in sync when compiledCode changes unless user edited custom
  useEffect(() => {
    if (!isCustomMode) {
      setCustomCode(compiledCode);
    }
  }, [compiledCode, isCustomMode]);

  const inspectedRequirement = useMemo(() => {
    return requirements.find((r) => r.id === inspectedReqId) || filteredRequirements[0] || null;
  }, [requirements, inspectedReqId, filteredRequirements]);

  // Quick auto-fix handler for gaps
  const handleQuickFix = (gap: LogicGapIssue) => {
    if (!gap.reqId || !onUpdateRequirement) {
      if (gap.reqId && onNavigateToBuilder) {
        const targetReq = requirements.find((r) => r.id === gap.reqId);
        if (targetReq) onNavigateToBuilder(targetReq, gap.fieldToFocus);
      }
      return;
    }

    const targetReq = requirements.find((r) => r.id === gap.reqId);
    if (!targetReq) return;

    if (gap.type === 'MISSING_TO_DESTINATION') {
      // Auto assign standard destination
      const updated: RequirementNode = {
        ...targetReq,
        toWhere: `${targetReq.title} Workplace Desk / Output Store`,
        toWhereType: 'ui_view',
        updatedAt: new Date().toISOString(),
      };
      onUpdateRequirement(updated);
    } else if (gap.type === 'MISSING_ELSE_BRANCH') {
      // Auto add ELSE fallback branch
      const newBranch = {
        id: `branch-${Date.now()}`,
        label: 'ELSE: Validation / Rule Failed',
        condition: 'When input validation or authorization fails',
        output: 'Display error dialog with corrective guidance',
        toWhere: 'Current Form View with Error Highlight',
        toWhereType: 'ui_view' as const,
      };

      const updated: RequirementNode = {
        ...targetReq,
        hasBranching: true,
        branches: [...(targetReq.branches || []), newBranch],
        updatedAt: new Date().toISOString(),
      };
      onUpdateRequirement(updated);
    }
  };

  const handleCopyCode = () => {
    navigator.clipboard.writeText(activeChart);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  const handleResetToCompiled = () => {
    setCustomCode(compiledCode);
    setIsCustomMode(false);
  };

  return (
    <div className="logic-inspector-view space-y-4">
      {/* Header Banner */}
      <div className="bg-white p-4 rounded-[4px] border border-[#e9ecef] shadow-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-3">
        <div>
          <div className="flex items-center gap-2">
            <span className="bg-[#17a2b8] text-white text-xs font-bold px-2 py-0.5 rounded">
              LANGKAH 3
            </span>
            <h1 className="text-xl font-bold text-gray-900 tracking-tight">
              Bagan Visual Alur Kerja & Pemeriksa Kelengkapan
            </h1>
          </div>
          <p className="text-xs text-gray-600 mt-1">
            Mengubah catatan alur kerja 6 pertanyaan (SIAPA → DARI MANA → TINDAKAN → ATURAN → HASIL → TUJUAN) menjadi diagram visual secara otomatis, serta memeriksa bagian yang belum lengkap atau terputus.
          </p>
        </div>

        {/* View Layout Tabs */}
        <div className="flex items-center bg-[#f8f9fa] p-1 rounded border border-gray-300 text-xs font-semibold">
          <button
            type="button"
            onClick={() => setActiveTab('SPLIT_VIEW')}
            className={`px-3 py-1.5 rounded transition-all cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'SPLIT_VIEW'
                ? 'bg-[#007bff] text-white font-bold shadow-xs'
                : 'text-gray-700 hover:text-black'
            }`}
          >
            <i className="fa-solid fa-columns"></i>
            <span>Berdampingan</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('DIAGRAM_ONLY')}
            className={`px-3 py-1.5 rounded transition-all cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'DIAGRAM_ONLY'
                ? 'bg-[#007bff] text-white font-bold shadow-xs'
                : 'text-gray-700 hover:text-black'
            }`}
          >
            <i className="fa-solid fa-diagram-project"></i>
            <span>Diagram Saja</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('CODE_ONLY')}
            className={`px-3 py-1.5 rounded transition-all cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'CODE_ONLY'
                ? 'bg-[#007bff] text-white font-bold shadow-xs'
                : 'text-gray-700 hover:text-black'
            }`}
          >
            <i className="fa-solid fa-code"></i>
            <span>Teks Diagram</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('SEQUENCE')}
            className={`px-3 py-1.5 rounded transition-all cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'SEQUENCE'
                ? 'bg-[#007bff] text-white font-bold shadow-xs'
                : 'text-gray-700 hover:text-black'
            }`}
          >
            <i className="fa-solid fa-arrows-split-up-and-left"></i>
            <span>Urutan Langkah</span>
          </button>
        </div>
      </div>

      {/* FEATURE 2: LOGIC GAP INSPECTOR (Validation Warning Box) */}
      {logicGaps.length > 0 ? (
        <div
          className={`callout ${
            criticalGapsCount > 0 ? 'callout-danger' : 'callout-warning'
          } text-xs`}
        >
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-2">
            <h2 className="text-sm font-bold flex items-center gap-2 text-gray-900">
              <i
                className={`fa-solid ${
                  criticalGapsCount > 0
                    ? 'fa-circle-xmark text-[#dc3545]'
                    : 'fa-triangle-exclamation text-[#ffc107]'
                } text-base`}
              ></i>
              <span>
                Pemeriksa Alur Kerja:{' '}
                <span className="text-red-700 font-bold">{logicGaps.length} Catatan Perlu Diperhatikan</span>
              </span>
            </h2>

            <div className="flex items-center gap-2 text-[11px] font-bold">
              {criticalGapsCount > 0 && (
                <span className="bg-red-100 text-red-800 px-2 py-0.5 rounded border border-red-300">
                  {criticalGapsCount} Belum Ada Tujuan Akhir
                </span>
              )}
              {warningGapsCount > 0 && (
                <span className="bg-amber-100 text-amber-900 px-2 py-0.5 rounded border border-amber-300">
                  {warningGapsCount} Perlu Jalur Penanganan Gagal
                </span>
              )}
              {infoGapsCount > 0 && (
                <span className="bg-blue-100 text-blue-900 px-2 py-0.5 rounded border border-blue-300">
                  {infoGapsCount} Tombol Belum Dibuatkan Alur
                </span>
              )}
            </div>
          </div>

          <p className="text-gray-700 mb-3">
            Sistem mendeteksi beberapa alur kerja yang belum lengkap tujuannya atau belum memiliki penanganan saat pengguna salah mengisi:
          </p>

          <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
            {logicGaps.map((gap) => (
              <div
                key={gap.id}
                className="p-2.5 bg-white rounded border border-gray-200 shadow-2xs flex flex-col md:flex-row md:items-center justify-between gap-2"
              >
                <div className="space-y-0.5">
                  <div className="flex items-center gap-2">
                    <span
                      className={`text-[10px] font-bold px-1.5 py-0.2 rounded uppercase ${
                        gap.severity === 'CRITICAL'
                          ? 'bg-red-600 text-white'
                          : gap.severity === 'WARNING'
                          ? 'bg-amber-500 text-gray-900 font-bold'
                          : 'bg-cyan-600 text-white'
                      }`}
                    >
                      {gap.severity === 'CRITICAL' ? 'PENTING' : gap.severity === 'WARNING' ? 'PERINGATAN' : 'INFO'}
                    </span>
                    <span className="font-bold text-gray-900 text-xs">{gap.title}</span>
                  </div>
                  <p className="text-gray-600 text-[11px]">{gap.description}</p>
                  <p className="text-emerald-700 font-medium text-[11px]">
                    <i className="fa-solid fa-lightbulb text-amber-500 mr-1"></i>
                    <strong>Saran Perbaikan:</strong> {gap.fixSuggestion}
                  </p>
                </div>

                <div className="flex items-center gap-1.5 flex-shrink-0">
                  {onUpdateRequirement && gap.reqId && (
                    <button
                      type="button"
                      onClick={() => handleQuickFix(gap)}
                      className="px-2.5 py-1 bg-[#28a745] hover:bg-[#218838] text-white rounded text-[11px] font-bold cursor-pointer transition-colors shadow-2xs"
                    >
                      <i className="fa-solid fa-wand-magic-sparkles mr-1"></i>
                      Perbaiki Otomatis
                    </button>
                  )}

                  {gap.reqId && onNavigateToBuilder && (
                    <button
                      type="button"
                      onClick={() => {
                        const target = requirements.find((r) => r.id === gap.reqId);
                        if (target) onNavigateToBuilder(target, gap.fieldToFocus);
                      }}
                      className="px-2.5 py-1 bg-[#007bff] hover:bg-[#0069d9] text-white rounded text-[11px] font-bold cursor-pointer transition-colors"
                    >
                      <i className="fa-solid fa-pen-to-square mr-1"></i>
                      Ubah di Form Alur
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      ) : (
        <div className="callout callout-success text-xs">
          <div className="flex items-center gap-2 font-bold text-green-900">
            <i className="fa-solid fa-circle-check text-green-600 text-base"></i>
            <span>Semua Alur Kerja Lengkap dan Terhubung: Tidak Ada Alur yang Buntu atau Terputus</span>
          </div>
          <p className="text-green-800 text-[11px] mt-0.5">
            Setiap tindakan tombol sudah memiliki tujuan akhir yang jelas, isian 6-pertanyaan lengkap, dan alur penanganan kondisi yang rapi.
          </p>
        </div>
      )}

      {/* Filter and Compiler Configuration Bar */}
      <AdminCard
        title="Pengaturan Tampilan Diagram & Saringan Data"
        icon="fa-solid fa-sliders"
        variant="outline-info"
        bodyClassName="py-2.5"
      >
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 text-xs">
          {/* Module Filter */}
          <div>
            <label htmlFor="comp-module-filter" className="block text-[10px] font-bold text-gray-700 uppercase mb-1">
              Saring Berdasarkan Bagian / Modul
            </label>
            <select
              id="comp-module-filter"
              value={filterModuleId}
              onChange={(e) => setFilterModuleId(e.target.value)}
              className="w-full p-1.5 text-xs bg-white border border-gray-300 rounded font-semibold text-gray-800"
            >
              <option value="ALL">Semua Bagian / Modul ({modules.length})</option>
              {modules.map((m) => (
                <option key={m.id} value={m.id}>
                  {m.code} - {m.name}
                </option>
              ))}
            </select>
          </div>

          {/* Feature Filter */}
          <div>
            <label htmlFor="comp-feature-filter" className="block text-[10px] font-bold text-gray-700 uppercase mb-1">
              Saring Berdasarkan Tombol / Fitur
            </label>
            <select
              id="comp-feature-filter"
              value={filterFeatureId}
              onChange={(e) => setFilterFeatureId(e.target.value)}
              className="w-full p-1.5 text-xs bg-white border border-gray-300 rounded font-semibold text-gray-800"
            >
              <option value="ALL">Semua Tombol / Fitur ({features.length})</option>
              {features.map((f) => (
                <option key={f.id} value={f.id}>
                  {f.code} - {f.name}
                </option>
              ))}
            </select>
          </div>

          {/* Flowchart Direction */}
          <div>
            <label className="block text-[10px] font-bold text-gray-700 uppercase mb-1">
              Arah Alur Diagram
            </label>
            <div className="flex items-center gap-1">
              <button
                type="button"
                onClick={() => setDiagramDirection('TD')}
                className={`flex-1 py-1.5 rounded text-xs font-bold transition-all cursor-pointer ${
                  diagramDirection === 'TD'
                    ? 'bg-[#007bff] text-white shadow-2xs'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                <i className="fa-solid fa-arrow-down mr-1"></i>Atas ke Bawah
              </button>
              <button
                type="button"
                onClick={() => setDiagramDirection('LR')}
                className={`flex-1 py-1.5 rounded text-xs font-bold transition-all cursor-pointer ${
                  diagramDirection === 'LR'
                    ? 'bg-[#007bff] text-white shadow-2xs'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                <i className="fa-solid fa-arrow-right mr-1"></i>Kiri ke Kanan
              </button>
            </div>
          </div>

          {/* Compiler Node Grouping Style */}
          <div>
            <label className="block text-[10px] font-bold text-gray-700 uppercase mb-1">
              Bentuk Pengelompokan
            </label>
            <div className="flex items-center gap-1">
              <button
                type="button"
                onClick={() => setStyleMode('CANONICAL')}
                className={`flex-1 py-1.5 rounded text-xs font-bold transition-all cursor-pointer ${
                  styleMode === 'CANONICAL'
                    ? 'bg-[#17a2b8] text-white shadow-2xs'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
                title="Tampilan alur langsung: SIAPA -> TINDAKAN -> ATURAN -> HASIL -> TUJUAN"
              >
                Alur Langsung
              </button>
              <button
                type="button"
                onClick={() => setStyleMode('SUBGRAPH')}
                className={`flex-1 py-1.5 rounded text-xs font-bold transition-all cursor-pointer ${
                  styleMode === 'SUBGRAPH'
                    ? 'bg-[#17a2b8] text-white shadow-2xs'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
                title="Kelompokkan tiap alur ke dalam kotak pembungkus tersendiri"
              >
                Kotak Kelompok
              </button>
            </div>
          </div>
        </div>
      </AdminCard>

      {/* FEATURE 1: LIVE MERMAID.JS DIAGRAM COMPILER (Split View Layout) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Left Column: Compiler Source Code Editor (in Split View or Code Only) */}
        {(activeTab === 'SPLIT_VIEW' || activeTab === 'CODE_ONLY') && (
          <div className={`${activeTab === 'CODE_ONLY' ? 'lg:col-span-12' : 'lg:col-span-5'} flex flex-col space-y-3`}>
            <AdminCard
              title="Teks Kode Diagram Alur (Mermaid)"
              icon="fa-solid fa-code"
              variant="outline-primary"
              tools={
                <div className="flex items-center gap-1.5">
                  {isCustomMode && (
                    <button
                      type="button"
                      onClick={handleResetToCompiled}
                      className="px-2 py-0.5 bg-amber-500 hover:bg-amber-600 text-white rounded text-[11px] font-bold"
                      title="Kembalikan perubahan manual ke susunan otomatis"
                    >
                      <i className="fa-solid fa-rotate-left mr-1"></i>Kembalikan ke Asli
                    </button>
                  )}
                  <button
                    type="button"
                    onClick={handleCopyCode}
                    className="px-2 py-0.5 bg-blue-600 hover:bg-blue-700 text-white rounded text-[11px] font-bold"
                  >
                    <i className={`fa-solid ${copiedCode ? 'fa-check' : 'fa-copy'} mr-1`}></i>
                    {copiedCode ? 'Tersalin' : 'Salin Kode'}
                  </button>
                </div>
              }
            >
              <div className="text-xs space-y-2">
                <div className="flex items-center justify-between text-[11px] text-gray-600">
                  <span>
                    Format teks diagram dibuat otomatis dari data alur kerja
                  </span>
                  {isCustomMode ? (
                    <span className="text-amber-600 font-bold bg-amber-50 px-1.5 py-0.2 rounded border border-amber-200">
                      Mode Ubah Manual
                    </span>
                  ) : (
                    <span className="text-green-600 font-bold bg-green-50 px-1.5 py-0.2 rounded border border-green-200">
                      Tersusun Otomatis ({filteredRequirements.length} alur)
                    </span>
                  )}
                </div>

                <div className="relative">
                  <textarea
                    value={customCode}
                    onChange={(e) => {
                      setCustomCode(e.target.value);
                      setIsCustomMode(true);
                    }}
                    rows={activeTab === 'CODE_ONLY' ? 18 : 16}
                    className="w-full p-3 font-mono text-xs bg-[#1e2227] text-[#abb2bf] rounded border border-gray-700 focus:ring-1 focus:ring-blue-500 outline-none leading-relaxed resize-y"
                    placeholder="Teks format bagan alur..."
                    spellCheck={false}
                  />
                </div>

                <div className="p-2.5 bg-gray-50 border border-gray-200 rounded text-[11px] text-gray-600 flex items-center justify-between">
                  <div>
                    <strong className="text-gray-800">Format Alur:</strong>{' '}
                    <code>SIAPA --&gt;|TINDAKAN| ATURAN --&gt;|HASIL| TUJUAN</code>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      const sampleSyntax = `graph TD\n  R1_WHO["SIAPA: Perawat (ALUR-01)"]:::whoClass\n  R1_LOG("ATURAN: Periksa NIK & Rekam Medis"):::logicClass\n  R1_TO[("TUJUAN: Basis Data Pasien")]:::targetClass\n  R1_WHO -->|TINDAKAN: Klik Simpan Pendaftaran| R1_LOG\n  R1_LOG -->|HASIL: Data Pasien Berhasil Terdaftar| R1_TO`;
                      setCustomCode(sampleSyntax);
                      setIsCustomMode(true);
                    }}
                    className="text-blue-600 hover:underline font-semibold"
                  >
                    Muat Contoh Teks
                  </button>
                </div>
              </div>
            </AdminCard>

            {/* Quick Node Details Panel */}
            <AdminCard
              title="Rincian Langkah Alur yang Dipilih"
              icon="fa-solid fa-eye"
              variant="outline-secondary"
            >
              {inspectedRequirement ? (
                <div className="space-y-2 text-xs">
                  <div className="flex items-center justify-between">
                    <span className="bg-blue-600 text-white font-mono font-bold px-2 py-0.5 rounded text-[11px]">
                      {inspectedRequirement.reqCode}
                    </span>
                    <span className="font-bold text-gray-800 truncate max-w-[200px]">
                      {inspectedRequirement.title}
                    </span>
                  </div>

                  <div className="grid grid-cols-2 gap-2 text-[11px]">
                    <div className="p-1.5 bg-blue-50 rounded border border-blue-200">
                      <span className="block font-bold text-blue-900 uppercase text-[9px]">SIAPA (PENGGUNA):</span>
                      <span className="text-gray-800">{inspectedRequirement.whoRole}</span>
                    </div>
                    <div className="p-1.5 bg-green-50 rounded border border-green-200">
                      <span className="block font-bold text-green-900 uppercase text-[9px]">TINDAKAN (AKSI):</span>
                      <span className="text-gray-800 truncate block">{inspectedRequirement.action}</span>
                    </div>
                    <div className="p-1.5 bg-amber-50 rounded border border-amber-200 col-span-2">
                      <span className="block font-bold text-amber-900 uppercase text-[9px]">ATURAN (SYARAT):</span>
                      <span className="text-gray-800 font-mono text-[10px]">{inspectedRequirement.logic}</span>
                    </div>
                    <div className="p-1.5 bg-cyan-50 rounded border border-cyan-200">
                      <span className="block font-bold text-cyan-900 uppercase text-[9px]">HASIL (OUTPUT):</span>
                      <span className="text-gray-800 truncate block">{inspectedRequirement.output}</span>
                    </div>
                    <div className="p-1.5 bg-gray-100 rounded border border-gray-300">
                      <span className="block font-bold text-gray-900 uppercase text-[9px]">TUJUAN (KE MANA):</span>
                      <span className="text-gray-800 font-semibold truncate block">{inspectedRequirement.toWhere}</span>
                    </div>
                  </div>

                  {onNavigateToBuilder && (
                    <button
                      type="button"
                      onClick={() => onNavigateToBuilder(inspectedRequirement)}
                      className="w-full mt-2 py-1.5 bg-blue-50 text-blue-700 hover:bg-blue-100 border border-blue-200 rounded font-bold text-xs cursor-pointer flex items-center justify-center gap-1.5"
                    >
                      <i className="fa-solid fa-pen"></i>
                      <span>Buka di Form Alur Kerja</span>
                    </button>
                  )}
                </div>
              ) : (
                <div className="text-center py-4 text-gray-400 text-xs">
                  Pilih salah satu alur kerja untuk melihat rincian langkah dan perpindahan layarnya.
                </div>
              )}
            </AdminCard>
          </div>
        )}

        {/* Right Column: Live Rendered Mermaid Canvas (in Split View or Diagram Only) */}
        {(activeTab === 'SPLIT_VIEW' || activeTab === 'DIAGRAM_ONLY' || activeTab === 'SEQUENCE') && (
          <div className={`${activeTab === 'SPLIT_VIEW' ? 'lg:col-span-7' : 'lg:col-span-12'} min-h-[560px]`}>
            <MermaidViewer
              chart={activeChart}
              className="h-full min-h-[560px]"
            />
          </div>
        )}
      </div>
    </div>
  );
};
