import React, { useState, useMemo } from 'react';
import { HierarchyLevel, MenuItem, Project, RequirementNode } from '../../types';
import { AdminCard } from '../common/AdminCard';
import { buildHierarchyTree, COMMON_FA_ICONS, LEVEL_CONFIG, TreeNode } from '../../utils/helpers';
import { StorageService } from '../../services/storageService';

interface MenuConfiguratorViewProps {
  activeProject?: Project;
  menuItems: MenuItem[];
  requirements: RequirementNode[];
  onRefreshData: () => void;
  onNavigateToBuilderWithFeature?: (moduleId: string, menuId: string, featureId: string) => void;
  onNavigateToHelp?: () => void;
}

export const MenuConfiguratorView: React.FC<MenuConfiguratorViewProps> = ({
  activeProject,
  menuItems,
  requirements,
  onRefreshData,
  onNavigateToBuilderWithFeature,
  onNavigateToHelp,
}) => {
  const [selectedItemId, setSelectedItemId] = useState<string | null>(null);
  const [searchFilter, setSearchFilter] = useState('');
  const [levelFilter, setLevelFilter] = useState<HierarchyLevel | 'ALL'>('ALL');
  const [expandedNodeIds, setExpandedNodeIds] = useState<Set<string>>(() => {
    return new Set(menuItems.map((m) => m.id));
  });

  // Form State
  const [formMode, setFormMode] = useState<'ADD' | 'EDIT'>('ADD');
  const [formLevel, setFormLevel] = useState<HierarchyLevel>(2);
  const [formParentId, setFormParentId] = useState<string>('');
  const [formName, setFormName] = useState('');
  const [formCode, setFormCode] = useState('');
  const [formDescription, setFormDescription] = useState('');
  const [formIcon, setFormIcon] = useState('fa-solid fa-folder');
  const [notification, setNotification] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  const selectedItem = useMemo(() => {
    return menuItems.find((i) => i.id === selectedItemId) || null;
  }, [menuItems, selectedItemId]);

  // Tree nodes
  const hierarchyTree = useMemo(() => {
    return buildHierarchyTree(menuItems, requirements);
  }, [menuItems, requirements]);

  // Handle tree expand/collapse
  const toggleExpand = (nodeId: string) => {
    setExpandedNodeIds((prev) => {
      const next = new Set(prev);
      if (next.has(nodeId)) {
        next.delete(nodeId);
      } else {
        next.add(nodeId);
      }
      return next;
    });
  };

  const expandAll = () => {
    setExpandedNodeIds(new Set(menuItems.map((m) => m.id)));
  };

  const collapseAll = () => {
    setExpandedNodeIds(new Set());
  };

  // Populate form for editing
  const handleSelectItemForEdit = (item: MenuItem) => {
    setSelectedItemId(item.id);
    setFormMode('EDIT');
    setFormLevel(item.level);
    setFormParentId(item.parentId || '');
    setFormName(item.name);
    setFormCode(item.code);
    setFormDescription(item.description || '');
    setFormIcon(item.icon || 'fa-solid fa-folder');
    setNotification(null);
  };

  // Reset form for adding new item
  const handleResetForAdd = (presetParentId?: string, presetLevel?: HierarchyLevel) => {
    setSelectedItemId(null);
    setFormMode('ADD');
    const targetLevel = presetLevel || 2;
    setFormLevel(targetLevel);
    setFormParentId(presetParentId || '');
    setFormName('');
    setFormCode('');
    setFormDescription('');
    setFormIcon(
      targetLevel === 1
        ? 'fa-solid fa-server'
        : targetLevel === 2
        ? 'fa-solid fa-cubes'
        : targetLevel === 3
        ? 'fa-solid fa-list-check'
        : 'fa-solid fa-bolt'
    );
    setNotification(null);
  };

  // Handle parent options based on selected level
  const validParentOptions = useMemo(() => {
    if (formLevel === 1) return []; // Level 1 System has no parent
    if (formLevel === 2) return menuItems.filter((i) => i.level === 1); // Module parent is System
    if (formLevel === 3) return menuItems.filter((i) => i.level === 2); // Menu parent is Module
    if (formLevel === 4) return menuItems.filter((i) => i.level === 3); // Feature parent is Menu
    return [];
  }, [menuItems, formLevel]);

  // Handle Save
  const handleSaveItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formName.trim()) {
      setNotification({ type: 'error', message: 'Nama menu / fitur wajib diisi.' });
      return;
    }

    if (formLevel > 1 && !formParentId) {
      setNotification({
        type: 'error',
        message: `Silakan pilih menu induk (${LEVEL_CONFIG[(formLevel - 1) as HierarchyLevel].name}) untuk item ini.`,
      });
      return;
    }

    // Auto-generate code if empty
    let code = formCode.trim();
    if (!code) {
      const prefix = formLevel === 1 ? 'SIS' : formLevel === 2 ? 'MOD' : formLevel === 3 ? 'MNU' : 'FTR';
      const cleanSlug = formName
        .toUpperCase()
        .replace(/[^A-Z0-9]/g, '-')
        .substring(0, 10);
      code = `${prefix}-${cleanSlug}`;
    }

    const payload = {
      ...(formMode === 'EDIT' && selectedItemId ? { id: selectedItemId } : {}),
      projectId: activeProject?.id || 'proj-medicare-01',
      name: formName.trim(),
      code: code,
      level: formLevel,
      parentId: formLevel === 1 ? null : formParentId || null,
      description: formDescription.trim(),
      icon: formIcon,
      order: menuItems.length + 1,
    };

    const saved = StorageService.saveMenuItem(payload);
    onRefreshData();

    setNotification({
      type: 'success',
      message: `Berhasil ${formMode === 'EDIT' ? 'memperbarui' : 'menambahkan'} "${saved.name}" (${saved.code})!`,
    });

    if (formMode === 'ADD') {
      // Auto expand parent
      if (saved.parentId) {
        setExpandedNodeIds((prev) => new Set([...prev, saved.parentId!]));
      }
      setSelectedItemId(saved.id);
      setFormMode('EDIT');
    }
  };

  // Handle Delete
  const handleDeleteItem = (id: string) => {
    const item = menuItems.find((i) => i.id === id);
    if (!item) return;

    if (
      window.confirm(
        `Apakah Anda yakin ingin menghapus "${item.name}" (${item.code})?\n\nPERINGATAN: Semua sub-menu di bawahnya dan alur kebutuhan yang terhubung juga akan ikut terhapus.`
      )
    ) {
      StorageService.deleteMenuItem(id);
      onRefreshData();
      if (selectedItemId === id) {
        handleResetForAdd();
      }
      setNotification({
        type: 'success',
        message: `Berhasil menghapus "${item.name}" beserta sub-menu terkait.`,
      });
    }
  };

  // Compute live breadcrumb of selected item
  const breadcrumbTrail = useMemo(() => {
    if (!selectedItem) return [];
    const trail: MenuItem[] = [selectedItem];
    let curr = selectedItem;
    while (curr.parentId) {
      const parent = menuItems.find((m) => m.id === curr.parentId);
      if (parent) {
        trail.unshift(parent);
        curr = parent;
      } else {
        break;
      }
    }
    return trail;
  }, [selectedItem, menuItems]);

  // Recursive Tree Node Renderer
  const renderTreeNode = (node: TreeNode, depth: number = 0) => {
    const isExpanded = expandedNodeIds.has(node.item.id);
    const hasChildren = node.children.length > 0;
    const isSelected = selectedItemId === node.item.id;
    const config = LEVEL_CONFIG[node.item.level];

    // Filter check
    const matchesSearch =
      !searchFilter ||
      node.item.name.toLowerCase().includes(searchFilter.toLowerCase()) ||
      node.item.code.toLowerCase().includes(searchFilter.toLowerCase()) ||
      (node.item.description && node.item.description.toLowerCase().includes(searchFilter.toLowerCase()));

    const matchesLevel = levelFilter === 'ALL' || node.item.level === levelFilter;

    if (!matchesSearch && !matchesLevel && !hasChildren) {
      return null;
    }

    return (
      <div key={node.item.id} className="tree-branch mb-1.5 select-none">
        <div
          className={`flex items-center justify-between p-2 rounded border transition-all cursor-pointer ${
            isSelected
              ? 'bg-blue-50/90 border-[#007bff] shadow-xs'
              : 'bg-white hover:bg-gray-50 border-gray-200'
          } ${config.borderClass}`}
          style={{ marginLeft: `${depth * 20}px` }}
          onClick={() => handleSelectItemForEdit(node.item)}
        >
          {/* Left info */}
          <div className="flex items-center gap-2 flex-1 min-w-0 mr-2">
            {/* Expand / Collapse Icon */}
            {hasChildren ? (
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  toggleExpand(node.item.id);
                }}
                className="w-5 h-5 rounded flex items-center justify-center text-gray-500 hover:text-gray-800 hover:bg-gray-200 text-xs"
              >
                <i className={`fa-solid ${isExpanded ? 'fa-chevron-down' : 'fa-chevron-right'}`}></i>
              </button>
            ) : (
              <div className="w-5 h-5 flex items-center justify-center text-gray-300 text-xs">
                <i className="fa-solid fa-circle-dot text-[8px]"></i>
              </div>
            )}

            {/* Level Icon */}
            <div className="w-6 h-6 rounded flex items-center justify-center text-xs bg-gray-100 text-gray-700">
              <i className={node.item.icon || config.icon}></i>
            </div>

            {/* Level Badge */}
            <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded font-mono ${config.badgeClass}`}>
              L{node.item.level}
            </span>

            {/* Code and Name */}
            <div className="truncate flex-1">
              <span className="font-semibold text-xs text-gray-900 mr-1.5">{node.item.name}</span>
              <span className="text-[11px] font-mono text-gray-500 bg-gray-100 px-1 py-0.2 rounded">
                {node.item.code}
              </span>
            </div>
          </div>

          {/* Right badges and quick actions */}
          <div className="flex items-center gap-1.5">
            {/* Requirement Count Badge */}
            {node.requirementCount > 0 ? (
              <span
                className="bg-amber-100 text-amber-900 border border-amber-300 text-[10px] font-bold px-2 py-0.5 rounded-full font-mono flex items-center gap-1"
                title={`${node.requirementCount} alur kebutuhan terhubung`}
              >
                <i className="fa-solid fa-bolt text-[9px] text-amber-600"></i>
                {node.requirementCount} Alur
              </span>
            ) : (
              <span className="text-gray-400 text-[10px] hidden sm:inline">0 Alur</span>
            )}

            {/* Quick Add Child Button (if level < 4) */}
            {node.item.level < 4 && (
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  handleResetForAdd(node.item.id, (node.item.level + 1) as HierarchyLevel);
                }}
                className="p-1 text-gray-500 hover:text-emerald-700 hover:bg-emerald-50 rounded text-xs transition-colors"
                title={`+ Tambah sub-item tingkat ${node.item.level + 1}`}
              >
                <i className="fa-solid fa-plus-circle text-emerald-600"></i>
              </button>
            )}

            {/* Quick Delete */}
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                handleDeleteItem(node.item.id);
              }}
              className="p-1 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded text-xs transition-colors"
              title="Hapus item"
            >
              <i className="fa-solid fa-trash-can"></i>
            </button>
          </div>
        </div>

        {/* Render Children */}
        {hasChildren && isExpanded && (
          <div className="tree-children mt-1">
            {node.children.map((child) => renderTreeNode(child, depth + 1))}
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="menu-configurator-view">
      {/* View Header Banner */}
      <div className="mb-4 bg-white p-4 rounded-[4px] border border-gray-200 shadow-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-3">
        <div>
          <div className="flex items-center gap-2">
            <span className="bg-[#007bff] text-white text-xs font-bold px-2 py-0.5 rounded">
              MENU A
            </span>
            <h1 className="text-xl font-bold text-gray-900 tracking-tight">
              Pengaturan Struktur Menu & Fitur
            </h1>
          </div>
          <p className="text-xs text-gray-600 mt-1">
            Atur susunan menu aplikasi dalam 4 tingkat (Tingkat 1: Sistem Utama → Tingkat 2: Modul/Bagian → Tingkat 3: Menu Layar → Tingkat 4: Tombol/Fitur) agar alur kebutuhan sistem tersusun rapi.
          </p>
        </div>

        <div className="flex items-center gap-2">
          {onNavigateToHelp && (
            <button
              type="button"
              onClick={onNavigateToHelp}
              className="px-3 py-1.5 bg-teal-50 hover:bg-teal-100 text-teal-800 text-xs font-semibold rounded border border-teal-300 transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <i className="fa-solid fa-circle-question text-teal-600"></i>
              <span>Panduan Menu 4 Tingkat</span>
            </button>
          )}

          <button
            type="button"
            onClick={() => handleResetForAdd(undefined, 1)}
            className="px-3 py-1.5 bg-[#007bff] hover:bg-[#0069d9] text-white text-xs font-semibold rounded shadow-xs transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <i className="fa-solid fa-circle-plus"></i>
            <span>+ Tambah Sistem Utama (L1)</span>
          </button>

          <button
            type="button"
            onClick={() => handleResetForAdd(undefined, 2)}
            className="px-3 py-1.5 bg-[#28a745] hover:bg-[#218838] text-white text-xs font-semibold rounded shadow-xs transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <i className="fa-solid fa-plus"></i>
            <span>+ Tambah Modul (L2)</span>
          </button>
        </div>
      </div>

      {/* Global Notification Banner */}
      {notification && (
        <div
          className={`mb-4 p-3 rounded-[4px] text-xs font-medium flex items-center justify-between gap-2 shadow-xs ${
            notification.type === 'success'
              ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
              : 'bg-red-50 text-red-800 border border-red-200'
          }`}
        >
          <div className="flex items-center gap-2">
            <i
              className={`fa-solid ${
                notification.type === 'success' ? 'fa-circle-check text-emerald-600' : 'fa-circle-exclamation text-red-600'
              }`}
            ></i>
            <span>{notification.message}</span>
          </div>
          <button
            type="button"
            onClick={() => setNotification(null)}
            className="text-gray-400 hover:text-gray-700"
          >
            <i className="fa-solid fa-xmark"></i>
          </button>
        </div>
      )}

      {/* Main Grid: Left Tree View | Right Item Form */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* LEFT PANEL: Interactive Tree View */}
        <div className="lg:col-span-6">
          <AdminCard
            title={
              <div className="flex items-center gap-2">
                <span>Pohon Struktur Menu Aplikasi</span>
                <span className="text-xs bg-gray-100 text-gray-700 px-2 py-0.5 rounded font-mono font-normal">
                  {menuItems.length} Item
                </span>
              </div>
            }
            icon="fa-solid fa-network-wired"
            variant="outline-primary"
            tools={
              <div className="flex items-center gap-1">
                <button
                  type="button"
                  onClick={expandAll}
                  className="px-2 py-0.5 text-xs text-gray-600 hover:bg-gray-100 rounded border border-gray-200"
                  title="Buka semua cabang menu"
                >
                  <i className="fa-solid fa-angles-down mr-1"></i>Buka Semua
                </button>
                <button
                  type="button"
                  onClick={collapseAll}
                  className="px-2 py-0.5 text-xs text-gray-600 hover:bg-gray-100 rounded border border-gray-200"
                  title="Tutup semua cabang menu"
                >
                  <i className="fa-solid fa-angles-up mr-1"></i>Tutup Semua
                </button>
              </div>
            }
          >
            {/* Search & Level Filter Bar */}
            <div className="space-y-2 mb-3">
              <div className="relative">
                <i className="fa-solid fa-magnifying-glass absolute left-3 top-2.5 text-gray-400 text-xs"></i>
                <input
                  type="text"
                  placeholder="Cari menu berdasarkan nama, kode, atau kata kunci..."
                  value={searchFilter}
                  onChange={(e) => setSearchFilter(e.target.value)}
                  className="w-full pl-8 pr-3 py-1.5 text-xs bg-gray-50 border border-gray-300 rounded focus:bg-white focus:outline-none focus:ring-1 focus:ring-blue-500"
                />
                {searchFilter && (
                  <button
                    type="button"
                    onClick={() => setSearchFilter('')}
                    className="absolute right-2.5 top-2 text-gray-400 hover:text-gray-700 text-xs"
                  >
                    <i className="fa-solid fa-circle-xmark"></i>
                  </button>
                )}
              </div>

              {/* Level Filter Chips */}
              <div className="flex flex-wrap items-center gap-1 text-xs">
                <span className="text-gray-500 text-[11px] font-medium mr-1">Saring Tingkat:</span>
                <button
                  type="button"
                  onClick={() => setLevelFilter('ALL')}
                  className={`px-2 py-0.5 rounded text-[11px] font-medium transition-colors ${
                    levelFilter === 'ALL'
                      ? 'bg-gray-800 text-white font-bold'
                      : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                  }`}
                >
                  Semua ({menuItems.length})
                </button>
                {([1, 2, 3, 4] as HierarchyLevel[]).map((lvl) => {
                  const count = menuItems.filter((i) => i.level === lvl).length;
                  const cfg = LEVEL_CONFIG[lvl];
                  return (
                    <button
                      key={lvl}
                      type="button"
                      onClick={() => setLevelFilter(lvl)}
                      className={`px-2 py-0.5 rounded text-[11px] font-medium transition-colors ${
                        levelFilter === lvl
                          ? `${cfg.badgeClass} font-bold ring-1 ring-offset-1 ring-gray-400`
                          : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                      }`}
                    >
                      L{lvl} {cfg.name.split(':')[1]} ({count})
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Tree View Container */}
            <div className="tree-container max-h-[560px] overflow-y-auto pr-1">
              {hierarchyTree.length === 0 ? (
                <div className="text-center py-10 bg-gray-50 rounded border border-dashed border-gray-300">
                  <i className="fa-solid fa-folder-tree text-3xl text-gray-300 mb-2"></i>
                  <p className="text-xs font-semibold text-gray-700">Belum Ada Susunan Menu</p>
                  <p className="text-[11px] text-gray-500 mt-1">
                    Klik "+ Tambah Sistem Utama (L1)" untuk mulai membuat susunan menu.
                  </p>
                </div>
              ) : (
                hierarchyTree.map((node) => renderTreeNode(node))
              )}
            </div>

            {/* Tree Legend */}
            <div className="mt-4 pt-3 border-t border-gray-200 flex flex-wrap items-center justify-between text-[11px] text-gray-500 gap-2">
              <div className="flex items-center gap-2">
                <span className="font-semibold text-gray-700">Tingkatan Menu:</span>
                <span className="bg-blue-100 text-blue-800 px-1.5 py-0.2 rounded font-mono">L1 Sistem</span>
                <span>→</span>
                <span className="bg-green-100 text-green-800 px-1.5 py-0.2 rounded font-mono">L2 Modul</span>
                <span>→</span>
                <span className="bg-amber-100 text-amber-800 px-1.5 py-0.2 rounded font-mono">L3 Menu</span>
                <span>→</span>
                <span className="bg-cyan-100 text-cyan-800 px-1.5 py-0.2 rounded font-mono">L4 Fitur</span>
              </div>
            </div>
          </AdminCard>
        </div>

        {/* RIGHT PANEL: Form to Add/Edit/Delete Menu Items */}
        <div className="lg:col-span-6">
          <AdminCard
            title={
              <div className="flex items-center gap-2">
                <span>
                  {formMode === 'EDIT' ? `Ubah Data: ${selectedItem?.name || ''}` : 'Tambah Menu / Fitur Baru'}
                </span>
                <span
                  className={`text-[10px] font-bold px-2 py-0.5 rounded font-mono uppercase ${
                    formMode === 'EDIT' ? 'bg-amber-500 text-gray-900' : 'bg-emerald-600 text-white'
                  }`}
                >
                  {formMode === 'EDIT' ? 'MODE UBAH' : 'MODE TAMBAH'}
                </span>
              </div>
            }
            icon={formMode === 'EDIT' ? 'fa-solid fa-pen-to-square' : 'fa-solid fa-square-plus'}
            variant={formMode === 'EDIT' ? 'outline-warning' : 'outline-success'}
            tools={
              formMode === 'EDIT' && (
                <button
                  type="button"
                  onClick={() => handleResetForAdd()}
                  className="px-2 py-0.5 text-xs bg-gray-100 hover:bg-gray-200 text-gray-700 rounded border border-gray-300"
                >
                  <i className="fa-solid fa-plus mr-1"></i>Ganti ke Mode Tambah Baru
                </button>
              )
            }
          >
            {/* Live Breadcrumb Location Preview */}
            {breadcrumbTrail.length > 0 && formMode === 'EDIT' && (
              <div className="mb-4 p-2.5 bg-gray-50 rounded border border-gray-200 text-xs">
                <div className="text-[10px] font-bold uppercase tracking-wider text-gray-400 mb-1">
                  Jalur Lokasi Menu Saat Ini
                </div>
                <div className="flex flex-wrap items-center gap-1.5 text-gray-800 font-medium">
                  {breadcrumbTrail.map((b, idx) => {
                    const isLast = idx === breadcrumbTrail.length - 1;
                    const cfg = LEVEL_CONFIG[b.level];
                    return (
                      <React.Fragment key={b.id}>
                        <span
                          className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] ${
                            isLast ? `${cfg.badgeClass} font-bold` : 'bg-gray-200 text-gray-800'
                          }`}
                        >
                          <i className={b.icon || cfg.icon}></i>
                          <span>{b.name}</span>
                        </span>
                        {!isLast && <span className="text-gray-400 text-xs">/</span>}
                      </React.Fragment>
                    );
                  })}
                </div>
              </div>
            )}

            <form onSubmit={handleSaveItem} className="space-y-3.5">
              {/* Hierarchy Level Selector */}
              <div>
                <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1.5">
                  Tingkat Menu <span className="text-red-500">*</span>
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5">
                  {([1, 2, 3, 4] as HierarchyLevel[]).map((lvl) => {
                    const cfg = LEVEL_CONFIG[lvl];
                    const isSelected = formLevel === lvl;
                    return (
                      <button
                        key={lvl}
                        type="button"
                        onClick={() => {
                          setFormLevel(lvl);
                          // Reset parent if changing to L1
                          if (lvl === 1) setFormParentId('');
                        }}
                        className={`p-2 rounded border text-left transition-all ${
                          isSelected
                            ? `${cfg.badgeClass} border-transparent shadow-xs font-bold ring-2 ring-offset-1 ring-blue-500`
                            : 'bg-gray-50 hover:bg-gray-100 border-gray-200 text-gray-700'
                        }`}
                      >
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-[11px] uppercase font-mono">L{lvl}</span>
                          <i className={cfg.icon}></i>
                        </div>
                        <div className="text-xs truncate">{cfg.name.split(':')[1].trim()}</div>
                      </button>
                    );
                  })}
                </div>
                <p className="text-[11px] text-gray-500 mt-1">
                  {LEVEL_CONFIG[formLevel].description}
                </p>
              </div>

              {/* Parent Selector (only if level > 1) */}
              {formLevel > 1 && (
                <div>
                  <label htmlFor="form-parent-item-select" className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1">
                    Pilih Menu Induk ({LEVEL_CONFIG[(formLevel - 1) as HierarchyLevel].name.split(':')[1]}){' '}
                    <span className="text-red-500">*</span>
                  </label>
                  <select
                    id="form-parent-item-select"
                    value={formParentId}
                    onChange={(e) => setFormParentId(e.target.value)}
                    required
                    className="w-full p-2 text-xs bg-white border border-gray-300 rounded focus:ring-1 focus:ring-blue-500 focus:outline-none"
                  >
                    <option value="">
                      -- Pilih Menu Induk ({LEVEL_CONFIG[(formLevel - 1) as HierarchyLevel].name.split(':')[1]}) --
                    </option>
                    {validParentOptions.map((opt) => (
                      <option key={opt.id} value={opt.id}>
                        {opt.code} - {opt.name}
                      </option>
                    ))}
                  </select>
                  {validParentOptions.length === 0 && (
                    <p className="text-[11px] text-amber-600 mt-1">
                      ⚠️ Belum ada data untuk tingkat {formLevel - 1}. Silakan buat data tingkat{' '}
                      {formLevel - 1} terlebih dahulu.
                    </p>
                  )}
                </div>
              )}

              {/* Item Name & Code */}
              <div className="grid grid-cols-1 sm:grid-cols-12 gap-3">
                <div className="sm:col-span-8">
                  <label htmlFor="form-item-name-input" className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1">
                    Nama Menu / Fitur <span className="text-red-500">*</span>
                  </label>
                  <input
                    id="form-item-name-input"
                    type="text"
                    required
                    placeholder="Contoh: Pendaftaran Pasien Baru"
                    value={formName}
                    onChange={(e) => setFormName(e.target.value)}
                    className="w-full p-2 text-xs bg-white border border-gray-300 rounded focus:ring-1 focus:ring-blue-500 focus:outline-none font-semibold text-gray-900"
                  />
                </div>

                <div className="sm:col-span-4">
                  <label htmlFor="form-item-code-input" className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1">
                    Kode Pengenal (Opsional)
                  </label>
                  <input
                    id="form-item-code-input"
                    type="text"
                    placeholder="Otomatis dibuat jika kosong"
                    value={formCode}
                    onChange={(e) => setFormCode(e.target.value)}
                    className="w-full p-2 text-xs bg-gray-50 border border-gray-300 rounded focus:bg-white focus:ring-1 focus:ring-blue-500 focus:outline-none font-mono text-gray-700"
                  />
                </div>
              </div>

              {/* FontAwesome Icon Picker */}
              <div>
                <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1">
                  Ikon Visual
                </label>
                <div className="flex items-center gap-2">
                  <div className="w-9 h-9 rounded bg-gray-100 border border-gray-300 flex items-center justify-center text-base text-gray-700">
                    <i className={formIcon}></i>
                  </div>
                  <input
                    type="text"
                    value={formIcon}
                    onChange={(e) => setFormIcon(e.target.value)}
                    placeholder="fa-solid fa-folder"
                    className="flex-1 p-2 text-xs bg-white border border-gray-300 rounded font-mono"
                  />
                </div>
                {/* Common Icon Presets */}
                <div className="flex flex-wrap items-center gap-1.5 mt-2">
                  <span className="text-[10px] text-gray-400">Pilihan Cepat:</span>
                  {COMMON_FA_ICONS.slice(0, 10).map((ico) => (
                    <button
                      key={ico}
                      type="button"
                      onClick={() => setFormIcon(ico)}
                      className={`w-6 h-6 rounded flex items-center justify-center text-xs transition-all ${
                        formIcon === ico
                          ? 'bg-blue-600 text-white'
                          : 'bg-gray-100 hover:bg-gray-200 text-gray-700'
                      }`}
                      title={ico}
                    >
                      <i className={ico}></i>
                    </button>
                  ))}
                </div>
              </div>

              {/* Description */}
              <div>
                <label htmlFor="form-item-description-input" className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1">
                  Keterangan & Catatan Tambahan
                </label>
                <textarea
                  id="form-item-description-input"
                  rows={2}
                  value={formDescription}
                  onChange={(e) => setFormDescription(e.target.value)}
                  placeholder="Tujuan kegunaan, batasan operasional, atau petunjuk singkat..."
                  className="w-full p-2 text-xs bg-white border border-gray-300 rounded focus:ring-1 focus:ring-blue-500 focus:outline-none"
                />
              </div>

              {/* Form Buttons */}
              <div className="pt-3 border-t border-gray-200 flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <button
                    type="submit"
                    className="px-4 py-2 bg-[#007bff] hover:bg-[#0069d9] text-white text-xs font-bold rounded shadow-xs transition-colors flex items-center gap-1.5 cursor-pointer"
                  >
                    <i className="fa-solid fa-floppy-disk"></i>
                    <span>{formMode === 'EDIT' ? 'Simpan Perubahan' : 'Simpan Menu Baru'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleResetForAdd()}
                    className="px-3 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 text-xs font-semibold rounded border border-gray-300 transition-colors flex items-center gap-1 cursor-pointer"
                  >
                    <i className="fa-solid fa-rotate-left"></i>
                    <span>Bersihkan Formulir</span>
                  </button>
                </div>

                {formMode === 'EDIT' && selectedItemId && (
                  <div className="flex items-center gap-2">
                    {/* If selected item is a Feature (L4), provide direct shortcut to create RE node */}
                    {selectedItem?.level === 4 && onNavigateToBuilderWithFeature && (
                      <button
                        type="button"
                        onClick={() => {
                          const menu = menuItems.find((m) => m.id === selectedItem.parentId);
                          const module = menu ? menuItems.find((m) => m.id === menu.parentId) : undefined;
                          if (module && menu) {
                            onNavigateToBuilderWithFeature(module.id, menu.id, selectedItem.id);
                          }
                        }}
                        className="px-3 py-2 bg-amber-500 hover:bg-amber-600 text-gray-900 text-xs font-bold rounded shadow-xs transition-colors flex items-center gap-1.5 cursor-pointer"
                      >
                        <i className="fa-solid fa-bolt"></i>
                        <span>+ Buat Alur Kebutuhan untuk Fitur Ini</span>
                      </button>
                    )}

                    <button
                      type="button"
                      onClick={() => handleDeleteItem(selectedItemId)}
                      className="px-3 py-2 bg-red-50 hover:bg-red-100 text-red-700 text-xs font-semibold rounded border border-red-300 transition-colors flex items-center gap-1 cursor-pointer"
                    >
                      <i className="fa-solid fa-trash-can"></i>
                      <span>Hapus</span>
                    </button>
                  </div>
                )}
              </div>
            </form>
          </AdminCard>
        </div>
      </div>
    </div>
  );
};
