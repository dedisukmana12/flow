import React from 'react';

interface InfoBoxProps {
  title: string;
  value: string | number;
  icon: string;
  variant: 'primary' | 'success' | 'warning' | 'info' | 'danger' | 'dark';
  subtitle?: string;
  progressPercent?: number;
  progressDescription?: string;
  onClick?: () => void;
}

export const InfoBox: React.FC<InfoBoxProps> = ({
  title,
  value,
  icon,
  variant,
  subtitle,
  progressPercent,
  progressDescription,
  onClick,
}) => {
  const getColors = () => {
    switch (variant) {
      case 'primary':
        return { bg: 'bg-[#007bff]', text: 'text-white', iconBg: 'bg-[#0069d9]', subText: 'text-blue-100' };
      case 'success':
        return { bg: 'bg-[#28a745]', text: 'text-white', iconBg: 'bg-[#218838]', subText: 'text-green-100' };
      case 'warning':
        return { bg: 'bg-[#ffc107]', text: 'text-gray-900', iconBg: 'bg-[#e0a800]', subText: 'text-gray-800' };
      case 'info':
        return { bg: 'bg-[#17a2b8]', text: 'text-white', iconBg: 'bg-[#138496]', subText: 'text-cyan-100' };
      case 'danger':
        return { bg: 'bg-[#dc3545]', text: 'text-white', iconBg: 'bg-[#c82333]', subText: 'text-red-100' };
      default:
        return { bg: 'bg-[#343a40]', text: 'text-white', iconBg: 'bg-[#23272b]', subText: 'text-gray-300' };
    }
  };

  const colors = getColors();

  return (
    <div
      onClick={onClick}
      className={`rounded-[4px] shadow-[0_0_1px_rgba(0,0,0,.125),0_1px_3px_rgba(0,0,0,.2)] ${colors.bg} ${colors.text} p-4 flex flex-col justify-between relative overflow-hidden transition-all duration-200 hover:shadow-md ${onClick ? 'cursor-pointer hover:scale-[1.01]' : ''}`}
    >
      <div className="flex justify-between items-start z-10">
        <div>
          <div className="text-[28px] font-bold tracking-tight leading-none mb-1 font-mono">
            {value}
          </div>
          <div className="text-xs uppercase tracking-wider font-semibold opacity-90">
            {title}
          </div>
          {subtitle && (
            <div className={`text-[11px] mt-1 ${colors.subText}`}>
              {subtitle}
            </div>
          )}
        </div>
        <div className="w-12 h-12 rounded-[4px] bg-black/10 flex items-center justify-center text-2xl">
          <i className={icon}></i>
        </div>
      </div>

      {progressPercent !== undefined && (
        <div className="mt-3 z-10">
          <div className="w-full bg-black/20 h-1 rounded-full overflow-hidden">
            <div
              className="bg-white h-full transition-all duration-500"
              style={{ width: `${Math.min(100, Math.max(0, progressPercent))}%` }}
            ></div>
          </div>
          {progressDescription && (
            <div className="text-[10px] mt-1 opacity-80 flex justify-between">
              <span>{progressDescription}</span>
              <span>{progressPercent}%</span>
            </div>
          )}
        </div>
      )}

      {/* Decorative background watermark icon */}
      <div className="absolute right-2 bottom-0 text-[70px] opacity-10 pointer-events-none -mb-4 -mr-2">
        <i className={icon}></i>
      </div>
    </div>
  );
};
