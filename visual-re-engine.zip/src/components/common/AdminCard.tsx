import React, { useState } from 'react';

interface AdminCardProps {
  id?: string;
  title: React.ReactNode;
  icon?: string;
  badgeText?: string;
  badgeClass?: string;
  variant?: 'primary' | 'success' | 'warning' | 'info' | 'danger' | 'dark' | 'secondary' | 'outline-primary' | 'outline-success' | 'outline-warning' | 'outline-info';
  children: React.ReactNode;
  footer?: React.ReactNode;
  tools?: React.ReactNode;
  collapsible?: boolean;
  className?: string;
  bodyClassName?: string;
  noPadding?: boolean;
}

export const AdminCard: React.FC<AdminCardProps> = ({
  id,
  title,
  icon,
  badgeText,
  badgeClass = 'bg-[#17a2b8] text-white',
  variant = 'outline-primary',
  children,
  footer,
  tools,
  collapsible = false,
  className = '',
  bodyClassName = '',
  noPadding = false,
}) => {
  const [collapsed, setCollapsed] = useState(false);

  // AdminLTE Card Header Color Classes
  const getVariantStyles = () => {
    switch (variant) {
      case 'primary':
        return { header: 'bg-[#007bff] text-white border-b-0', card: 'border-t-0' };
      case 'success':
        return { header: 'bg-[#28a745] text-white border-b-0', card: 'border-t-0' };
      case 'warning':
        return { header: 'bg-[#ffc107] text-gray-900 border-b-0', card: 'border-t-0' };
      case 'info':
        return { header: 'bg-[#17a2b8] text-white border-b-0', card: 'border-t-0' };
      case 'danger':
        return { header: 'bg-[#dc3545] text-white border-b-0', card: 'border-t-0' };
      case 'dark':
        return { header: 'bg-[#343a40] text-white border-b-0', card: 'border-t-0' };
      case 'outline-primary':
        return { header: 'bg-white text-[#007bff] border-b border-gray-200', card: 'border-t-3 border-t-[#007bff]' };
      case 'outline-success':
        return { header: 'bg-white text-[#28a745] border-b border-gray-200', card: 'border-t-3 border-t-[#28a745]' };
      case 'outline-warning':
        return { header: 'bg-white text-[#b38600] border-b border-gray-200', card: 'border-t-3 border-t-[#ffc107]' };
      case 'outline-info':
        return { header: 'bg-white text-[#17a2b8] border-b border-gray-200', card: 'border-t-3 border-t-[#17a2b8]' };
      default:
        return { header: 'bg-gray-50 text-gray-800 border-b border-gray-200', card: 'border-t-3 border-t-gray-400' };
    }
  };

  const styles = getVariantStyles();

  return (
    <div
      id={id}
      className={`bg-white rounded-[4px] shadow-[0_0_1px_rgba(0,0,0,.125),0_1px_3px_rgba(0,0,0,.2)] border border-gray-200/80 mb-4 transition-all duration-200 ${styles.card} ${className}`}
    >
      <div className={`px-4 py-3 rounded-t-[3px] flex items-center justify-between gap-2 ${styles.header}`}>
        <div className="flex items-center gap-2 font-semibold text-[15px] tracking-tight">
          {icon && <i className={`${icon} text-[15px] opacity-90`}></i>}
          <div className="truncate">{title}</div>
          {badgeText && (
            <span className={`text-[11px] font-bold px-2 py-0.5 rounded-full ml-1 uppercase tracking-wider ${badgeClass}`}>
              {badgeText}
            </span>
          )}
        </div>

        <div className="flex items-center gap-1 text-xs">
          {tools}
          {collapsible && (
            <button
              type="button"
              onClick={() => setCollapsed(!collapsed)}
              className="px-1.5 py-0.5 rounded hover:bg-black/10 transition-colors cursor-pointer text-inherit"
              title={collapsed ? 'Expand Card' : 'Collapse Card'}
            >
              <i className={`fa-solid ${collapsed ? 'fa-plus' : 'fa-minus'}`}></i>
            </button>
          )}
        </div>
      </div>

      {!collapsed && (
        <>
          <div className={`${noPadding ? 'p-0' : 'p-4'} ${bodyClassName}`}>
            {children}
          </div>
          {footer && (
            <div className="px-4 py-3 bg-gray-50/80 border-t border-gray-200 rounded-b-[4px] flex items-center justify-between gap-2">
              {footer}
            </div>
          )}
        </>
      )}
    </div>
  );
};
