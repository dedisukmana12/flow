import React, { useEffect, useRef, useState } from 'react';
import mermaid from 'mermaid';

interface MermaidViewerProps {
  chart: string;
  className?: string;
  onNodeClick?: (nodeId: string) => void;
}

export const MermaidViewer: React.FC<MermaidViewerProps> = ({
  chart,
  className = '',
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [svgContent, setSvgContent] = useState<string>('');
  const [error, setError] = useState<string | null>(null);
  const [zoom, setZoom] = useState<number>(1);
  const [copied, setCopied] = useState<boolean>(false);

  useEffect(() => {
    mermaid.initialize({
      startOnLoad: false,
      theme: 'default',
      securityLevel: 'loose',
      fontFamily: 'Source Sans 3, sans-serif',
      flowchart: {
        htmlLabels: true,
        curve: 'basis',
        useMaxWidth: false,
      },
    });
  }, []);

  useEffect(() => {
    let isMounted = true;
    const renderChart = async () => {
      if (!chart.trim()) {
        setSvgContent('');
        setError(null);
        return;
      }

      try {
        const uniqueId = `mermaid-svg-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
        const { svg } = await mermaid.render(uniqueId, chart);
        if (isMounted) {
          setSvgContent(svg);
          setError(null);
        }
      } catch (err: any) {
        if (isMounted) {
          console.warn('Mermaid syntax error:', err);
          setError(err?.message || 'Error rendering diagram syntax');
        }
      }
    };

    renderChart();

    return () => {
      isMounted = false;
    };
  }, [chart]);

  const handleCopy = () => {
    navigator.clipboard.writeText(chart);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadSVG = () => {
    if (!svgContent) return;
    const blob = new Blob([svgContent], { type: 'image/svg+xml' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `re-engine-diagram-${Date.now()}.svg`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className={`flex flex-col h-full bg-white border border-gray-200 rounded-[4px] relative overflow-hidden ${className}`}>
      {/* Top Toolbar */}
      <div className="flex items-center justify-between px-3 py-2 bg-gray-50 border-b border-gray-200 text-xs text-gray-700">
        <div className="flex items-center gap-2">
          <span className="font-semibold text-gray-800 flex items-center gap-1.5">
            <i className="fa-solid fa-diagram-project text-[#007bff]"></i>
            Mermaid Diagram Canvas
          </span>
          <span className="bg-blue-100 text-blue-800 text-[10px] font-bold px-2 py-0.5 rounded">
            Live Interactive
          </span>
        </div>

        <div className="flex items-center gap-1">
          {/* Zoom controls */}
          <div className="flex items-center bg-white border border-gray-300 rounded mr-2">
            <button
              type="button"
              onClick={() => setZoom((prev) => Math.max(0.4, prev - 0.15))}
              className="px-2 py-1 hover:bg-gray-100 text-gray-700 border-r border-gray-200"
              title="Zoom Out"
            >
              <i className="fa-solid fa-magnifying-glass-minus"></i>
            </button>
            <span className="px-2 text-[11px] font-mono text-gray-600 min-w-[45px] text-center">
              {Math.round(zoom * 100)}%
            </span>
            <button
              type="button"
              onClick={() => setZoom((prev) => Math.min(2.5, prev + 0.15))}
              className="px-2 py-1 hover:bg-gray-100 text-gray-700 border-r border-gray-200"
              title="Zoom In"
            >
              <i className="fa-solid fa-magnifying-glass-plus"></i>
            </button>
            <button
              type="button"
              onClick={() => setZoom(1)}
              className="px-2 py-1 hover:bg-gray-100 text-gray-600 text-[10px]"
              title="Reset Zoom (100%)"
            >
              Reset
            </button>
          </div>

          <button
            type="button"
            onClick={handleCopy}
            className="px-2.5 py-1 bg-white hover:bg-gray-100 text-gray-700 border border-gray-300 rounded font-medium transition-colors flex items-center gap-1"
          >
            <i className={`fa-solid ${copied ? 'fa-check text-green-600' : 'fa-copy'}`}></i>
            <span>{copied ? 'Copied' : 'Copy Code'}</span>
          </button>

          <button
            type="button"
            onClick={handleDownloadSVG}
            disabled={!svgContent}
            className="px-2.5 py-1 bg-[#17a2b8] hover:bg-[#138496] disabled:opacity-50 text-white rounded font-medium transition-colors flex items-center gap-1"
          >
            <i className="fa-solid fa-download"></i>
            <span>Export SVG</span>
          </button>
        </div>
      </div>

      {/* Main Diagram Area */}
      <div
        ref={containerRef}
        className="flex-1 overflow-auto p-6 bg-[#fafbfc] flex items-center justify-center min-h-[420px] relative"
        style={{
          backgroundImage: 'radial-gradient(#e5e7eb 1px, transparent 1px)',
          backgroundSize: '20px 20px',
        }}
      >
        {error ? (
          <div className="max-w-md p-4 bg-red-50 border border-red-200 rounded text-red-700 text-xs">
            <div className="font-bold flex items-center gap-1.5 mb-1 text-sm">
              <i className="fa-solid fa-triangle-exclamation"></i>
              Diagram Generation Notice
            </div>
            <p className="mb-2">There was an issue rendering this diagram specification:</p>
            <pre className="bg-red-100/80 p-2 rounded text-[11px] font-mono whitespace-pre-wrap overflow-x-auto">
              {error}
            </pre>
          </div>
        ) : svgContent ? (
          <div
            className="transition-transform duration-150 origin-center select-none"
            style={{ transform: `scale(${zoom})` }}
            dangerouslySetInnerHTML={{ __html: svgContent }}
          />
        ) : (
          <div className="text-gray-400 text-sm flex flex-col items-center gap-2">
            <i className="fa-solid fa-spinner fa-spin text-2xl text-blue-500"></i>
            <span>Constructing visual logic model...</span>
          </div>
        )}
      </div>
    </div>
  );
};
