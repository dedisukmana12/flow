import { MenuItem, Project, RequirementNode } from '../types';

export const DEFAULT_PROJECTS: Project[] = [
  {
    id: 'proj-medicare-01',
    name: 'MediCare HealthOS',
    code: 'MCO-SYS',
    systemName: 'Hospital Clinical & Administrative ERP',
    description: 'Enterprise hospital information system handling patient triage, EHR, pharmacy auto-dispensing, and insurance settlement.',
    version: '2.4.0',
    author: 'Principal Systems Architect',
    roles: ['Triage Nurse', 'Attending Physician', 'Chief Pharmacist', 'Billing Officer', 'Patient Portal User', 'System Administrator', 'BPJS/Insurance Gateway'],
    createdAt: '2026-01-15T08:00:00.000Z',
    updatedAt: '2026-08-20T14:30:00.000Z',
  },
  {
    id: 'proj-nexpay-02',
    name: 'NexPay Financial Switch',
    code: 'NP-GATEWAY',
    systemName: 'Core Payment & Settlement Engine',
    description: 'High-throughput payment gateway orchestrating multi-currency card processing, QRIS dynamic routing, and fraud risk scoring.',
    version: '1.8.0',
    author: 'FinTech Lead Engineer',
    roles: ['Merchant Admin', 'End Customer', 'Risk & Compliance Officer', 'Card Scheme API', 'Settlement Bot'],
    createdAt: '2026-03-10T10:00:00.000Z',
    updatedAt: '2026-08-18T16:00:00.000Z',
  }
];

export const DEFAULT_MENU_ITEMS: MenuItem[] = [
  // PROJECT 1: MediCare HealthOS
  // LEVEL 1: System
  {
    id: 'sys-medicare-root',
    projectId: 'proj-medicare-01',
    name: 'MediCare HealthOS Suite',
    code: 'SYS-MCO',
    level: 1,
    parentId: null,
    description: 'Central hospital operating system root framework.',
    icon: 'fa-solid fa-hospital',
    order: 1,
    createdAt: '2026-01-15T08:00:00.000Z',
    updatedAt: '2026-01-15T08:00:00.000Z'
  },
  
  // LEVEL 2: Modules under System
  {
    id: 'mod-patient-admin',
    projectId: 'proj-medicare-01',
    name: 'Patient Administration & Triage',
    code: 'MOD-PATIENT',
    level: 2,
    parentId: 'sys-medicare-root',
    description: 'Handles walk-in intake, emergency room triage scoring, biometric ID registration, and room allocations.',
    icon: 'fa-solid fa-id-card-clip',
    order: 1,
    createdAt: '2026-01-15T08:10:00.000Z',
    updatedAt: '2026-01-15T08:10:00.000Z'
  },
  {
    id: 'mod-clinical-ehr',
    projectId: 'proj-medicare-01',
    name: 'Clinical & Electronic Health Records (EHR)',
    code: 'MOD-EHR',
    level: 2,
    parentId: 'sys-medicare-root',
    description: 'Doctor consultation workspace, medical history, e-prescriptions, and ICD-10 diagnostic coding.',
    icon: 'fa-solid fa-notes-medical',
    order: 2,
    createdAt: '2026-01-15T08:20:00.000Z',
    updatedAt: '2026-01-15T08:20:00.000Z'
  },
  {
    id: 'mod-pharmacy-dispense',
    projectId: 'proj-medicare-01',
    name: 'Pharmacy & Drug Inventory',
    code: 'MOD-PHARM',
    level: 2,
    parentId: 'sys-medicare-root',
    description: 'Drug compounding, prescription validation, batch expiry alerts, and inventory stock replenishment.',
    icon: 'fa-solid fa-pills',
    order: 3,
    createdAt: '2026-01-15T08:30:00.000Z',
    updatedAt: '2026-01-15T08:30:00.000Z'
  },
  {
    id: 'mod-billing-insurance',
    projectId: 'proj-medicare-01',
    name: 'Billing & Insurance Settlement',
    code: 'MOD-BILL',
    level: 2,
    parentId: 'sys-medicare-root',
    description: 'Invoice aggregation, BPJS / Private Insurer API bridge, patient co-pay calculations, and receipting.',
    icon: 'fa-solid fa-file-invoice-dollar',
    order: 4,
    createdAt: '2026-01-15T08:40:00.000Z',
    updatedAt: '2026-01-15T08:40:00.000Z'
  },

  // LEVEL 3: Menus under Modules
  // Menus for MOD-PATIENT
  {
    id: 'mnu-patient-intake',
    projectId: 'proj-medicare-01',
    name: 'Patient Intake & Biometric Check-In',
    code: 'MNU-INTAKE',
    level: 3,
    parentId: 'mod-patient-admin',
    description: 'Front-desk intake workstation for national ID scan, fingerprint verification, and queue ticket issuance.',
    icon: 'fa-solid fa-user-plus',
    order: 1,
    createdAt: '2026-01-15T09:00:00.000Z',
    updatedAt: '2026-01-15T09:00:00.000Z'
  },
  {
    id: 'mnu-triage-emergency',
    projectId: 'proj-medicare-01',
    name: 'Emergency Triage & Bed Allocation',
    code: 'MNU-TRIAGE',
    level: 3,
    parentId: 'mod-patient-admin',
    description: 'Manchester Triage System (MTS) score input, vital signs monitor feed, and urgent ICU/Ward bed reservation.',
    icon: 'fa-solid fa-truck-medical',
    order: 2,
    createdAt: '2026-01-15T09:10:00.000Z',
    updatedAt: '2026-01-15T09:10:00.000Z'
  },
  
  // Menus for MOD-EHR
  {
    id: 'mnu-physician-desk',
    projectId: 'proj-medicare-01',
    name: 'Physician Consultation Station',
    code: 'MNU-CONSULT',
    level: 3,
    parentId: 'mod-clinical-ehr',
    description: 'Interactive clinical notes, vital trend charts, lab test orders, and SOAP documentation.',
    icon: 'fa-solid fa-stethoscope',
    order: 1,
    createdAt: '2026-01-15T09:20:00.000Z',
    updatedAt: '2026-01-15T09:20:00.000Z'
  },
  {
    id: 'mnu-eprescription-desk',
    projectId: 'proj-medicare-01',
    name: 'E-Prescription & Allergy Shield',
    code: 'MNU-EPRESCRIBE',
    level: 3,
    parentId: 'mod-clinical-ehr',
    description: 'Direct digital prescription dispatch with auto contraindication checking against patient allergies.',
    icon: 'fa-solid fa-file-prescription',
    order: 2,
    createdAt: '2026-01-15T09:30:00.000Z',
    updatedAt: '2026-01-15T09:30:00.000Z'
  },

  // Menus for MOD-PHARM
  {
    id: 'mnu-dispensary-queue',
    projectId: 'proj-medicare-01',
    name: 'Dispensary Verification & Dispensing',
    code: 'MNU-DISPENSE',
    level: 3,
    parentId: 'mod-pharmacy-dispense',
    description: 'Pharmacist verification queue, barcoded medicine picking, and dosage label printing.',
    icon: 'fa-solid fa-box-tissue',
    order: 1,
    createdAt: '2026-01-15T09:40:00.000Z',
    updatedAt: '2026-01-15T09:40:00.000Z'
  },

  // LEVEL 4: Features under Menus
  // Features for MNU-INTAKE
  {
    id: 'ft-biometric-verify',
    projectId: 'proj-medicare-01',
    name: 'National ID & Fingerprint Verification',
    code: 'FT-BIO-VERIFY',
    level: 4,
    parentId: 'mnu-patient-intake',
    description: 'Captures hardware fingerprint biometric and matches against National Population Registry API.',
    icon: 'fa-solid fa-fingerprint',
    order: 1,
    createdAt: '2026-01-15T10:00:00.000Z',
    updatedAt: '2026-01-15T10:00:00.000Z'
  },
  {
    id: 'ft-insurance-eligibility',
    projectId: 'proj-medicare-01',
    name: 'Real-time Insurance Coverage Check',
    code: 'FT-INS-CHECK',
    level: 4,
    parentId: 'mnu-patient-intake',
    description: 'Queries insurer health card active policy limits and generates SEP pre-authorization code.',
    icon: 'fa-solid fa-shield-halved',
    order: 2,
    createdAt: '2026-01-15T10:10:00.000Z',
    updatedAt: '2026-01-15T10:10:00.000Z'
  },

  // Features for MNU-TRIAGE
  {
    id: 'ft-vital-score-calc',
    projectId: 'proj-medicare-01',
    name: 'Emergency Severity Index (ESI) Calculator',
    code: 'FT-ESI-CALC',
    level: 4,
    parentId: 'mnu-triage-emergency',
    description: 'Computes ESI Category 1-5 from SpO2, systolic BP, pain score, and Glasgow Coma Scale.',
    icon: 'fa-solid fa-heart-pulse',
    order: 1,
    createdAt: '2026-01-15T10:20:00.000Z',
    updatedAt: '2026-01-15T10:20:00.000Z'
  },

  // Features for MNU-EPRESCRIBE
  {
    id: 'ft-drug-interaction-guard',
    projectId: 'proj-medicare-01',
    name: 'Drug-Drug & Food Interaction Sentinel',
    code: 'FT-DRUG-SENTINEL',
    level: 4,
    parentId: 'mnu-eprescription-desk',
    description: 'Cross-checks prescribed compound against existing active regimen and flagged patient allergies.',
    icon: 'fa-solid fa-triangle-exclamation',
    order: 1,
    createdAt: '2026-01-15T10:30:00.000Z',
    updatedAt: '2026-01-15T10:30:00.000Z'
  },

  // Features for MNU-DISPENSE
  {
    id: 'ft-batch-auto-deduct',
    projectId: 'proj-medicare-01',
    name: 'Barcode Scan & FEFO Stock Auto-Deduction',
    code: 'FT-FEFO-DEDUCT',
    level: 4,
    parentId: 'mnu-dispensary-queue',
    description: 'Scans pharmaceutical 2D barcode, enforces First-Expired First-Out (FEFO), and writes inventory audit log.',
    icon: 'fa-solid fa-barcode',
    order: 1,
    createdAt: '2026-01-15T10:40:00.000Z',
    updatedAt: '2026-01-15T10:40:00.000Z'
  }
];

export const DEFAULT_REQUIREMENTS: RequirementNode[] = [
  {
    id: 'req-001',
    projectId: 'proj-medicare-01',
    reqCode: 'REQ-INTAKE-001',
    title: 'Patient Identity Biometric Matching & Record Linking',
    moduleId: 'mod-patient-admin',
    menuId: 'mnu-patient-intake',
    featureId: 'ft-biometric-verify',
    
    whoRole: 'Triage Nurse',
    whoCustom: '',
    fromWhere: 'Intake Desk Biometric Hardware Terminal',
    action: 'Scans patient fingerprint and enters 16-digit National ID (NIK)',
    logic: 'System queries Local Master Patient Index (MPI). If matched, fetch medical record history. If not found locally, query National Civil Registry API.',
    output: 'Returns active patient profile with active visit number and prints thermal wristband with QR code.',
    toWhere: 'Triage Emergency Queue & Doctor Consultation Desk',
    toWhereType: 'internal_menu',
    
    hasBranching: true,
    branches: [
      {
        id: 'br-001-1',
        label: 'Branch A: National ID Not Found / Unregistered',
        condition: 'If National ID does not exist in registry or fingerprint mismatch > 3 attempts',
        output: 'Trigger "Emergency Temporary Medical Record" workflow with provisional MRN-TEMP-XXXX and flag for social worker verification.',
        toWhere: 'Emergency Temp Profile Modal',
        toWhereType: 'ui_view'
      },
      {
        id: 'br-001-2',
        label: 'Branch B: Active Unsettled Bill Warning',
        condition: 'If patient has outstanding unpaid emergency deposit from previous encounter > 90 days',
        output: 'Display non-blocking Financial Counseling advisory dialog while still allowing immediate clinical triage admission.',
        toWhere: 'Billing Officer Notification Bell',
        toWhereType: 'internal_menu'
      }
    ],
    
    priority: 'CRITICAL',
    status: 'APPROVED',
    notes: 'Compliant with Indonesia Kemenkes SATUSEHAT FHIR Patient Resource specification.',
    createdAt: '2026-01-15T11:00:00.000Z',
    updatedAt: '2026-08-10T09:15:00.000Z'
  },
  {
    id: 'req-002',
    projectId: 'proj-medicare-01',
    reqCode: 'REQ-CLINIC-002',
    title: 'E-Prescription Real-time Allergy & Cross-Interaction Shield',
    moduleId: 'mod-clinical-ehr',
    menuId: 'mnu-eprescription-desk',
    featureId: 'ft-drug-interaction-guard',
    
    whoRole: 'Attending Physician',
    whoCustom: '',
    fromWhere: 'Physician Consultation EHR Worksheet',
    action: 'Selects antibiotic medication (e.g. Amoxicillin 500mg) and clicks "Commit Prescription"',
    logic: 'System parses patient allergen register for Beta-Lactam / Penicillin family. Also computes glomerular filtration rate (eGFR) for renal dosage safety adjustments.',
    output: 'Prescription digitally signed with physician private key and instantly routed to Pharmacy Dispensary Queue.',
    toWhere: 'Dispensary Verification & Dispensing Menu',
    toWhereType: 'internal_menu',
    
    hasBranching: true,
    branches: [
      {
        id: 'br-002-1',
        label: 'Branch Critical: Severe Anaphylaxis Allergy Detected',
        condition: 'If selected drug belongs to verified High-Risk Patient Allergy group',
        output: 'Hard-block prescription submission. Pop up Red Alert Modal requiring physician to choose alternative compound or provide documented Clinical Override justification.',
        toWhere: 'Clinical Override Dialog',
        toWhereType: 'ui_view'
      },
      {
        id: 'br-002-2',
        label: 'Branch Warning: Moderate Drug Interaction with Regimen',
        condition: 'If selected drug interacts moderately with patient active chronic medicine (e.g. Warfarin)',
        output: 'Display Yellow Warning Banner detailing interaction severity and recommended dosage adjustment interval, allowing single-click confirmation.',
        toWhere: 'Prescription Form Warning Box',
        toWhereType: 'ui_view'
      }
    ],
    
    priority: 'CRITICAL',
    status: 'APPROVED',
    notes: 'Reduces medical prescription errors by 98% based on clinical trials.',
    createdAt: '2026-01-16T14:20:00.000Z',
    updatedAt: '2026-08-12T11:45:00.000Z'
  },
  {
    id: 'req-003',
    projectId: 'proj-medicare-01',
    reqCode: 'REQ-PHARM-003',
    title: 'FEFO Barcode Scan & Dispensary Inventory Stock Depletion',
    moduleId: 'mod-pharmacy-dispense',
    menuId: 'mnu-dispensary-queue',
    featureId: 'ft-batch-auto-deduct',
    
    whoRole: 'Chief Pharmacist',
    whoCustom: '',
    fromWhere: 'Pharmacy Barcode Handheld Scanner Terminal',
    action: 'Scans 2D DataMatrix on drug packaging during physical dispensing',
    logic: 'Verify batch number against system FEFO allocation table. Verify expiry date > 90 days. Decrement warehouse SKU inventory count in transactional database.',
    output: 'Prints automated patient instructional sticker ("3x daily after meals") and marks prescription item as DISPENSED in EHR.',
    toWhere: 'Billing & Insurance Settlement Module',
    toWhereType: 'internal_menu',
    
    hasBranching: false,
    branches: [],
    
    priority: 'HIGH',
    status: 'IN_REVIEW',
    notes: 'Linear node with audit logging for narcotic / psychotropic drugs.',
    createdAt: '2026-01-18T10:00:00.000Z',
    updatedAt: '2026-08-15T15:30:00.000Z'
  },
  {
    id: 'req-004',
    projectId: 'proj-medicare-01',
    reqCode: 'REQ-TRIAGE-004',
    title: 'Emergency Severity Index (ESI) Scoring & Priority Queue Sorting',
    moduleId: 'mod-patient-admin',
    menuId: 'mnu-triage-emergency',
    featureId: 'ft-vital-score-calc',
    
    whoRole: 'Triage Nurse',
    whoCustom: '',
    fromWhere: 'Emergency Admission Tablet App',
    action: 'Inputs vital signs (BP, Pulse, SpO2, Pain scale) and clicks "Compute ESI Tier"',
    logic: 'Calculate ESI Category (Tier 1: Resuscitation, Tier 2: Emergent, Tier 3: Urgent, Tier 4: Less Urgent, Tier 5: Non-Urgent). Determine bed readiness.',
    output: 'System reorders waiting room TV dashboard in real-time, flashing Red alert for Tier 1/2 cases and paging Trauma Team on-call pagers.',
    toWhere: 'Emergency Resuscitation Bay / Physician Console',
    toWhereType: 'internal_menu',
    
    hasBranching: true,
    branches: [
      {
        id: 'br-004-1',
        label: 'Branch Emergency: ESI Level 1 (Cardiac Arrest / Trauma)',
        condition: 'If SpO2 < 85% or GCS < 9 or Systolic BP < 70 mmHg',
        output: 'Trigger Code Red siren in ER bay, auto-reserve Trauma Bay 1, and dispatch emergency airway kit.',
        toWhere: 'Code Red Hospital Paging System',
        toWhereType: 'external_api'
      }
    ],
    
    priority: 'CRITICAL',
    status: 'APPROVED',
    notes: 'Tested with simulation emergency scenarios.',
    createdAt: '2026-01-20T09:00:00.000Z',
    updatedAt: '2026-08-19T13:10:00.000Z'
  }
];
